'use client';

import { useState, useCallback } from 'react';
import Sidebar from '@/components/dashboard/Sidebar';
import Topbar from '@/components/dashboard/Topbar';
import StatCards from '@/components/dashboard/StatCards';
import RenewalTable from '@/components/dashboard/RenewalTable';
import QuotesPipeline from '@/components/dashboard/QuotesPipeline';
import ActivityFeed from '@/components/dashboard/ActivityFeed';
import TaskPanel from '@/components/dashboard/TaskPanel';
import NewSubmissionModal from '@/components/dashboard/NewSubmissionModal';
import type { SubmissionData } from '@/components/dashboard/NewSubmissionModal';

// ── ALERT BANNER ───────────────────────────────────────────────────────────────
function AlertBanner({ onDismiss }: { onDismiss: () => void }) {
  return (
    <div style={{
      background: 'var(--amber-bg)',
      border: '1px solid rgba(138,90,0,0.2)',
      borderRadius: 'var(--radius)',
      padding: '10px 16px',
      display: 'flex', alignItems: 'center', gap: 10,
      fontSize: 13, color: 'var(--amber)',
      animation: 'slideDown 0.3s ease',
    }}>
      <span>⚠</span>
      <span>
        <strong style={{ fontWeight: 600 }}>3 renewals expiring within 10 days.</strong>
        {' '}KARS INC, Aniad Selim, and Delta Kay require immediate attention.
      </span>
      <span
        onClick={onDismiss}
        style={{ marginLeft: 'auto', cursor: 'pointer', opacity: 0.7, fontSize: 18, lineHeight: 1, padding: '2px 4px' }}
      >
        ×
      </span>
    </div>
  );
}

// ── MINI STAT PAIR ─────────────────────────────────────────────────────────────
function MiniStatPair() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
      {[
        { label: 'Overdue', value: 3, color: 'var(--red)',   sub: 'tasks past due'   },
        { label: 'Done',    value: 1, color: 'var(--green)', sub: 'tasks completed' },
      ].map(s => (
        <div key={s.label} style={{
          background: 'var(--surface)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-lg)',
          padding: '14px 16px',
        }}>
          <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: '0.5px', textTransform: 'uppercase', color: 'var(--text-3)', marginBottom: 6 }}>
            {s.label}
          </div>
          <div style={{ fontSize: 26, fontWeight: 300, fontFamily: 'var(--mono)', letterSpacing: '-1px', color: s.color }}>
            {s.value}
          </div>
          <div style={{ fontSize: 10.5, color: 'var(--text-3)', marginTop: 3 }}>{s.sub}</div>
        </div>
      ))}
    </div>
  );
}

// ── TOAST ──────────────────────────────────────────────────────────────────────
function Toast({ message, visible }: { message: string; visible: boolean }) {
  if (!visible) return null;
  return (
    <div style={{
      position: 'fixed', bottom: 24, right: 24,
      background: 'var(--text)', color: '#fff',
      padding: '12px 18px', borderRadius: 'var(--radius)',
      fontSize: 13, fontWeight: 500,
      boxShadow: 'var(--shadow-lg)',
      display: 'flex', alignItems: 'center', gap: 8,
      zIndex: 300, animation: 'slideUp 0.2s ease',
    }}>
      ✓ {message}
    </div>
  );
}

// ── DASHBOARD PAGE ─────────────────────────────────────────────────────────────
export default function DashboardPage() {
  const [showAlert, setShowAlert]   = useState(true);
  const [modalOpen, setModalOpen]   = useState(false);
  const [toast, setToast]           = useState({ visible: false, message: '' });

  const showToast = useCallback((msg: string) => {
    setToast({ visible: true, message: msg });
    setTimeout(() => setToast(prev => ({ ...prev, visible: false })), 2500);
  }, []);

  const handleSubmit = useCallback((data: SubmissionData) => {
    showToast(`Created: ${data.description || data.type} for ${data.clientName}`);
  }, [showToast]);

  return (
    <>
      {/* CSS variables + global styles loaded via globals.css */}
      <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg)' }}>

        <Sidebar />

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>

          <Topbar onNewSubmission={() => setModalOpen(true)} />

          {/* Scrollable content */}
          <div style={{
            flex: 1, overflowY: 'auto',
            padding: 24,
            display: 'flex', flexDirection: 'column', gap: 20,
          }}>

            {showAlert && <AlertBanner onDismiss={() => setShowAlert(false)} />}

            <StatCards />

            {/* Main two-column grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16, alignItems: 'start' }}>

              {/* Left stack */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 0 }}>
                <RenewalTable />
                <QuotesPipeline />
                <ActivityFeed />
              </div>

              {/* Right stack */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <MiniStatPair />
                <TaskPanel onNewTask={() => setModalOpen(true)} />
              </div>

            </div>
          </div>
        </div>
      </div>

      <NewSubmissionModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={handleSubmit}
      />

      <Toast message={toast.message} visible={toast.visible} />
    </>
  );
}
