// File: /components/dashboard/DashboardPage.tsx (REFACTORED)
// Purpose: Main dashboard using WorkflowKanban (unified renewals + submissions)
// Deploy: BACKUP current file, then replace with this version

'use client'

import { useState, useCallback } from 'react'
import Sidebar from '@/components/dashboard/Sidebar'
import Topbar from '@/components/dashboard/Topbar'
import MetricBar from '@/components/dashboard/MetricBar'
import WorkflowKanban from '@/components/dashboard/WorkflowKanban'
import ActivityFeed from '@/components/dashboard/ActivityFeed'
import NewSubmissionModal from '@/components/dashboard/NewSubmissionModal'
import type { SubmissionData } from '@/components/dashboard/NewSubmissionModal'
import type { WorkflowItem } from '@/app/api/workflow-items/route'

// ── COLORS & VARS ──────────────────────────────────────────────────────────
const BG = '#0A0A0B'
const BG1 = '#0F0F11'
const BG2 = '#141416'
const BD = 'rgba(255,255,255,0.06)'
const TEXT = '#F0F0F2'
const T2 = '#8A8A96'
const T3 = '#52525E'
const FONT = 'Inter, DM Sans, system-ui, sans-serif'
const GREEN = '#22C55E'

// ── TOAST COMPONENT ───────────────────────────────────────────────────────
function Toast({ message, visible }: { message: string; visible: boolean }) {
  if (!visible) return null
  return (
    <div
      style={{
        position: 'fixed',
        bottom: 20,
        right: 20,
        background: '#1A1A1E',
        color: TEXT,
        border: '1px solid rgba(255,255,255,0.10)',
        padding: '10px 16px',
        borderRadius: 8,
        fontSize: 12,
        fontWeight: 500,
        boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        zIndex: 400,
        fontFamily: FONT,
      }}
    >
      <span style={{ width: 7, height: 7, borderRadius: '50%', background: GREEN, flexShrink: 0 }} />
      {message}
    </div>
  )
}

// ── DETAIL PANEL (Side drawer for viewing/editing workflow items) ────────────
function WorkflowDetailPanel({
  item,
  onClose,
  onStatusChange,
}: {
  item: WorkflowItem | null
  onClose: () => void
  onStatusChange?: (itemId: string, newStatus: string) => void
}) {
  if (!item) return null

  const STATUSES = ['pending', 'in_review', 'awaiting_uw', 'bound', 'declined']

  return (
    <>
      {/* Overlay */}
      <div
        style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.5)',
          zIndex: 100,
          backdropFilter: 'blur(2px)',
        }}
        onClick={onClose}
      />

      {/* Panel */}
      <div
        style={{
          position: 'fixed',
          right: 0,
          top: 0,
          bottom: 0,
          width: '400px',
          background: BG2,
          borderLeft: `1px solid ${BD}`,
          zIndex: 101,
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column',
          fontFamily: FONT,
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: '16px',
            borderBottom: `1px solid ${BD}`,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
        }}
      >
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: TEXT, marginBottom: 4 }}>
              {item.clientName}
            </div>
            <div style={{ fontSize: 10, color: T3 }}>
              {item.policyNumber || item.trackingNumber || '—'}
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              fontSize: 18,
              color: T2,
            }}
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div style={{ flex: 1, padding: '16px', display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Type & Status */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', color: T3, marginBottom: 6 }}>
              Type
            </div>
            <div style={{ fontSize: 11, color: TEXT, textTransform: 'capitalize' }}>
              {item.type === 'renewal' ? '🔄 Renewal' : '📋 Submission'}
            </div>
          </div>

          {/* Status Selector */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', color: T3, marginBottom: 6 }}>
              Status
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {STATUSES.map(status => (
                <button
                  key={status}
                  onClick={() => {
                    onStatusChange?.(item.id, status)
                    onClose()
                  }}
                  style={{
                    padding: '8px 10px',
                    background: item.status === status ? '#3B82F6' : BG1,
                    color: item.status === status ? TEXT : T2,
                    border: `1px solid ${item.status === status ? '#3B82F6' : BD}`,
                    borderRadius: 4,
                    cursor: 'pointer',
                    fontSize: 11,
                    fontWeight: 500,
                    fontFamily: FONT,
                    transition: 'all 0.2s',
                    textTransform: 'capitalize',
                  }}
                  onMouseEnter={(e) => {
                    const el = e.currentTarget as HTMLButtonElement
                    if (item.status !== status) {
                      el.style.borderColor = T2
                      el.style.color = TEXT
                    }
                  }}
                  onMouseLeave={(e) => {
                    const el = e.currentTarget as HTMLButtonElement
                    if (item.status !== status) {
                      el.style.borderColor = BD
                      el.style.color = T2
                    }
                  }}
                >
                  {status.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Details Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', color: T3, marginBottom: 4 }}>
                Policy Type
              </div>
              <div style={{ fontSize: 11, color: T2 }}>{item.policyType}</div>
            </div>
            <div>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', color: T3, marginBottom: 4 }}>
                Carrier
              </div>
              <div style={{ fontSize: 11, color: T2 }}>{item.carrier || '—'}</div>
            </div>
          </div>

          {/* Premium */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', color: T3, marginBottom: 4 }}>
              Premium
            </div>
            <div style={{ fontSize: 14, fontWeight: 600, color: TEXT }}>
              ${item.premium.toLocaleString('en-US', { maximumFractionDigits: 0 })}
            </div>
          </div>

          {/* Expiry Info (Renewals only) */}
          {item.expiryDate && (
            <div>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', color: T3, marginBottom: 4 }}>
                Expiry Date
              </div>
              <div style={{ fontSize: 11, color: T2 }}>
                {new Date(item.expiryDate).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                })}
              </div>
              {item.daysUntilExpiry !== undefined && (
                <div style={{ fontSize: 10, color: T3, marginTop: 4 }}>
                  {item.daysUntilExpiry < 0
                    ? `${Math.abs(item.daysUntilExpiry)} days overdue`
                    : `${item.daysUntilExpiry} days remaining`}
                </div>
              )}
            </div>
          )}

          {/* Created Date */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', color: T3, marginBottom: 4 }}>
              Created
            </div>
            <div style={{ fontSize: 11, color: T2 }}>
              {new Date(item.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
              })}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div
          style={{
            padding: '16px',
            borderTop: `1px solid ${BD}`,
            display: 'flex',
            gap: 8,
          }}
        >
          <button
            onClick={onClose}
            style={{
              flex: 1,
              padding: '8px 12px',
              background: BG1,
              border: `1px solid ${BD}`,
              borderRadius: 4,
              color: TEXT,
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: FONT,
            }}
          >
            Close
          </button>
          <button
            style={{
              flex: 1,
              padding: '8px 12px',
              background: '#3B82F6',
              border: '1px solid #3B82F6',
              borderRadius: 4,
              color: '#F0F0F2',
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: FONT,
            }}
          >
            Edit
          </button>
        </div>
      </div>
    </>
  )
}

// ── MAIN DASHBOARD PAGE ────────────────────────────────────────────────────
export default function DashboardPage() {
  const [modalOpen, setModalOpen] = useState(false)
  const [toast, setToast] = useState({ visible: false, msg: '' })
  const [selectedItem, setSelectedItem] = useState<WorkflowItem | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)

  const showToast = useCallback((msg: string) => {
    setToast({ visible: true, msg })
    setTimeout(() => setToast((p) => ({ ...p, visible: false })), 2800)
  }, [])

  const handleSubmit = useCallback(
    (data: SubmissionData) => {
      showToast(`Created: ${data.description || data.type} for ${data.clientName}`)
      setModalOpen(false)
      setRefreshKey((k) => k + 1)
    },
    [showToast]
  )

  const handleStatusChange = useCallback(
    (itemId: string, newStatus: string) => {
      showToast(`Status updated to "${newStatus}"`)
      setRefreshKey((k) => k + 1)
      // TODO: Call API to update status
      // await fetch(`/api/workflow-items/${itemId}`, { method: 'PATCH', body: JSON.stringify({ status: newStatus }) })
    },
    [showToast]
  )

  return (
    <>
      <div
        style={{
          display: 'flex',
          height: '100vh',
          overflow: 'hidden',
          background: BG,
          fontFamily: FONT,
          fontSize: 13,
          lineHeight: 1.5,
          WebkitFontSmoothing: 'antialiased',
          colorScheme: 'dark',
        }}
      >
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content */}
        <div
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            minWidth: 0,
            background: BG,
          }}
        >
          <Topbar onNewSubmission={() => setModalOpen(true)} />

          {/* Scrollable Content Area */}
          <div
            style={{
              flex: 1,
              overflowY: 'auto',
              padding: '18px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
              background: BG,
            }}
          >
            {/* Metric Bar (Sticky) */}
            <MetricBar refreshKey={refreshKey} />

            {/* Kanban Board (Primary View) */}
            <div style={{ flex: 1, minHeight: 0 }}>
              <h2 style={{ fontSize: 14, fontWeight: 600, color: TEXT, marginBottom: 12 }}>
                Workflow Items
              </h2>
              <WorkflowKanban refreshKey={refreshKey} onCardClick={setSelectedItem} />
            </div>

            {/* Activity Feed (Footer) */}
            <div style={{ borderTop: `1px solid ${BD}`, paddingTop: '12px' }}>
              <ActivityFeed />
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <NewSubmissionModal open={modalOpen} onClose={() => setModalOpen(false)} onSubmit={handleSubmit} />

      <WorkflowDetailPanel
        item={selectedItem}
        onClose={() => setSelectedItem(null)}
        onStatusChange={handleStatusChange}
      />

      <Toast message={toast.msg} visible={toast.visible} />
    </>
  )
}
