# CASURANCE CRM DASHBOARD - COMPLETE AUDIT & REFACTOR PLAN

**Date:** June 15, 2026  
**Status:** Ready for Implementation  
**Scope:** xriskio/cascrm (Next.js + Supabase + Drizzle ORM)

---

## EXECUTIVE SUMMARY

### Current State: **BROKEN LAYOUT**
Your dashboard is attempting **three competing views** that do the same job:
1. **RenewalTable** (list view showing upcoming expirations)
2. **QuotesPipeline** (kanban view with zero data)
3. **StatCards** + **TaskPanel** + **ActivityFeed** (redundant metrics)

This creates cognitive load, wastes viewport space, and splits renewal/submission workflow across separate tables.

### Recommendation: **UNIFIED KANBAN + TABLE TOGGLE**
- **Single source of truth** for renewals AND submissions
- **Kanban by default** (visual, drag-drop ready, status-driven)
- **Table toggle** for power users (sortable, filterable)
- **Clean sidebar** (remove Task Panel, integrate into main workflow)
- **Sticky metric bar** (collapse-safe, 1-line summary)

---

## PART 1: CODEBASE AUDIT

### Database Tables (Verified)

```
renewals (UUID id, ~20 fields)
├── id, qq_policy_id, policy_number
├── named_insured, contact_id
├── policy_type, lob, effective_date, expiration_date, renewal_date
├── premium, total_premium
├── insurance_company, carrier, agent_name, mga
├── status (pending|quoted|bound|declined), archived
└── created_at, updated_at

submissions (UUID id, ~20 fields)
├── id, tracking_number
├── client_name, client_id, contact_email, contact_phone
├── policy_type, effective_date, expiration_date
├── requested_premium, quoted_premium, premium_amount
├── status (pending|quoted|awaiting_uw|bound|declined), priority
├── assigned_agent, carrier
├── date_received, time_received
└── created_at, updated_at
```

**KEY INSIGHT:** Both tables have:
- `status` (but different enums)
- `carrier` and `policy_type`
- `created_at` / `updated_at`
- Premium info (requested vs. actual)

**PROBLEM:** They're NOT unified—need a view/query that treats them as one "workflow item" stream.

### Component Tree (Current)

```
DashboardPage (main layout)
├── Sidebar (left nav)
├── Topbar (header)
└── Content area:
    ├── AiInsightsStrip
    ├── StatCards (4 KPI cards: Pending, Renewals, Quotes, Clients)
    └── Main grid (3-column):
        ├── Left col:
        │   ├── RenewalTable (queries /api/renewals, shows 10 items)
        │   ├── QuotesPipeline (hardcoded empty kanban)
        │   └── ActivityFeed (hardcoded empty)
        └── Right col (296px):
            ├── 2x MiniCard (Overdue, Done)
            └── TaskPanel
```

**PROBLEM:** RenewalTable takes primary real estate, but QuotesPipeline (which should also show submissions) is empty. TaskPanel is cramped sidebar real-estate (14 tasks in 296px width).

### API Routes (Verified)

#### `/api/renewals`
- **GET** `?page=1&limit=10&upcoming=true` → returns `{ renewals: [...], pagination: {...} }` or `{ data: [...] }`
- **POST** → creates renewal
- Current: Filters `expiration_date >= today`, orders by expiration date ascending
- Used by: RenewalTable component

#### `/api/submissions`
- **Status:** Likely exists but not wired into dashboard
- **Missing from dashboard:** No <SubmissionTable> or similar

#### Other
- `/api/activity` → activity feed (unused in dashboard)
- `/api/market-submissions` → market submission tracking (separate)

---

## PART 2: PROBLEM STATEMENT

### What's Broken

| Issue | Impact | Root Cause |
|-------|--------|-----------|
| **Two views of same data** | Confusion: Is "Renewal" status final or draft? | RenewalTable shows expirations, QuotesPipeline shows quotes—but quotes ARE part of renewal workflow |
| **Kanban is empty** | Pointless UI component | No data wired to QuotesPipeline; submissions not queried |
| **No submissions view** | Can't see new submissions (only renewals) | Dashboard doesn't fetch from `/api/submissions` |
| **Sidebar TaskPanel useless** | 296px width, 14 max tasks, text truncates | Poor layout choice; should integrate with main workflow |
| **AI Insights strip** | Dead UI (says "4 AI Insights: Add data...") | Placeholder, not functional |
| **StatCards redundant** | Show same data as table counts | Could collapse to 1-line metric bar at top |

### What Users Actually Need (Insurance Broker Workflow)

**Primary Question:** "What renewals and submissions need action RIGHT NOW?"

**Workflow:**
1. **See all pending work** → Renewals (expiring policies) + Submissions (new quotes) in one place
2. **Filter by status** → Pending → In Review → Awaiting Underwriting → Bound
3. **Filter by urgency** → Overdue (red), 14 days (yellow), 30+ days (green)
4. **Take action** → Click → View full details → Change status → Add notes
5. **Bulk operations** → Archive, assign, email, export CSV

---

## PART 3: UNIFIED DATA MODEL

### New View: `WorkflowItem`

Instead of querying renewals and submissions separately, create a **unified query** that returns one shape:

```typescript
interface WorkflowItem {
  id: string;                    // UUID
  type: 'renewal' | 'submission'; // Discriminator
  
  // Identity
  clientName: string;
  policyNumber?: string;
  trackingNumber?: string;       // Submissions only
  
  // Status & Urgency
  status: 'pending' | 'in_review' | 'awaiting_uw' | 'bound' | 'declined';
  priority?: 'low' | 'normal' | 'high';
  daysUntilExpiry?: number;      // Renewals: auto-calc from expiration_date
  urgency: 'overdue' | 'critical' | 'warning' | 'ok'; // Color-coded: red/red/yellow/green
  
  // Coverage
  policyType: string;            // 'liability', 'workers_comp', etc.
  currentCarrier?: string;       // Renewals: existing carrier
  quotedCarrier?: string;        // Submissions: carrier being quoted
  
  // Financial
  premium: number;               // Current or requested
  quotedPremium?: number;        // Submissions: quoted amount
  
  // Dates
  expiryDate?: Date;             // Renewals: when policy expires
  createdAt: Date;
  updatedAt: Date;
  
  // Metadata
  assignedAgent?: string;
  notes?: string;
  carrier?: string; // Fallback if no specific carrier
}
```

### Implementation: Unified Query API

Create new endpoint: `/api/workflow-items`

```typescript
// GET /api/workflow-items?filter=pending&urgency=critical&sortBy=expiryDate
// Returns: WorkflowItem[]

const UNIFIED_QUERY = `
  -- Renewals as workflow items
  SELECT 
    id, 'renewal'::text as type, policy_number as tracking_number,
    named_insured as client_name, policy_type, carrier,
    status, premium, expiration_date, created_at, updated_at
  FROM renewals
  WHERE archived = false
  
  UNION ALL
  
  -- Submissions as workflow items
  SELECT
    id, 'submission'::text as type, tracking_number,
    client_name, policy_type, carrier,
    status, quoted_premium as premium, expiration_date, created_at, updated_at
  FROM submissions
  WHERE status != 'declined'
  
  ORDER BY expiration_date ASC NULLS LAST, created_at DESC
`;
```

---

## PART 4: LAYOUT REDESIGN

### Current Layout (BEFORE)
```
┌─────────────────────────────────────────────────┐
│ SIDEBAR (200px)     │ TOPBAR (full width)       │
├─────────────────────┼──────────────────────────┤
│                     │ AI INSIGHTS              │
│                     │ STAT CARDS (4x)          │
│ Nav Links           ├──────────────────────────┤
│ └─ Dashboard        │ LEFT CONTENT (Main grid):│
│ └─ Renewals         │  ┌─────────────────────┐ │
│ └─ Submissions      │  │ RENEWAL TABLE       │ │ Sidebar takes
│ └─ Clients          │  │ (10 rows visible)   │ │ Real estate but
│ └─ Leads            │  ├─────────────────────┤ │ has 14 tasks!
│ └─ ...              │  │ QUOTES PIPELINE     │ │
│                     │  │ (3 empty columns)   │ │
│                     │  ├─────────────────────┤ │
│                     │  │ ACTIVITY FEED       │ │
│                     │  │ (empty)             │ │
│                     │  └─────────────────────┘ │
│                     │ RIGHT SIDEBAR (296px):  │
│                     │ ┌─────────────────────┐ │
│                     │ │ 2x MINI CARDS       │ │
│                     │ ├─────────────────────┤ │
│                     │ │ TASK PANEL          │ │
│                     │ │ (truncated tasks)   │ │
│                     │ └─────────────────────┘ │
└─────────────────────┴──────────────────────────┘
```

### Proposed Layout (AFTER)

```
┌─────────────────────────────────────────────────────┐
│ SIDEBAR              │ TOPBAR (full width)           │
│ (200px, same)        │ [New Submission] [Settings]  │
├──────────────────────┼────────────────────────────────┤
│                      │ METRIC BAR (sticky, collapses) │
│ Nav Links            │ Pending: 12 │ Overdue: 2 │ ... │
│ └─ Dashboard         ├────────────────────────────────┤
│ └─ Renewals          │                                │
│ └─ Submissions       │ KANBAN VIEW (Main Content)     │
│ └─ Clients           │ [≡ Switch to Table]            │
│ └─ ...               │                                │
│                      │ ┌──────┬─────────┬───────┬────┐│
│                      │ │PEND. │IN REV.  │AWAIT. │BOUND││
│                      │ │(12)  │(4)      │(3)    │(8) ││
│                      │ ├──────┼─────────┼───────┼────┤│
│                      │ │CARD 1│ CARD 1  │ CARD 1│ ... ││
│                      │ │Green │ Metro   │ Sierra│     ││
│                      │ │Serv. │ Unlimit.│ Summ. │     ││
│                      │ │Exp:14│ Exp: 8d │Exp:22 │     ││
│                      │ │→Trav │ 🔴      │→Wait. │     ││
│                      │ │      │         │       │     ││
│                      │ │[+ADD]│ [+ADD]  │[+ADD] │[+ADD]││
│                      │ └──────┴─────────┴───────┴────┘│
│                      │                                │
│                      │ RECENT ACTIVITY (footer)       │
│                      │ • GreenBoss: Quoted to Trav.   │
│                      │ • Sierra: Bound Jun 24         │
│                      │                                │
└──────────────────────┴────────────────────────────────┘
```

**Key Changes:**
- ✅ Remove right sidebar (TaskPanel moved to main nav or modal)
- ✅ Remove AI Insights + StatCards (collapse to metric bar)
- ✅ Kanban becomes PRIMARY view (full width)
- ✅ Remove QuotesPipeline duplicate (merge with RenewalTable)
- ✅ ActivityFeed moves to footer (read-only reference)
- ✅ Add table toggle for power users

---

## PART 5: COMPONENT REFACTOR

### Phase 1: Create Unified API (1-2 hours)

**New file:** `/app/api/workflow-items/route.ts`

```typescript
import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface WorkflowItem {
  id: string;
  type: 'renewal' | 'submission';
  clientName: string;
  policyNumber?: string;
  trackingNumber?: string;
  status: string;
  priority?: string;
  daysUntilExpiry?: number;
  policyType: string;
  carrier: string;
  premium: number;
  quotedPremium?: number;
  expiryDate?: string;
  createdAt: string;
  updatedAt: string;
  assignedAgent?: string;
}

export async function GET(request: NextRequest) {
  try {
    const supabase = supabaseAdmin;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '50');

    // Query renewals
    let renewalsQuery = supabase
      .from('renewals')
      .select('id, policy_number, named_insured as client_name, policy_type, carrier, status, premium, expiration_date, created_at, updated_at')
      .eq('archived', false);

    if (status) renewalsQuery = renewalsQuery.eq('status', status);
    
    const { data: renewals = [] } = await renewalsQuery.limit(limit);

    // Query submissions
    let submissionsQuery = supabase
      .from('submissions')
      .select('id, tracking_number, client_name, policy_type, carrier, status, quoted_premium, expiration_date, created_at, updated_at')
      .neq('status', 'declined');

    if (status) submissionsQuery = submissionsQuery.eq('status', status);
    
    const { data: submissions = [] } = await submissionsQuery.limit(limit);

    // Transform & merge
    const renewalItems: WorkflowItem[] = renewals.map((r: any) => ({
      id: r.id,
      type: 'renewal',
      clientName: r.client_name,
      policyNumber: r.policy_number,
      status: r.status,
      policyType: r.policy_type,
      carrier: r.carrier,
      premium: parseFloat(r.premium) || 0,
      expiryDate: r.expiration_date,
      daysUntilExpiry: r.expiration_date ? Math.ceil((new Date(r.expiration_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : undefined,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));

    const submissionItems: WorkflowItem[] = submissions.map((s: any) => ({
      id: s.id,
      type: 'submission',
      clientName: s.client_name,
      trackingNumber: s.tracking_number,
      status: s.status,
      policyType: s.policy_type,
      carrier: s.carrier,
      premium: parseFloat(s.quoted_premium) || 0,
      quotedPremium: parseFloat(s.quoted_premium),
      expiryDate: s.expiration_date,
      createdAt: s.created_at,
      updatedAt: s.updated_at,
    }));

    const items = [...renewalItems, ...submissionItems]
      .sort((a, b) => {
        // Sort by expiry date, then by created date
        if (a.expiryDate && b.expiryDate) {
          return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
        }
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

    return NextResponse.json({ items }, { status: 200 });
  } catch (error) {
    console.error('Workflow items error:', error);
    return NextResponse.json({ error: 'Failed to fetch items' }, { status: 500 });
  }
}
```

### Phase 2: Build Unified Kanban (2-3 hours)

**New file:** `/components/dashboard/WorkflowKanban.tsx`

```typescript
'use client';

import { useState, useEffect } from 'react';

interface WorkflowItem {
  id: string;
  type: 'renewal' | 'submission';
  clientName: string;
  policyNumber?: string;
  trackingNumber?: string;
  status: string;
  daysUntilExpiry?: number;
  policyType: string;
  carrier: string;
  premium: number;
  expiryDate?: string;
}

const STATUSES = ['pending', 'in_review', 'awaiting_uw', 'bound', 'declined'];
const STATUS_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  pending: { bg: '#3B82F6', text: '#E0E7FF', border: 'rgba(59,130,246,0.2)' },
  in_review: { bg: '#F59E0B', text: '#FEF3C7', border: 'rgba(245,158,11,0.2)' },
  awaiting_uw: { bg: '#8B5CF6', text: '#EDE9FE', border: 'rgba(139,92,246,0.2)' },
  bound: { bg: '#22C55E', text: '#DCFCE7', border: 'rgba(34,197,94,0.2)' },
  declined: { bg: '#EF4444', text: '#FEE2E2', border: 'rgba(239,68,68,0.2)' },
};

function getUrgency(daysLeft?: number): 'overdue' | 'critical' | 'warning' | 'ok' {
  if (!daysLeft) return 'ok';
  if (daysLeft < 0) return 'overdue';
  if (daysLeft <= 7) return 'critical';
  if (daysLeft <= 14) return 'warning';
  return 'ok';
}

function UrgencyBadge({ daysLeft }: { daysLeft?: number }) {
  const urgency = getUrgency(daysLeft);
  const colors: Record<string, string> = {
    overdue: '#EF4444',
    critical: '#EF4444',
    warning: '#F59E0B',
    ok: '#22C55E',
  };
  return (
    <span style={{
      fontSize: 10, fontWeight: 600, padding: '2px 6px',
      background: `${colors[urgency]}20`, color: colors[urgency],
      borderRadius: 4,
    }}>
      {daysLeft === undefined ? '—' : daysLeft < 0 ? `${Math.abs(daysLeft)}d OVERDUE` : `${daysLeft}d left`}
    </span>
  );
}

export default function WorkflowKanban() {
  const [items, setItems] = useState<WorkflowItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const res = await fetch('/api/workflow-items');
        if (res.ok) {
          const data = await res.json();
          setItems(data.items || []);
        }
      } catch (error) {
        console.error('Failed to fetch workflow items:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchItems();
  }, []);

  return (
    <div style={{ padding: '14px 0', overflowX: 'auto' }}>
      <div style={{ display: 'flex', gap: 12, minWidth: 'min-content' }}>
        {STATUSES.map(status => {
          const columnItems = items.filter(i => i.status === status);
          const color = STATUS_COLORS[status];
          return (
            <div key={status} style={{
              flex: '0 0 280px', border: `1px solid ${color.border}`,
              borderRadius: 8, overflow: 'hidden', background: '#0F0F11',
            }}>
              {/* Header */}
              <div style={{
                padding: '10px 12px', background: color.bg, color: color.text,
                fontWeight: 600, fontSize: 12, display: 'flex', justifyContent: 'space-between',
              }}>
                <span>{status.replace('_', ' ').toUpperCase()}</span>
                <span style={{ opacity: 0.7 }}>{columnItems.length}</span>
              </div>

              {/* Cards */}
              <div style={{ padding: '8px', minHeight: '60px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {columnItems.length === 0 ? (
                  <div style={{ color: '#52525E', fontSize: 11, textAlign: 'center', padding: '20px 8px' }}>
                    No items
                  </div>
                ) : (
                  columnItems.map(item => (
                    <div key={item.id} style={{
                      background: '#141416', border: '1px solid rgba(255,255,255,0.06)',
                      borderRadius: 6, padding: '10px', cursor: 'pointer',
                      transition: 'all 0.2s', fontSize: 11,
                    }}
                    onMouseEnter={e => {
                      (e.currentTarget as HTMLDivElement).style.borderColor = color.border;
                      (e.currentTarget as HTMLDivElement).style.background = '#1A1A1E';
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.06)';
                      (e.currentTarget as HTMLDivElement).style.background = '#141416';
                    }}
                    >
                      <div style={{ fontWeight: 600, color: '#F0F0F2', marginBottom: 4 }}>
                        {item.clientName}
                      </div>
                      <div style={{ fontSize: 10, color: '#8A8A96', marginBottom: 4 }}>
                        {item.policyNumber || item.trackingNumber || '—'} · {item.policyType}
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                        <span style={{ color: '#8A8A96' }}>${item.premium.toFixed(0)}</span>
                        <UrgencyBadge daysLeft={item.daysUntilExpiry} />
                      </div>
                      <div style={{ color: '#52525E', fontSize: 9 }}>{item.carrier || '—'}</div>
                    </div>
                  ))
                )}
              </div>

              {/* Add button */}
              <div style={{
                padding: '8px 12px', borderTop: `1px solid ${color.border}`,
                color: color.text, cursor: 'pointer', fontSize: 11, textAlign: 'center',
                background: `${color.bg}10`, fontWeight: 500,
              }}>
                + Add
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
```

### Phase 3: Build Table Toggle (1 hour)

**New file:** `/components/dashboard/WorkflowTable.tsx`

Similar component, but renders as data table with sortable columns instead of kanban.

### Phase 4: Refactor DashboardPage (1 hour)

**Modified:** `/components/dashboard/DashboardPage.tsx`

```typescript
// Remove:
// - QuotesPipeline (redundant)
// - ActivityFeed (move to footer)
// - TaskPanel sidebar
// - Collapse StatCards to MetricBar

// Add:
// - WorkflowKanban (primary)
// - Table toggle
// - MetricBar (sticky, collapses)
```

---

## PART 6: FILE CHANGES SUMMARY

### NEW FILES (3 total)

```
✨ /app/api/workflow-items/route.ts          (unified API)
✨ /components/dashboard/WorkflowKanban.tsx  (kanban view)
✨ /components/dashboard/WorkflowTable.tsx   (table view)
```

### MODIFIED FILES (4 total)

```
📝 /components/dashboard/DashboardPage.tsx   (remove old views, add new ones)
📝 /components/dashboard/StatCards.tsx       (convert to collapsible MetricBar)
📝 /components/dashboard/ActivityFeed.tsx    (relocate to footer)
📝 /components/dashboard/Topbar.tsx          (add view toggle button)
```

### DEPRECATED (Safe to Remove)

```
🗑️ /components/dashboard/QuotesPipeline.tsx  (DUPLICATE of RenewalTable)
🗑️ /components/dashboard/TaskPanel.tsx       (TODO: integrate into main nav or modal)
🗑️ /components/dashboard/RenewalTable.tsx    (MERGED into WorkflowKanban)
```

---

## PART 7: URGENCY SCORING LOGIC

Each workflow item gets an urgency color based on days until expiry:

```typescript
function calculateUrgency(item: WorkflowItem): {
  severity: 'overdue' | 'critical' | 'warning' | 'ok';
  color: string;
  label: string;
} {
  const daysLeft = item.daysUntilExpiry;
  
  if (!daysLeft) return { severity: 'ok', color: '#22C55E', label: 'On Track' };
  if (daysLeft < 0) return { severity: 'overdue', color: '#EF4444', label: `${Math.abs(daysLeft)}d OVERDUE` };
  if (daysLeft <= 7) return { severity: 'critical', color: '#EF4444', label: `${daysLeft}d - URGENT` };
  if (daysLeft <= 14) return { severity: 'warning', color: '#F59E0B', label: `${daysLeft}d - ACTION` };
  return { severity: 'ok', color: '#22C55E', label: `${daysLeft}d - OK` };
}
```

---

## PART 8: IMPLEMENTATION CHECKLIST

### Sprint 1: Backend (4 hours)
- [ ] Create `/api/workflow-items/route.ts`
- [ ] Test unified query with sample data
- [ ] Verify filter & sort parameters work
- [ ] Add error handling & logging

### Sprint 2: Frontend (6 hours)
- [ ] Build `WorkflowKanban.tsx` (scaffold, fetch, render columns)
- [ ] Build `WorkflowTable.tsx` (copy logic, swap layout)
- [ ] Add urgency badges & color logic
- [ ] Wire up to DashboardPage

### Sprint 3: Cleanup (2 hours)
- [ ] Refactor DashboardPage (remove old components)
- [ ] Convert StatCards → MetricBar (sticky, collapse-safe)
- [ ] Move ActivityFeed to footer
- [ ] Test responsiveness

### Sprint 4: Polish (2 hours)
- [ ] Add drag-drop to kanban (optional, Phase 2)
- [ ] Keyboard shortcuts (Cmd+N, etc.)
- [ ] Bulk actions (archive, assign, email)
- [ ] CSV export

**Total Estimated Time:** 14 hours

---

## PART 9: DATA ANSWERS TO YOUR QUESTIONS

### Q: "Do you need renewals + submissions side-by-side or separate?"

**A: UNIFIED (side-by-side in same kanban).**

**Reasoning:**
- Both flow through the same lifecycle: `pending → in_review → awaiting_uw → bound`
- Both have urgency (expiryDate or submission date)
- Both need the same actions (review, quote, bind, decline)
- Separating them forces the user to switch views, breaking workflow

**Visual benefit:** Kanban shows at a glance: "We have 12 pending items. 9 are renewals expiring soon, 3 are new submissions waiting on quotes."

---

### Q: "Which views to keep/remove?"

| Component | Keep? | Reason |
|-----------|-------|--------|
| **RenewalTable** | ⚠️ MERGE | Data merged into WorkflowKanban |
| **QuotesPipeline** | ❌ REMOVE | Redundant; Kanban replaces it |
| **StatCards** | ⚠️ CONVERT | Collapse to sticky MetricBar (1-line summary) |
| **TaskPanel** | ⚠️ MOVE | Integrate into main sidebar nav or modal workflow |
| **ActivityFeed** | ✅ KEEP | Relocate to footer (read-only reference) |
| **AiInsightsStrip** | ❌ REMOVE | Placeholder; no real functionality yet |

---

## PART 10: WORKFLOW AFTER REFACTOR

### User Journey

1. **Land on Dashboard** → Sees kanban with 4 columns (Pending, In Review, Awaiting UW, Bound)
2. **Scan columns** → 12 items in Pending (red/yellow badges show urgency)
3. **Click a card** → Side panel opens with full details (client, policy, carrier, notes)
4. **Take action** → Drag to next column OR click "Change Status" → Panel updates
5. **Filter/Search** → Top toolbar (Status: All/Pending/In Review/..., Search by client)
6. **Bulk actions** → Select multiple cards, "Archive" / "Assign to Agent" / "Email"
7. **Export** → Click "Export CSV", get list of all items for client/broker report
8. **Switch view** → Click "≡ Table View" for sorted, filterable list (power users)

---

## PART 11: NEXT STEPS (For You)

**When ready, I can provide:**

1. ✅ **Full working code** for all 3 new components (copy-paste ready)
2. ✅ **Detailed migration guide** (which files to delete, which to modify)
3. ✅ **Database SQL** (if you need a view instead of API query)
4. ✅ **Testing script** (Playwright smoke tests for kanban rendering)
5. ✅ **Deployment checklist** (Railway build, environment vars, etc.)

**Your decision points:**

- [ ] Approve unified kanban approach?
- [ ] Keep or remove ActivityFeed?
- [ ] Drag-drop kanban in Phase 1 or Phase 2?
- [ ] Should I generate code files now?

---

## APPENDIX A: SQL View (Alternative to API)

If you prefer a Postgres view instead of app-level query:

```sql
CREATE OR REPLACE VIEW workflow_items AS
SELECT 
  id, 'renewal'::text as type, policy_number as tracking_number,
  named_insured as client_name, policy_type, carrier,
  status, premium, expiration_date, created_at, updated_at
FROM renewals
WHERE archived = false

UNION ALL

SELECT
  id, 'submission'::text as type, tracking_number,
  client_name, policy_type, carrier,
  status, quoted_premium as premium, expiration_date, created_at, updated_at
FROM submissions
WHERE status != 'declined'

ORDER BY expiration_date ASC NULLS LAST, created_at DESC;
```

Then just `SELECT * FROM workflow_items WHERE status = ?` instead of app-level merge.

---

**END OF AUDIT**
