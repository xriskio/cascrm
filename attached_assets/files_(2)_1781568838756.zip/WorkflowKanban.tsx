// File: /components/dashboard/WorkflowKanban.tsx
// Purpose: Kanban board displaying renewals & submissions by status
// Deploy: Copy to components/dashboard/WorkflowKanban.tsx

'use client'

import { useState, useEffect } from 'react'
import type { WorkflowItem } from '@/app/api/workflow-items/route'

// ── COLORS & VARS ──────────────────────────────────────────────────────────
const BG = '#0A0A0B'
const BG1 = '#0F0F11'
const BG2 = '#141416'
const BG3 = '#1A1A1E'
const BD = 'rgba(255,255,255,0.06)'
const TEXT = '#F0F0F2'
const T2 = '#8A8A96'
const T3 = '#52525E'
const FONT = 'Inter, DM Sans, system-ui, sans-serif'

const STATUSES = [
  { id: 'pending', label: 'Pending', color: '#3B82F6', bgColor: 'rgba(59,130,246,0.1)' },
  { id: 'in_review', label: 'In Review', color: '#F59E0B', bgColor: 'rgba(245,158,11,0.1)' },
  { id: 'awaiting_uw', label: 'Awaiting UW', color: '#8B5CF6', bgColor: 'rgba(139,92,246,0.1)' },
  { id: 'bound', label: 'Bound', color: '#22C55E', bgColor: 'rgba(34,197,94,0.1)' },
]

// ── UTILITY FUNCTIONS ──────────────────────────────────────────────────────
function calculateUrgency(daysLeft?: number): {
  severity: 'overdue' | 'critical' | 'warning' | 'ok'
  color: string
  label: string
} {
  if (!daysLeft) return { severity: 'ok', color: '#22C55E', label: '—' }
  if (daysLeft < 0) return { severity: 'overdue', color: '#EF4444', label: `${Math.abs(daysLeft)}d OVERDUE` }
  if (daysLeft <= 7) return { severity: 'critical', color: '#EF4444', label: `${daysLeft}d URGENT` }
  if (daysLeft <= 14) return { severity: 'warning', color: '#F59E0B', label: `${daysLeft}d ACTION` }
  return { severity: 'ok', color: '#22C55E', label: `${daysLeft}d OK` }
}

function getStatusColor(status: string): (typeof STATUSES[0]) | undefined {
  return STATUSES.find(s => s.id === status)
}

// ── COMPONENTS ─────────────────────────────────────────────────────────────
function WorkflowCard({
  item,
  onClick,
}: {
  item: WorkflowItem
  onClick?: () => void
}) {
  const urgency = calculateUrgency(item.daysUntilExpiry)
  const icon = item.type === 'renewal' ? '🔄' : '📋'

  return (
    <div
      style={{
        background: BG2,
        border: `1px solid ${BD}`,
        borderRadius: 8,
        padding: '10px 12px',
        cursor: 'pointer',
        transition: 'all 0.2s',
        fontFamily: FONT,
      }}
      onClick={onClick}
      onMouseEnter={(e) => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = 'rgba(255,255,255,0.12)'
        el.style.background = BG3
      }}
      onMouseLeave={(e) => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = BD
        el.style.background = BG2
      }}
    >
      {/* Type Badge */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
        <span style={{ fontSize: 12 }}>{icon}</span>
        <span
          style={{
            fontSize: 8,
            fontWeight: 600,
            letterSpacing: '0.5px',
            textTransform: 'uppercase',
            background: 'rgba(255,255,255,0.05)',
            color: T3,
            padding: '2px 5px',
            borderRadius: 3,
          }}
        >
          {item.type}
        </span>
      </div>

      {/* Client Name */}
      <div
        style={{
          fontSize: 12,
          fontWeight: 600,
          color: TEXT,
          marginBottom: 4,
          lineHeight: 1.3,
          maxHeight: '2.4em',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical' as any,
        }}
      >
        {item.clientName}
      </div>

      {/* Policy/Tracking Number */}
      <div style={{ fontSize: 9, color: T3, marginBottom: 6, fontFamily: 'monospace' }}>
        {item.policyNumber || item.trackingNumber || '—'}
      </div>

      {/* Coverage Type */}
      <div
        style={{
          fontSize: 9,
          color: T2,
          marginBottom: 6,
          textTransform: 'capitalize',
        }}
      >
        {item.policyType}
      </div>

      {/* Carrier */}
      <div
        style={{
          fontSize: 9,
          color: T3,
          marginBottom: 8,
          maxHeight: '1.2em',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}
      >
        {item.carrier && item.carrier !== '—' ? item.carrier : '—'}
      </div>

      {/* Premium & Urgency Row */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderTop: `1px solid ${BD}`,
          paddingTop: 8,
        }}
      >
        <span style={{ fontSize: 10, fontWeight: 600, color: TEXT }}>
          ${item.premium.toLocaleString('en-US', { maximumFractionDigits: 0 })}
        </span>
        <span
          style={{
            fontSize: 8,
            fontWeight: 600,
            letterSpacing: '0.4px',
            textTransform: 'uppercase',
            color: urgency.color,
            padding: '2px 5px',
            background: `${urgency.color}15`,
            borderRadius: 3,
          }}
        >
          {urgency.label}
        </span>
      </div>
    </div>
  )
}

function KanbanColumn({
  status,
  items,
  onCardClick,
}: {
  status: (typeof STATUSES[0])
  items: WorkflowItem[]
  onCardClick?: (item: WorkflowItem) => void
}) {
  return (
    <div
      style={{
        flex: '0 0 300px',
        background: BG2,
        border: `1px solid ${BD}`,
        borderRadius: 12,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        fontFamily: FONT,
      }}
    >
      {/* Column Header */}
      <div
        style={{
          padding: '12px 14px',
          background: status.bgColor,
          borderBottom: `1px solid ${BD}`,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span
            style={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              background: status.color,
              flexShrink: 0,
            }}
          />
          <span
            style={{
              fontSize: 12,
              fontWeight: 600,
              color: TEXT,
              textTransform: 'capitalize',
            }}
          >
            {status.label}
          </span>
        </div>
        <span
          style={{
            fontSize: 10,
            fontWeight: 600,
            background: BG3,
            color: T3,
            padding: '2px 8px',
            borderRadius: 6,
          }}
        >
          {items.length}
        </span>
      </div>

      {/* Cards Container */}
      <div
        style={{
          flex: 1,
          overflow: 'auto',
          padding: '10px',
          display: 'flex',
          flexDirection: 'column',
          gap: 8,
          minHeight: '400px',
        }}
      >
        {items.length === 0 ? (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: T3,
              fontSize: 11,
              fontStyle: 'italic',
              textAlign: 'center',
              flex: 1,
              paddingY: 20,
            }}
          >
            No items
          </div>
        ) : (
          items.map((item) => (
            <WorkflowCard
              key={item.id}
              item={item}
              onClick={() => onCardClick?.(item)}
            />
          ))
        )}
      </div>

      {/* Add Card Button */}
      <div
        style={{
          padding: '10px 14px',
          borderTop: `1px solid ${BD}`,
          background: 'transparent',
          cursor: 'pointer',
          fontSize: 11,
          fontWeight: 600,
          color: status.color,
          textAlign: 'center',
          transition: 'background 0.2s',
        }}
        onMouseEnter={(e) => {
          const el = e.currentTarget as HTMLDivElement
          el.style.background = status.bgColor
        }}
        onMouseLeave={(e) => {
          const el = e.currentTarget as HTMLDivElement
          el.style.background = 'transparent'
        }}
      >
        + Add Item
      </div>
    </div>
  )
}

// ── MAIN COMPONENT ─────────────────────────────────────────────────────────
interface WorkflowKanbanProps {
  onCardClick?: (item: WorkflowItem) => void
  refreshKey?: number
}

export default function WorkflowKanban({ onCardClick, refreshKey }: WorkflowKanbanProps) {
  const [items, setItems] = useState<WorkflowItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchItems = async () => {
      try {
        setLoading(true)
        setError(null)
        const res = await fetch('/api/workflow-items?limit=100&sortBy=expiryDate&order=asc')
        if (!res.ok) throw new Error(`Status ${res.status}`)
        const data = await res.json()
        setItems(data.items || [])
      } catch (err) {
        console.error('Failed to fetch workflow items:', err)
        setError(String(err))
        setItems([])
      } finally {
        setLoading(false)
      }
    }

    fetchItems()
  }, [refreshKey])

  if (loading) {
    return (
      <div
        style={{
          padding: '40px',
          textAlign: 'center',
          color: T3,
          fontFamily: FONT,
        }}
      >
        <div style={{ fontSize: 12, marginBottom: 8 }}>Loading workflow items...</div>
        <div style={{ fontSize: 11, opacity: 0.7 }}>↻</div>
      </div>
    )
  }

  if (error) {
    return (
      <div
        style={{
          padding: '20px',
          background: 'rgba(239,68,68,0.05)',
          border: '1px solid rgba(239,68,68,0.2)',
          borderRadius: 8,
          color: '#EF4444',
          fontSize: 11,
          fontFamily: FONT,
        }}
      >
        <div style={{ fontWeight: 600, marginBottom: 4 }}>Error loading items</div>
        <div style={{ opacity: 0.8 }}>{error}</div>
      </div>
    )
  }

  return (
    <div
      style={{
        display: 'flex',
        gap: 12,
        overflowX: 'auto',
        paddingRight: '20px',
        fontFamily: FONT,
      }}
    >
      {STATUSES.map((status) => {
        const columnItems = items.filter((i) => i.status === status.id)
        return (
          <KanbanColumn
            key={status.id}
            status={status}
            items={columnItems}
            onCardClick={onCardClick}
          />
        )
      })}
    </div>
  )
}
