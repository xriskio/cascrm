# CASURANCE CRM DASHBOARD REFACTOR - DEPLOYMENT GUIDE

**Date:** June 15, 2026  
**Scope:** Next.js + Supabase dashboard overhaul  
**Estimated time:** 1-2 hours (code deployment only, testing excluded)

---

## OVERVIEW

This guide walks you through deploying the unified workflow dashboard refactor.

**What's changing:**
- ✅ **New:** Unified API endpoint `/api/workflow-items` (merges renewals + submissions)
- ✅ **New:** `WorkflowKanban.tsx` (kanban view, replaces RenewalTable + QuotesPipeline)
- ✅ **New:** `MetricBar.tsx` (sticky metrics header, replaces StatCards)
- ✅ **Refactored:** `DashboardPage.tsx` (cleaner layout, removes clutter)
- ⚠️ **Removed:** RenewalTable, QuotesPipeline, StatCards, TaskPanel, AiInsightsStrip
- ✅ **Kept:** Sidebar, Topbar, ActivityFeed (relocated), NewSubmissionModal

**Files provided:**
```
✓ workflow-items-route.ts       → /app/api/workflow-items/route.ts
✓ WorkflowKanban.tsx            → /components/dashboard/WorkflowKanban.tsx
✓ MetricBar.tsx                 → /components/dashboard/MetricBar.tsx
✓ DashboardPage-refactored.tsx  → /components/dashboard/DashboardPage.tsx (REPLACE)
```

---

## PHASE 1: BACKUP (5 minutes)

Before making changes, commit everything to GitHub:

```bash
cd ~/CASURANCE-CRM-PROJECT  # Your repo root

# Verify clean working directory
git status

# If there are uncommitted changes:
git add -A
git commit -m "pre-refactor: backup dashboard before kanban migration"

# Create backup branch
git checkout -b dashboard-refactor-backup
git push origin dashboard-refactor-backup

# Return to main branch
git checkout main
```

---

## PHASE 2: API ROUTE (5 minutes)

### Step 1: Create directory

```bash
mkdir -p app/api/workflow-items
```

### Step 2: Add the API file

Copy the contents of **`workflow-items-route.ts`** into a new file:

**Path:** `app/api/workflow-items/route.ts`

```bash
# If you prefer command line:
cat > app/api/workflow-items/route.ts << 'EOF'
[PASTE ENTIRE CONTENTS OF workflow-items-route.ts HERE]
EOF
```

### Step 3: Verify import paths

The file imports from `@/lib/supabase/admin`. Verify this exists:

```bash
ls -la lib/supabase/admin.ts
```

If it doesn't exist, check your actual supabase setup file and adjust the import on line 3:

```typescript
import { supabaseAdmin } from "@/lib/supabase/admin"  // ← Adjust path if needed
```

### Step 4: Test the endpoint

```bash
# Local: Start dev server if not running
npm run dev

# Then test in another terminal (replace with your port):
curl "http://localhost:3000/api/workflow-items?limit=10"

# Or in browser:
# http://localhost:3000/api/workflow-items?limit=10

# Expected response:
# {
#   "items": [...],
#   "metrics": {
#     "total": N,
#     "byStatus": {"pending": X, ...},
#     "overdue": Y,
#     "urgent": Z
#   },
#   "pagination": {"limit": 10, "returned": N}
# }
```

**If it fails:**
- Check Supabase connection string in `.env.local`
- Verify `renewals` and `submissions` tables exist
- Check browser console for error details

---

## PHASE 3: COMPONENTS (10 minutes)

### Step 1: Add WorkflowKanban

Copy `WorkflowKanban.tsx` into:  
**Path:** `components/dashboard/WorkflowKanban.tsx`

```bash
# Verify no import errors by checking React/Next imports:
grep "from 'react'" components/dashboard/WorkflowKanban.tsx
# Should see: import { useState, useEffect } from 'react'
```

### Step 2: Add MetricBar

Copy `MetricBar.tsx` into:  
**Path:** `components/dashboard/MetricBar.tsx`

```bash
# Same React check
grep "from 'react'" components/dashboard/MetricBar.tsx
```

### Step 3: Replace DashboardPage

**CRITICAL: Backup first**

```bash
# Backup existing
cp components/dashboard/DashboardPage.tsx components/dashboard/DashboardPage.tsx.backup

# Replace with new version
cp DashboardPage-refactored.tsx components/dashboard/DashboardPage.tsx
```

Verify the new file has correct imports:

```bash
grep "^import.*from" components/dashboard/DashboardPage.tsx | head -10
```

Should see imports for:
- Sidebar, Topbar, MetricBar, WorkflowKanban, ActivityFeed, NewSubmissionModal

---

## PHASE 4: VERIFY BUILD (10 minutes)

### Step 1: Dev server check

```bash
# If dev server is running, check for build errors in terminal

# Or restart:
npm run dev

# Watch for build errors (they'll appear in red)
```

### Step 2: Browser test

Open http://localhost:3000/dashboard

**What you should see:**
1. ✅ Sidebar (left)
2. ✅ Topbar (top) with "New Submission" button
3. ✅ MetricBar (gray box with Total, Pending, In Review, Bound, Overdue, Urgent)
4. ✅ Kanban board (4 columns: Pending, In Review, Awaiting UW, Bound)
5. ✅ ActivityFeed (bottom)

**What should NOT be visible:**
- ❌ StatCards (4 KPI cards)
- ❌ RenewalTable
- ❌ QuotesPipeline
- ❌ TaskPanel (right sidebar)
- ❌ AiInsightsStrip

### Step 3: Functional test

**Test kanban:**
1. Click a card → Side panel opens on right
2. See client name, policy type, status selector, premium
3. Click status button → Updates panel (no real update yet, UI only)
4. Click "Close" → Panel closes

**Test metric bar:**
1. Click the collapse button (−) → Collapses to 1 line
2. Click again (+) → Expands back

**Test filters:**
1. (Optional) If you add search/filter buttons to Topbar, they should work

**If kanban is empty:**
- This is OK for dev environment
- Check `/api/workflow-items` directly in browser to debug
- The endpoint should return `{ "items": [...], "metrics": {...} }`

---

## PHASE 5: CLEANUP (10 minutes)

### Step 1: Remove old components (optional but recommended)

You can now delete these unused files (safe to remove):

```bash
# These are fully replaced by WorkflowKanban
rm components/dashboard/RenewalTable.tsx
rm components/dashboard/QuotesPipeline.tsx

# StatCards replaced by MetricBar
rm components/dashboard/StatCards.tsx

# TaskPanel no longer used (can integrate to sidebar nav later)
rm components/dashboard/TaskPanel.tsx

# AI Insights was placeholder
rm components/dashboard/AiInsightsStrip.tsx (if separate file)
```

### Step 2: Clean imports

Check if DashboardPage still has any unused imports:

```bash
head -30 components/dashboard/DashboardPage.tsx | grep "^import"
```

Remove any imports for deleted components (should be none if you used the refactored version).

### Step 3: Git commit

```bash
git add -A
git commit -m "feat: unified workflow kanban dashboard

- Add /api/workflow-items endpoint (renewals + submissions merged)
- Add WorkflowKanban component (replaces RenewalTable + QuotesPipeline)
- Add MetricBar component (replaces StatCards)
- Refactor DashboardPage (cleaner layout, removes clutter)
- Remove unused: RenewalTable, QuotesPipeline, StatCards, TaskPanel, AiInsightsStrip"
```

---

## PHASE 6: PRODUCTION DEPLOYMENT (5 minutes)

### Step 1: Push to GitHub

```bash
git push origin main
```

### Step 2: Deploy to Railway

Railway should auto-detect the changes (assuming GitHub integration is working).

**If not:**
1. Go to Railway dashboard
2. Click your project (CASURANCE or XRISK)
3. Go to "Deployments" tab
4. Click "Deploy" or "Redeploy"
5. Wait for build to complete

**Monitor:**
- ✅ Build logs should show "next build" succeeding
- ✅ No TypeScript errors
- ✅ Deploy logs show "Server running on port 3000"

### Step 3: Test production

1. Open your production dashboard URL
2. Run the same functional tests as Phase 4, Step 3

---

## PHASE 7: ADVANCED FEATURES (Optional, Phase 2)

After the initial deployment, you can add:

### Add Drag-Drop Kanban
Install: `npm install react-beautiful-dnd` (or framer-motion)

Replace WorkflowKanban rendering with drag-drop handlers.

### Add Status Change API
Uncomment the TODO in DashboardPage (line ~215):

```typescript
const handleStatusChange = useCallback(
  (itemId: string, newStatus: string) => {
    showToast(`Status updated to "${newStatus}"`)
    // TODO: Uncomment this:
    // await fetch(`/api/workflow-items/${itemId}`, {
    //   method: 'PATCH',
    //   body: JSON.stringify({ status: newStatus })
    // })
    setRefreshKey((k) => k + 1)
  },
  [showToast]
)
```

Create `/app/api/workflow-items/[id]/route.ts` with PATCH handler.

### Add Table View Toggle
Add a button in Topbar:
```typescript
const [view, setView] = useState<'kanban' | 'table'>('kanban')

// In render:
{view === 'kanban' ? <WorkflowKanban /> : <WorkflowTable />}
```

Create `WorkflowTable.tsx` (same data, table layout).

### Add Bulk Actions
Select multiple cards, show toolbar:
- Archive selected
- Assign to agent
- Change status
- Export CSV

---

## TROUBLESHOOTING

### Issue: Build fails with "Cannot find module @/components/dashboard/StatCards"

**Cause:** You haven't replaced DashboardPage.tsx yet, or the new version has old imports.

**Fix:**
```bash
# Use the refactored version
cp DashboardPage-refactored.tsx components/dashboard/DashboardPage.tsx
```

### Issue: Kanban shows "No items" even with data in database

**Cause:** API endpoint not returning data

**Debug:**
```bash
# Test the API directly
curl "http://localhost:3000/api/workflow-items?limit=100"

# Check response:
# - Does "items" array have data?
# - Are "renewals" and "submissions" tables populated?
# - Does Supabase connection string work?
```

### Issue: TypeError: Cannot read property 'map' of undefined (in browser console)

**Cause:** API returned `null` for items instead of array

**Fix:**
```typescript
// In WorkflowKanban.tsx, line ~150:
const columnItems = (items || []).filter(i => i.status === status.id)
// Add || [] fallback
```

### Issue: Styles look broken (wrong colors, layout)

**Cause:** CSS variable names changed or Tailwind not loading

**Fix:**
```bash
# Ensure no Tailwind conflicts
grep "className=" components/dashboard/WorkflowKanban.tsx
# Should be empty (we use inline styles, not Tailwind classes)

# If you see className, remove them and use style={} instead
```

### Issue: Sidebar/Topbar missing on production

**Cause:** Stale cache

**Fix:**
```bash
# Clear cache
rm -rf .next
npm run build
npm run dev

# Or on Railway:
# Settings → "Clear all" under Build & Deploy → Redeploy
```

---

## VERIFICATION CHECKLIST

Use this before marking as "done":

- [ ] API endpoint `/api/workflow-items?limit=10` returns valid JSON
- [ ] Kanban board renders 4 columns (Pending, In Review, Awaiting UW, Bound)
- [ ] Clicking a card opens detail panel on right
- [ ] Clicking close button closes panel
- [ ] MetricBar shows correct counts (Total, Pending, Overdue, etc.)
- [ ] Metric bar collapse button works (− / +)
- [ ] ActivityFeed renders at bottom (may be empty if no activity)
- [ ] No console errors (check browser DevTools)
- [ ] No TypeScript build errors
- [ ] Mobile responsive (kanban scrolls horizontally on small screens)
- [ ] Production deploy completes without errors

---

## NEXT STEPS

After deployment:

1. **Gather feedback** → Does the unified workflow make sense?
2. **Test with real data** → Import renewals/submissions from QQCatalyst
3. **Add status updates** → Wire the PATCH endpoint to actually update database
4. **Add drag-drop** → Make kanban fully interactive
5. **Add table view** → Let power users toggle to sortable table
6. **Add bulk actions** → Select multiple cards, archive/assign/email

---

## SUPPORT

If you hit issues:

1. **Check the audit doc** → `cascrm-audit-refactor.md` (full architecture)
2. **Check browser console** → Errors will be logged there
3. **Check Railway logs** → Build errors appear in Deploy logs
4. **Test API directly** → `curl "http://localhost:3000/api/workflow-items"`

---

**END OF DEPLOYMENT GUIDE**
