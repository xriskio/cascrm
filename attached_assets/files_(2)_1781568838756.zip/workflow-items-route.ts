// File: /app/api/workflow-items/route.ts
// Purpose: Unified endpoint returning renewals + submissions as single "WorkflowItem" stream
// Deploy: Copy to app/api/workflow-items/route.ts, create directory if needed

import { type NextRequest, NextResponse } from "next/server"
import { supabaseAdmin } from "@/lib/supabase/admin"

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// ── TYPES ──────────────────────────────────────────────────────────────────
export interface WorkflowItem {
  id: string
  type: 'renewal' | 'submission'
  clientName: string
  policyNumber?: string
  trackingNumber?: string
  status: string
  priority?: string
  policyType: string
  carrier?: string
  premium: number
  quotedPremium?: number
  expiryDate?: string
  daysUntilExpiry?: number
  createdAt: string
  updatedAt: string
  assignedAgent?: string
}

// ── UTILITIES ──────────────────────────────────────────────────────────────
function calculateDaysUntilExpiry(expiryDate: string | null): number | undefined {
  if (!expiryDate) return undefined
  const expiry = new Date(expiryDate)
  const now = new Date()
  const diffMs = expiry.getTime() - now.getTime()
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24))
}

// ── GET HANDLER ────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = supabaseAdmin
    const { searchParams } = new URL(request.url)

    // Query parameters
    const status = searchParams.get('status')
    const type = searchParams.get('type') // 'renewal' | 'submission' | 'all'
    const limit = Math.min(parseInt(searchParams.get('limit') || '100'), 500)
    const sortBy = searchParams.get('sortBy') || 'expiryDate' // expiryDate | createdAt | premium
    const order = searchParams.get('order') || 'asc'

    // Fetch renewals
    let renewalsQuery = supabase
      .from('renewals')
      .select(
        'id, policy_number, named_insured, policy_type, carrier, status, premium, expiration_date, created_at, updated_at, agent_name',
        { count: 'exact' }
      )
      .eq('archived', false)

    if (status) {
      renewalsQuery = renewalsQuery.eq('status', status)
    }
    if (type && type !== 'all') {
      if (type !== 'renewal') renewalsQuery = renewalsQuery.limit(0)
    }

    const { data: renewals = [], error: renewalError } = await renewalsQuery

    if (renewalError) {
      console.error('Renewals query error:', renewalError)
      return NextResponse.json({ error: 'Failed to fetch renewals', details: renewalError.message }, { status: 500 })
    }

    // Fetch submissions
    let submissionsQuery = supabase
      .from('submissions')
      .select(
        'id, tracking_number, client_name, policy_type, carrier, status, quoted_premium, expiration_date, created_at, updated_at, assigned_agent',
        { count: 'exact' }
      )
      .neq('status', 'declined')

    if (status) {
      submissionsQuery = submissionsQuery.eq('status', status)
    }
    if (type && type !== 'all') {
      if (type !== 'submission') submissionsQuery = submissionsQuery.limit(0)
    }

    const { data: submissions = [], error: submissionError } = await submissionsQuery

    if (submissionError) {
      console.error('Submissions query error:', submissionError)
      return NextResponse.json({ error: 'Failed to fetch submissions', details: submissionError.message }, { status: 500 })
    }

    // ── TRANSFORM ──────────────────────────────────────────────────────────
    const renewalItems: WorkflowItem[] = renewals.map((r: any) => {
      const daysUntilExpiry = calculateDaysUntilExpiry(r.expiration_date)
      return {
        id: r.id,
        type: 'renewal',
        clientName: r.named_insured || '—',
        policyNumber: r.policy_number,
        status: r.status || 'pending',
        policyType: r.policy_type || '—',
        carrier: r.carrier || '—',
        premium: parseFloat(r.premium) || 0,
        expiryDate: r.expiration_date,
        daysUntilExpiry,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
        assignedAgent: r.agent_name,
      }
    })

    const submissionItems: WorkflowItem[] = submissions.map((s: any) => {
      const daysUntilExpiry = calculateDaysUntilExpiry(s.expiration_date)
      return {
        id: s.id,
        type: 'submission',
        clientName: s.client_name || '—',
        trackingNumber: s.tracking_number,
        status: s.status || 'pending',
        policyType: s.policy_type || '—',
        carrier: s.carrier || '—',
        premium: parseFloat(s.quoted_premium) || 0,
        quotedPremium: parseFloat(s.quoted_premium),
        expiryDate: s.expiration_date,
        daysUntilExpiry,
        createdAt: s.created_at,
        updatedAt: s.updated_at,
        assignedAgent: s.assigned_agent,
      }
    })

    // ── MERGE & SORT ───────────────────────────────────────────────────────
    let items = [...renewalItems, ...submissionItems]

    // Apply sorting
    if (sortBy === 'expiryDate') {
      items.sort((a, b) => {
        const aDate = a.expiryDate ? new Date(a.expiryDate).getTime() : Infinity
        const bDate = b.expiryDate ? new Date(b.expiryDate).getTime() : Infinity
        return order === 'asc' ? aDate - bDate : bDate - aDate
      })
    } else if (sortBy === 'premium') {
      items.sort((a, b) => (order === 'asc' ? a.premium - b.premium : b.premium - a.premium))
    } else if (sortBy === 'createdAt') {
      items.sort((a, b) => {
        const aDate = new Date(a.createdAt).getTime()
        const bDate = new Date(b.createdAt).getTime()
        return order === 'asc' ? aDate - bDate : bDate - aDate
      })
    }

    // Apply limit
    items = items.slice(0, limit)

    // ── COMPUTE METRICS ───────────────────────────────────────────────────
    const metrics = {
      total: items.length,
      byStatus: {} as Record<string, number>,
      byType: { renewal: renewalItems.length, submission: submissionItems.length },
      overdue: items.filter(i => i.daysUntilExpiry !== undefined && i.daysUntilExpiry < 0).length,
      urgent: items.filter(i => i.daysUntilExpiry !== undefined && i.daysUntilExpiry >= 0 && i.daysUntilExpiry <= 7).length,
    }

    items.forEach(i => {
      metrics.byStatus[i.status] = (metrics.byStatus[i.status] || 0) + 1
    })

    return NextResponse.json(
      {
        items,
        metrics,
        pagination: { limit, returned: items.length },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Workflow items error:', error)
    return NextResponse.json(
      { error: 'Internal server error', message: String(error) },
      { status: 500 }
    )
  }
}
