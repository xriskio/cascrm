'use client';

/**
 * RenewalPanel.tsx
 * ─────────────────────────────────────────────────────────────────
 * Self-contained 60-day renewal workspace. Fixed height, scrollable
 * internally. Shows timeline bar, urgency chips, inline status
 * dropdown, per-row progress bars, and auto-refreshes every 60s.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { daysUntil } from '@/lib/store';
import type { Renewal, RenewalStatus } from '@/types';

// ── CONSTANTS ─────────────────────────────────────────────────────────────────
const WINDOW_DAYS = 60;
const STATUS_OPTIONS: RenewalStatus[] = ['Pending', 'In Progress', 'Quoted', 'Cancelled'];

const STATUS_COLORS: Record<RenewalStatus, string> = {
  'Pending':     'var(--amber)',
  'In Progress': 'var(--blue)',
  'Quoted':      'var(--green)',
  'Cancelled':   'var(--text3)',
};

type FilterTab = 'All' | 'Urgent' | 'Pending' | 'Quoted';

// ── HELPERS ───────────────────────────────────────────────────────────────────
function fmtLong(s?: string): string {
  if (!s) return '—';
  try {
    return new Date(s + 'T00:00:00').toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
    });
  } catch { return s; }
}

function getDayChipStyle(days: number): { bg: string; color: string; border: string; label: string } {
  if (days < 0)  return { bg: 'rgba(239,68,68,0.15)', color: 'var(--red)',   border: '1px solid var(--red-bd)',   label: `Exp. ${Math.abs(days)}d ago` };
  if (days === 0) return { bg: 'var(--red-bg)',        color: 'var(--red)',   border: '1px solid var(--red-bd)',   label: 'TODAY' };
  if (days <= 10) return { bg: 'var(--red-bg)',        color: 'var(--red)',   border: '1px solid var(--red-bd)',   label: `${days}d` };
  if (days <= 20) return { bg: 'var(--amber-bg)',      color: 'var(--amber)', border: '1px solid var(--amber-bd)', label: `${days}d` };
  return               { bg: 'var(--green-bg)',      color: 'var(--green)', border: '1px solid var(--green-bd)', label: `${days}d` };
}

function getBarColor(days: number): string {
  if (days <= 10) return 'var(--red)';
  if (days <= 20) return 'var(--amber)';
  return 'var(--green)';
}

// ── TIMELINE BAR ──────────────────────────────────────────────────────────────
function TimelineBar({ renewals }: { renewals: Renewal[] }) {
  const slots = Array(WINDOW_DAYS).fill(0);
  renewals.forEach(r => {
    const d = daysUntil(r.expiryDate);
    if (d >= 0 && d < WINDOW_DAYS) slots[d]++;
  });

  return (
    <div style={{
      flexShrink: 0, padding: '8px 16px 6px',
      borderBottom: '1px solid var(--border)',
      display: 'flex', alignItems: 'center', gap: 6,
    }}>
      <span style={{ fontSize: 9.5, color: 'var(--text3)', fontFamily: 'var(--mono)', flexShrink: 0 }}>
        Today
      </span>
      <div style={{ flex: 1, height: 5, background: 'var(--bg3)', borderRadius: 3, overflow: 'hidden', display: 'flex', gap: 1 }}>
        {slots.map((count, i) => {
          const color = i <= 10 ? 'var(--red)' : i <= 20 ? 'var(--amber)' : 'var(--green)';
          return (
            <div
              key={i}
              title={count ? `${count} renewal(s) on day ${i}` : undefined}
              style={{
                flex: 1, height: '100%',
                background: count ? color : 'var(--bg4)',
                opacity: count ? 1 : 0.3,
                borderRadius: 1,
                transition: 'opacity 0.2s',
              }}
            />
          );
        })}
      </div>
      <span style={{ fontSize: 9.5, color: 'var(--text3)', fontFamily: 'var(--mono)', flexShrink: 0 }}>
        +60d
      </span>
    </div>
  );
}

// ── SUMMARY CHIPS ─────────────────────────────────────────────────────────────
function SummaryBar({ renewals, onFilter }: { renewals: Renewal[]; onFilter: (f: FilterTab) => void }) {
  const expired  = renewals.filter(r => daysUntil(r.expiryDate) < 0).length;
  const critical = renewals.filter(r => { const d = daysUntil(r.expiryDate); return d >= 0 && d <= 10; }).length;
  const urgent   = renewals.filter(r => { const d = daysUntil(r.expiryDate); return d > 10 && d <= 20; }).length;
  const upcoming = renewals.filter(r => daysUntil(r.expiryDate) > 20).length;

  const chips = [
    expired  && { label: `⚠ ${expired} Expired`,      bg: 'rgba(239,68,68,0.15)', color: 'var(--red)',   bd: 'var(--red-bd)',   filter: 'Urgent' as FilterTab },
    critical && { label: `🔴 ${critical} Critical ≤10d`, bg: 'var(--red-bg)',      color: 'var(--red)',   bd: 'var(--red-bd)',   filter: 'Urgent' as FilterTab },
    urgent   && { label: `🟡 ${urgent} Urgent ≤20d`,    bg: 'var(--amber-bg)',     color: 'var(--amber)', bd: 'var(--amber-bd)', filter: 'Urgent' as FilterTab },
    upcoming && { label: `🟢 ${upcoming} Upcoming`,     bg: 'var(--green-bg)',     color: 'var(--green)', bd: 'var(--green-bd)', filter: 'All' as FilterTab },
  ].filter(Boolean) as { label: string; bg: string; color: string; bd: string; filter: FilterTab }[];

  if (!chips.length) return null;

  return (
    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 4 }}>
      {chips.map(chip => (
        <SummaryChip key={chip.label} chip={chip} onClick={() => onFilter(chip.filter)} />
      ))}
    </div>
  );
}

function SummaryChip({ chip, onClick }: { chip: { label: string; bg: string; color: string; bd: string }; onClick: () => void }) {
  const [h, setH] = useState(false);
  return (
    <span
      onClick={onClick}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        fontSize: 9.5, fontWeight: 600, padding: '2px 7px', borderRadius: 10,
        background: chip.bg, color: chip.color, border: `1px solid ${chip.bd}`,
        cursor: 'pointer', opacity: h ? 0.8 : 1, transition: 'opacity 0.1s',
      }}
    >
      {chip.label}
    </span>
  );
}

// ── INLINE STATUS DROPDOWN ────────────────────────────────────────────────────
function StatusDropdown({
  renewal, onStatusChange,
}: {
  renewal: Renewal;
  onStatusChange: (id: string, status: RenewalStatus) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const dotColor = STATUS_COLORS[renewal.status] ?? 'var(--amber)';

  return (
    <div ref={ref} style={{ position: 'relative', display: 'inline-block' }}>
      {/* Trigger */}
      <div
        onClick={e => { e.stopPropagation(); setOpen(o => !o); }}
        style={{
          display: 'flex', alignItems: 'center', gap: 5,
          fontSize: 11, color: 'var(--text2)', cursor: 'pointer',
          padding: '3px 6px', borderRadius: 6,
          background: open ? 'var(--bg4)' : 'transparent',
          border: open ? '1px solid var(--border2)' : '1px solid transparent',
          transition: 'all 0.1s',
          userSelect: 'none',
        }}
      >
        <span style={{ width: 5, height: 5, borderRadius: '50%', background: dotColor, flexShrink: 0 }} />
        {renewal.status}
        <span style={{ fontSize: 8, color: 'var(--text3)', marginLeft: 1 }}>▾</span>
      </div>

      {/* Dropdown */}
      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 4px)', left: 0,
          background: 'var(--bg3)', border: '1px solid var(--border2)',
          borderRadius: 'var(--r)', boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
          zIndex: 50, minWidth: 140, overflow: 'hidden',
          animation: 'dropIn 0.12s ease',
        }}>
          {STATUS_OPTIONS.map(s => (
            <StatusOption
              key={s}
              status={s}
              active={renewal.status === s}
              onClick={() => {
                onStatusChange(renewal.id, s);
                setOpen(false);
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function StatusOption({ status, active, onClick }: { status: RenewalStatus; active: boolean; onClick: () => void }) {
  const [h, setH] = useState(false);
  const dot = STATUS_COLORS[status];
  return (
    <div
      onClick={e => { e.stopPropagation(); onClick(); }}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        padding: '7px 12px', fontSize: 11.5, cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 7,
        color: active || h ? 'var(--text)' : 'var(--text2)',
        background: active || h ? 'var(--bg4)' : 'transparent',
        fontWeight: active ? 500 : 400,
        transition: 'all 0.1s',
      }}
    >
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: dot, flexShrink: 0 }} />
      {status}
      {active && <span style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--blue)' }}>✓</span>}
    </div>
  );
}

// ── RENEWAL ROW ───────────────────────────────────────────────────────────────
function RenewalRow({
  renewal, onEdit, onDelete, onStatusChange,
}: {
  renewal: Renewal;
  onEdit: () => void;
  onDelete: () => void;
  onStatusChange: (id: string, status: RenewalStatus) => void;
}) {
  const [h, setH] = useState(false);
  const days      = daysUntil(renewal.expiryDate);
  const isExpired = days < 0;
  const chip      = getDayChipStyle(days);
  const barColor  = getBarColor(days);
  const barPct    = isExpired ? 100 : Math.max(2, Math.round((1 - days / WINDOW_DAYS) * 100));
  const premiumFmt = renewal.premium
    ? ` · $${Number(renewal.premium).toLocaleString()}`
    : '';

  return (
    <div
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        display: 'grid',
        gridTemplateColumns: '1fr 100px 110px 80px 120px 60px',
        alignItems: 'center',
        padding: '10px 16px',
        borderTop: '1px solid var(--border)',
        background: h ? 'var(--bg3)' : isExpired ? 'rgba(239,68,68,0.03)' : 'transparent',
        borderLeft: isExpired ? '2px solid rgba(239,68,68,0.3)' : '2px solid transparent',
        transition: 'background 0.1s',
        cursor: 'default',
      }}
    >
      {/* Client */}
      <div>
        <div style={{
          fontSize: 12.5, fontWeight: 500,
          color: isExpired ? 'var(--red)' : 'var(--text)',
        }}>
          {renewal.clientName}
        </div>
        <div style={{ fontSize: 10, color: 'var(--text3)', marginTop: 2 }}>
          {renewal.policyType}
          {premiumFmt && (
            <span style={{ color: 'var(--text2)', fontFamily: 'var(--mono)' }}>
              {premiumFmt}
            </span>
          )}
        </div>
        {/* Progress bar */}
        <div style={{ width: '100%', height: 3, background: 'var(--bg4)', borderRadius: 2, marginTop: 5, overflow: 'hidden' }}>
          <div style={{
            height: '100%', width: `${barPct}%`,
            background: isExpired ? 'var(--red)' : barColor,
            borderRadius: 2, transition: 'width 0.4s ease',
          }} />
        </div>
      </div>

      {/* Policy ID */}
      <div style={{ fontSize: 10.5, color: 'var(--text2)', fontFamily: 'var(--mono)' }}>
        {renewal.policyId || '—'}
      </div>

      {/* Expiry date */}
      <div style={{ fontSize: 11, color: 'var(--text2)' }}>
        {fmtLong(renewal.expiryDate)}
      </div>

      {/* Days chip */}
      <div>
        <span style={{
          display: 'inline-flex', alignItems: 'center',
          fontSize: days === 0 ? 9 : 10, fontWeight: 700,
          padding: '2px 8px', borderRadius: 20,
          background: chip.bg, color: chip.color, border: chip.border,
          animation: days === 0 ? 'pulse 1s ease infinite' : 'none',
          letterSpacing: days === 0 ? '0.3px' : 'normal',
        }}>
          {chip.label}
        </span>
      </div>

      {/* Status dropdown */}
      <StatusDropdown renewal={renewal} onStatusChange={onStatusChange} />

      {/* Row actions — always visible */}
      <div style={{ display: 'flex', gap: 4, opacity: h ? 1 : 0.4, transition: 'opacity 0.15s' }}>
        <ActionBtn title="Edit" onClick={onEdit}>✎</ActionBtn>
        <ActionBtn title="Delete" danger onClick={onDelete}>✕</ActionBtn>
      </div>
    </div>
  );
}

function ActionBtn({ children, title, danger, onClick }: {
  children: React.ReactNode; title: string; danger?: boolean; onClick: () => void;
}) {
  const [h, setH] = useState(false);
  return (
    <button
      title={title}
      onClick={e => { e.stopPropagation(); onClick(); }}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        width: 24, height: 24, borderRadius: 5, cursor: 'pointer',
        border: h && danger ? '1px solid var(--red-bd)' : '1px solid var(--border2)',
        background: h ? (danger ? 'var(--red-bg)' : 'var(--bg4)') : 'transparent',
        color: h ? (danger ? 'var(--red)' : 'var(--text)') : 'var(--text3)',
        fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all 0.1s', fontFamily: 'var(--font)',
      }}
    >
      {children}
    </button>
  );
}

// ── FILTER TABS ───────────────────────────────────────────────────────────────
const FILTER_TABS: FilterTab[] = ['All', 'Urgent', 'Pending', 'Quoted'];

function FilterTabs({ active, onChange }: { active: FilterTab; onChange: (f: FilterTab) => void }) {
  return (
    <div style={{
      display: 'flex', background: 'var(--bg3)', borderRadius: 6,
      padding: 2, gap: 1, border: '1px solid var(--border)',
    }}>
      {FILTER_TABS.map(tab => (
        <button
          key={tab}
          onClick={() => onChange(tab)}
          style={{
            padding: '3px 8px', fontSize: 10.5, fontWeight: 500,
            borderRadius: 4, cursor: 'pointer', fontFamily: 'var(--font)',
            border: active === tab ? '1px solid var(--border2)' : 'none',
            background: active === tab ? 'var(--bg4)' : 'transparent',
            color: active === tab ? 'var(--text)' : 'var(--text3)',
            transition: 'all 0.1s',
          }}
        >
          {tab}
        </button>
      ))}
    </div>
  );
}

// ── ADD BUTTON ────────────────────────────────────────────────────────────────
function AddBtn({ onClick }: { onClick: () => void }) {
  const [h, setH] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 5,
        padding: '0 9px', height: 26,
        background: 'var(--blue)', color: '#fff',
        border: 'none', borderRadius: 'var(--r)',
        fontFamily: 'var(--font)', fontSize: 10.5, fontWeight: 500,
        cursor: 'pointer', opacity: h ? 0.88 : 1,
        boxShadow: '0 0 12px rgba(59,130,246,0.25)',
        transition: 'opacity 0.1s', whiteSpace: 'nowrap',
      }}
    >
      + Add
    </button>
  );
}

// ── LIVE DOT ──────────────────────────────────────────────────────────────────
function LiveDot() {
  return (
    <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 9.5, color: 'var(--text3)' }}>
      <span style={{
        width: 5, height: 5, borderRadius: '50%', background: 'var(--green)',
        display: 'inline-block', animation: 'pulse 2s ease infinite',
      }} />
      Live
    </span>
  );
}

// ── MAIN COMPONENT ────────────────────────────────────────────────────────────
interface RenewalPanelProps {
  renewals: Renewal[];
  onAdd: () => void;
  onEdit: (r: Renewal) => void;
  onDelete: (r: Renewal) => void;
  onStatusChange: (id: string, status: RenewalStatus) => void;
}

export default function RenewalPanel({
  renewals, onAdd, onEdit, onDelete, onStatusChange,
}: RenewalPanelProps) {
  const [filter, setFilter]   = useState<FilterTab>('All');
  const [tick, setTick]       = useState(0);   // forces re-render on interval
  const [lastRefresh, setLastRefresh] = useState('');

  // Auto-refresh every 60 seconds to keep days-remaining counts live
  useEffect(() => {
    const id = setInterval(() => {
      setTick(t => t + 1);
      setLastRefresh(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
    }, 60_000);
    setLastRefresh(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
    return () => clearInterval(id);
  }, []);

  // Filter to 60-day window
  const within60 = renewals.filter(r => daysUntil(r.expiryDate) <= WINDOW_DAYS);

  // Apply tab filter
  const visible = within60.filter(r => {
    const days = daysUntil(r.expiryDate);
    const s    = r.status;
    if (filter === 'Urgent')  return days <= 20;
    if (filter === 'Pending') return s === 'Pending' || s === 'In Progress';
    if (filter === 'Quoted')  return s === 'Quoted';
    return true;
  }).sort((a, b) => daysUntil(a.expiryDate) - daysUntil(b.expiryDate));

  const outsideCount = renewals.filter(r => daysUntil(r.expiryDate) > WINDOW_DAYS).length;

  const handleFilter = useCallback((f: FilterTab) => setFilter(f), []);

  return (
    <div
      id="renewals-section"
      style={{
        background: 'var(--bg2)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--rl)',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        height: 420,
        transition: 'border-color 0.15s',
      }}
    >
      {/* ── HEADER ── */}
      <div style={{
        flexShrink: 0, display: 'flex', alignItems: 'flex-start',
        padding: '12px 16px', borderBottom: '1px solid var(--border)', gap: 10,
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1 }}>
          {/* Title row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, letterSpacing: '-0.2px' }}>
              Upcoming Renewals
            </div>
            <span style={{
              fontSize: 10, fontWeight: 500, background: 'var(--bg3)',
              color: 'var(--text3)', padding: '1px 6px', borderRadius: 20,
              border: '1px solid var(--border)',
            }}>
              {renewals.length} total
            </span>
            <span style={{
              fontSize: 9.5, fontWeight: 600, padding: '1px 6px', borderRadius: 10,
              background: 'var(--blue-bg)', color: 'var(--blue)',
              border: '1px solid var(--blue-bd)',
            }}>
              Next 60 days
            </span>
          </div>

          {/* Summary chips */}
          <SummaryBar renewals={within60} onFilter={handleFilter} />
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
          <FilterTabs active={filter} onChange={handleFilter} />
          <AddBtn onClick={onAdd} />
        </div>
      </div>

      {/* ── TIMELINE BAR ── */}
      <TimelineBar renewals={within60} />

      {/* ── COLUMN HEADERS ── */}
      <div style={{
        flexShrink: 0,
        display: 'grid',
        gridTemplateColumns: '1fr 100px 110px 80px 120px 60px',
        padding: '7px 16px',
        background: 'var(--bg3)',
        fontSize: 9.5, fontWeight: 600, letterSpacing: '0.6px',
        textTransform: 'uppercase', color: 'var(--text3)',
        borderBottom: '1px solid var(--border)',
      }}>
        <span>Client</span>
        <span>Policy ID</span>
        <span>Expires</span>
        <span>Days Left</span>
        <span>Status</span>
        <span>Actions</span>
      </div>

      {/* ── SCROLLABLE ROWS ── */}
      <div style={{ flex: 1, overflowY: 'auto', minHeight: 0 }}>
        {visible.length === 0 ? (
          <EmptyState
            hasRenewals={renewals.length > 0}
            filter={filter}
            onAdd={onAdd}
          />
        ) : (
          visible.map(r => (
            <RenewalRow
              key={r.id + tick}   // tick ensures re-render on interval
              renewal={r}
              onEdit={() => onEdit(r)}
              onDelete={() => onDelete(r)}
              onStatusChange={onStatusChange}
            />
          ))
        )}
      </div>

      {/* ── FOOTER ── */}
      <div style={{
        flexShrink: 0, display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', padding: '7px 16px',
        borderTop: '1px solid var(--border)', background: 'var(--bg3)',
      }}>
        <span style={{ fontSize: 10, color: 'var(--text3)' }}>
          {visible.length} renewal{visible.length !== 1 ? 's' : ''} in 60-day window
          {outsideCount > 0 && ` · ${outsideCount} beyond 60 days hidden`}
          {' · '}sorted by urgency
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {lastRefresh && (
            <span style={{ fontSize: 9.5, color: 'var(--text3)', fontFamily: 'var(--mono)' }}>
              Updated {lastRefresh}
            </span>
          )}
          <LiveDot />
          <FooterAddBtn onClick={onAdd} />
        </div>
      </div>
    </div>
  );
}

// ── EMPTY STATE ───────────────────────────────────────────────────────────────
function EmptyState({ hasRenewals, filter, onAdd }: {
  hasRenewals: boolean; filter: FilterTab; onAdd: () => void;
}) {
  const [h, setH] = useState(false);
  const msg = hasRenewals
    ? filter !== 'All'
      ? `No renewals match the "${filter}" filter`
      : 'All renewals are beyond the 60-day window'
    : 'Add your first renewal to start tracking expiring policies';

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '40px 20px', gap: 8, textAlign: 'center',
    }}>
      <div style={{ fontSize: 26, opacity: 0.2, marginBottom: 2 }}>↻</div>
      <div style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--text2)' }}>
        No renewals in view
      </div>
      <div style={{ fontSize: 11, color: 'var(--text3)', maxWidth: 240, lineHeight: 1.6 }}>
        {msg}
      </div>
      {!hasRenewals && (
        <button
          onClick={onAdd}
          onMouseEnter={() => setH(true)}
          onMouseLeave={() => setH(false)}
          style={{
            marginTop: 6, padding: '6px 14px', borderRadius: 'var(--r)',
            border: '1px solid var(--border2)', background: h ? 'var(--bg3)' : 'transparent',
            fontFamily: 'var(--font)', fontSize: 11, color: 'var(--text2)', cursor: 'pointer',
            transition: 'background 0.1s',
          }}
        >
          + Add renewal
        </button>
      )}
    </div>
  );
}

function FooterAddBtn({ onClick }: { onClick: () => void }) {
  const [h, setH] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 5, height: 24,
        padding: '0 8px', borderRadius: 'var(--r)',
        border: '1px solid var(--border2)',
        background: h ? 'var(--bg4)' : 'transparent',
        fontFamily: 'var(--font)', fontSize: 10.5, color: 'var(--text2)',
        cursor: 'pointer', transition: 'all 0.1s',
      }}
    >
      + Add renewal
    </button>
  );
}
