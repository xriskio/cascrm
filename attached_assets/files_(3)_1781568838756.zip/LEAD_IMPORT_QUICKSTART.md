# LEAD IMPORT SYSTEM - COMPLETE IMPLEMENTATION GUIDE

**Status:** ✅ READY TO DEPLOY  
**Scope:** Import leads from Truxsurance, InsureLimos, Casurance into unified CRM  
**Time to deploy:** ~2-3 hours (automated) or 4-6 hours (manual)

---

## 📚 WHAT YOU'RE GETTING

This is a **complete lead import system** that:

✅ **Pulls leads** from all 3 sites (Truxsurance, InsureLimos, Casurance)  
✅ **Consolidates** into single leads table in CasRM  
✅ **De-duplicates** by email (same person from 2 sites = 1 lead record)  
✅ **Tracks source** (know which site each lead came from)  
✅ **Schedules** automatic hourly imports  
✅ **Provides** manual import button in dashboard  
✅ **Logs** all imports for auditing  

---

## 🎯 FILES YOU'RE GETTING

### Documentation
- **LEAD_IMPORT_SYSTEM.md** ← Architecture & design (read first)
- **This file** ← Quick start & implementation guide

### Implementation Code
- **api-leads-import-route.ts** ← Main import API endpoint (copy to `/app/api/leads/import/route.ts`)
- **schema-additions.ts** ← New database tables (append to `shared/schema.ts`)

### Automation
- **LEAD_IMPORT_REPLIT_PROMPT.md** ← Full Replit agent prompt (copy/paste to automate)

---

## 🚀 QUICKSTART (Fully Automated)

### Option A: Use Replit Agent (Recommended, 5 min setup + 60 min execution)

1. **Copy** the prompt from `LEAD_IMPORT_REPLIT_PROMPT.md`
2. **Paste** into your Replit Agent chat
3. **Press Enter** and wait ~60 minutes
4. **Done!** Agent will:
   - Add tables to database
   - Create API endpoints
   - Create cron job
   - Update leads page
   - Deploy to Railway

### Option B: Manual Implementation (2-3 hours, more control)

Follow the steps below.

---

## 📋 MANUAL IMPLEMENTATION STEPS

### STEP 1: DATABASE SCHEMA (15 min)

**1a. Backup existing schema**
```bash
cp shared/schema.ts shared/schema.ts.backup
```

**1b. Add to schema.ts (at the end)**

Copy everything from `schema-additions.ts` and append to `shared/schema.ts`

**1c. Verify**
```bash
grep "export const leads = pgTable" shared/schema.ts
```

**1d. Commit**
```bash
git add shared/schema.ts
git commit -m "db: add leads tables"
```

---

### STEP 2: IMPORT API (20 min)

**2a. Create directory**
```bash
mkdir -p app/api/leads/import
```

**2b. Create file: `app/api/leads/import/route.ts`**

Copy everything from `api-leads-import-route.ts` into this new file.

**2c. Verify**
```bash
wc -l app/api/leads/import/route.ts
# Should be 300+ lines
```

**2d. Commit**
```bash
git add app/api/leads/import/route.ts
git commit -m "feat: add lead import API"
```

---

### STEP 3: ENVIRONMENT VARIABLES (5 min)

**3a. Edit `.env.local`**

Add these lines:
```
# Lead Import Configuration
TRUXSURANCE_API_URL=https://truxsurance.com/api
TRUXSURANCE_API_KEY=your-api-key-here

INSURELIMOS_API_URL=https://insurelimos.com/api
INSURELIMOS_API_KEY=your-api-key-here

CASURANCE_API_URL=https://casurance.com/api
CASURANCE_API_KEY=your-api-key-here
```

**3b. Get API keys from each site**
- Go to Truxsurance, InsureLimos, Casurance admin panels
- Get API keys from Settings → API
- Paste into .env.local

---

### STEP 4: TEST IMPORT (10 min)

**4a. Start dev server**
```bash
npm run dev
```

**4b. In another terminal, test import**
```bash
curl -X POST "http://localhost:3000/api/leads/import?manual=true" \
  -H "Content-Type: application/json"
```

**Expected output:**
```json
{
  "success": true,
  "batch_id": "batch-2024-06-15-...",
  "results": [
    { "site": "truxsurance", "new_leads": 5, "duplicates": 2, "errors": [] },
    { "site": "insurelimos", "new_leads": 3, "duplicates": 1, "errors": [] },
    { "site": "casurance", "new_leads": 4, "duplicates": 0, "errors": [] }
  ],
  "summary": { "total_new_leads": 12, "total_duplicates": 3 }
}
```

**If it works:** Continue to STEP 5  
**If it fails:** Check error in response, fix API keys or URLs, try again

---

### STEP 5: SCHEDULED IMPORT (10 min)

**5a. Create file: `scripts/import-leads-cron.ts`**

```typescript
// scripts/import-leads-cron.ts
import https from 'https'

const API_URL = process.env.API_URL || 'http://localhost:3000'

async function runImport() {
  try {
    console.log(`[${new Date().toISOString()}] Starting lead import...`)

    const response = await fetch(`${API_URL}/api/leads/import?manual=false`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    })

    const result = await response.json()
    console.log(`[${new Date().toISOString()}] Import complete:`, {
      batch_id: result.batch_id,
      new_leads: result.summary.total_new_leads,
      duplicates: result.summary.total_duplicates,
    })

    if (!response.ok) {
      console.error('Import failed:', result.error)
      process.exit(1)
    }

    process.exit(0)
  } catch (error) {
    console.error('Cron error:', error)
    process.exit(1)
  }
}

runImport()
```

**5b. Test locally**
```bash
npx ts-node scripts/import-leads-cron.ts
```

Should output something like:
```
[2024-06-15T13:00:00Z] Starting lead import...
[2024-06-15T13:00:05Z] Import complete: { batch_id: 'batch-...', new_leads: 12, duplicates: 3 }
```

**5c. Add to Railway cron**

Edit `railway.json`:
```json
{
  "buildCommand": "npm install && npm run build",
  "startCommand": "npm start",
  "crons": [
    {
      "schedule": "0 * * * *",
      "command": "npx ts-node scripts/import-leads-cron.ts"
    }
  ]
}
```

This runs the import **every hour at the top of the hour** (0 * * * *)

**5d. Commit**
```bash
git add scripts/import-leads-cron.ts railway.json
git commit -m "feat: add scheduled lead import (hourly)"
```

---

### STEP 6: ADD BUTTON TO DASHBOARD (15 min)

**6a. Edit `app/leads/page.tsx`**

Find the imports section (top of file) and add:
```typescript
import { RefreshCw } from "lucide-react"
```

Find the component function and add this state:
```typescript
const [importLoading, setImportLoading] = useState(false)
```

Find where you render buttons/header and add:
```typescript
const handleImportLeads = async () => {
  setImportLoading(true)
  try {
    const res = await fetch('/api/leads/import?manual=true', { method: 'POST' })
    const data = await res.json()
    const { total_new_leads, total_duplicates } = data.summary
    alert(`✅ Import complete!\nNew leads: ${total_new_leads}\nDuplicates merged: ${total_duplicates}`)
    fetchLeads() // Refresh the leads list
  } catch (error) {
    alert(`❌ Import failed: ${error}`)
  } finally {
    setImportLoading(false)
  }
}
```

And render the button in your header (next to other buttons):
```typescript
<Button 
  onClick={handleImportLeads} 
  disabled={importLoading}
  variant="outline"
>
  {importLoading ? (
    <>
      <RefreshCw className="animate-spin mr-2 h-4 w-4" />
      Importing...
    </>
  ) : (
    <>
      <RefreshCw className="mr-2 h-4 w-4" />
      Import All Sites
    </>
  )}
</Button>
```

**6b. Verify**
```bash
grep -n "handleImportLeads" app/leads/page.tsx
```

Should show the function is defined.

**6c. Test in dev**

Go to `http://localhost:3000/leads` (in browser)
- You should see new "Import All Sites" button
- Click it
- You should see: "✅ Import complete!" popup
- Leads list refreshes

**6d. Commit**
```bash
git add app/leads/page.tsx
git commit -m "feat: add import button to leads dashboard"
```

---

### STEP 7: BUILD & DEPLOY (10 min)

**7a. Build**
```bash
npm run build
```

Check for errors. If OK, continue.

**7b. Commit & push**
```bash
git add -A
git commit -m "feat: complete lead import system

- Multi-site lead consolidation (Truxsurance, InsureLimos, Casurance)
- Automatic de-duplication by email
- Hourly scheduled imports
- Manual import button on dashboard
- Full import history logging"

git push origin main
```

**7c. Check Railway deployment**

Go to https://railway.app → Your Project → Deployments

Wait for **"Live"** status (green)

---

## ✅ VERIFICATION

After deployment, verify everything works:

### Check 1: Manual Import
1. Go to https://your-domain/leads
2. Click "Import All Sites" button
3. Should see: "✅ Import complete! New leads: X, Duplicates: Y"
4. Leads list refreshes with new leads

### Check 2: Check for Duplicates
1. Go to Leads page
2. Look for leads with same email from different sites
3. They should be merged into ONE lead record (in raw_data)

### Check 3: Source Tracking
1. Click on a lead to view details
2. Should show `source: "truxsurance"` (or other site)
3. Should show which site the lead came from

### Check 4: Scheduled Import
1. Wait for next hour (or check cron logs in Railway)
2. Should run automatically at top of hour
3. Check import history: `/api/leads/import` (GET)

### Check 5: Check API Response
```bash
curl https://your-domain/api/leads/import | jq '.imports[0]'
```

Should return latest import log with batch_id, results, timestamps

---

## 🔑 KEY FEATURES EXPLAINED

### De-Duplication
When a lead with the same email is imported again:
- **Existing lead** gets updated (contact_attempts++)
- **Not a duplicate record** (no duplicate row created)
- **Both sources** stored in raw_data
- **Marked in logs** as "duplicate"

### Source Tracking
Every lead has:
- `source`: "truxsurance" | "insurelimos" | "casurance"
- `source_url`: Where the form was on each site
- `raw_data`: Full original form data

### Automatic Assignment
(Optional, can be added later)
- New leads auto-assign to next available agent
- Or manually assign in dashboard
- Track assignment date & agent

### Activity Log
Every action tracked:
- Lead created (auto-imported)
- Lead contacted (manual)
- Lead assigned
- Lead converted (to client)
- Lead lost

---

## 📊 WHAT HAPPENS NEXT

### After First Import
You'll have:
- ✅ All leads from all 3 sites in one table
- ✅ Duplicates merged & tracked
- ✅ Source of each lead visible
- ✅ Automatic hourly imports running

### What You Can Do Now
- View all leads in one place (no more switching between sites)
- Filter by source (show only Truxsurance leads, etc.)
- Assign leads to agents
- Track follow-ups
- Convert leads to policies
- See funnel analytics (new → contacted → qualified → converted)

### Future Enhancements (Optional)
- Lead scoring (auto-calculate lead quality)
- Email follow-up automation
- SMS notifications
- Lead assignment rules (skill-based)
- Predictive analytics (which leads will convert?)

---

## 🆘 TROUBLESHOOTING

### Import shows 0 new leads
**Cause:** API keys wrong or no new leads at source sites

**Fix:**
1. Check `.env.local` has correct API keys
2. Verify sites have API endpoints returning leads
3. Test each site manually:
   ```bash
   curl https://truxsurance.com/api/leads \
     -H "Authorization: Bearer YOUR_KEY"
   ```

### Import fails with 500 error
**Cause:** Database connection or schema issue

**Fix:**
1. Check Supabase connection string in `.env`
2. Verify `leads` table exists in database
3. Check Rails logs for error details
4. Try manual import again

### Duplicate leads aren't merging
**Cause:** Email comparison might be case-sensitive

**Fix:**
- Check that email normalization is happening (`.toLowerCase()`)
- All import logic should normalize emails
- Try importing lead manually with exact same email

### Cron job not running
**Cause:** Railway cron not configured correctly

**Fix:**
1. Check `railway.json` has crons section
2. Verify command is correct
3. Check Railway logs for execution
4. Can manually test: `npx ts-node scripts/import-leads-cron.ts`

---

## 📈 ANALYTICS (Future)

Once leads are imported, you can add analytics:

```sql
-- Leads by source
SELECT source, COUNT(*) as total, 
  SUM(CASE WHEN status = 'converted' THEN 1 ELSE 0 END) as converted
FROM leads
GROUP BY source;

-- Conversion funnel
SELECT status, COUNT(*) FROM leads GROUP BY status;

-- Leads per agent
SELECT assigned_to, COUNT(*) FROM leads WHERE assigned_to IS NOT NULL GROUP BY assigned_to;

-- Lead quality (by days to conversion)
SELECT source, AVG(EXTRACT(DAY FROM (conversion_date - created_at))) as avg_days_to_convert
FROM leads
WHERE converted_to_client = true
GROUP BY source;
```

---

## 🎉 SUCCESS CRITERIA

When complete, you'll have:
- [ ] Leads import automatically every hour
- [ ] Manual import button on dashboard works
- [ ] Duplicates detected & merged by email
- [ ] Source tracked for each lead
- [ ] Import history logged
- [ ] No leads lost (all visible in one place)
- [ ] Can assign leads to agents
- [ ] Can track follow-ups & conversions

---

## 📞 NEXT STEPS

1. **Choose deployment method:**
   - Option A: Replit Agent (faster, automated)
   - Option B: Manual steps (more control)

2. **Get API keys from each site:**
   - Truxsurance admin → API keys
   - InsureLimos admin → API keys
   - Casurance admin → API keys

3. **Deploy**

4. **Test import**

5. **Monitor first import run** (check logs for any issues)

---

**Ready to get started?**

- For **automated deployment**: Use `LEAD_IMPORT_REPLIT_PROMPT.md`
- For **manual deployment**: Follow the steps above
- For **architecture details**: Read `LEAD_IMPORT_SYSTEM.md`

Good luck! 🚀
