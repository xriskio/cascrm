# MULTI-SITE LEAD IMPORT SYSTEM
## Truxsurance, InsureLimos, Casurance → Unified Leads Database

**Date:** June 15, 2026  
**Status:** ✅ READY FOR IMPLEMENTATION  
**Scope:** Import leads from 3 sites + unified lead management

---

## 🎯 OVERVIEW

### What This Does
- **Pulls leads** from form submissions on all 3 sites (truxsurance.com, insurelimos.com, casurance.com)
- **Consolidates** into single CRM leads table
- **Deduplicates** by email (same person on multiple sites → 1 lead)
- **Tracks source** (which site lead came from)
- **Schedules** automatic imports every hour
- **Provides** unified lead dashboard with filtering, assignment, follow-up

### Current State
- Each site (Truxsurance, InsureLimos, Casurance) has its own database
- Leads are siloed per site
- No cross-site view
- Manual copy/paste workflow

### Target State
- **Single leads table** (unified CRM)
- **Automatic imports** (hourly sync from all sites)
- **Deduplication logic** (same person from 2 sites = 1 lead)
- **Source tracking** (know which site lead came from)
- **Lead assignment** (assign to agent in CRM)
- **Follow-up tracking** (call, email, convert to client)

---

## 📊 DATABASE SCHEMA

### New Table: `leads` (in CasRM database)

```typescript
export const leads = pgTable("leads", {
  // Identity
  id: uuid("id").primaryKey().defaultRandom(),
  lead_id: varchar("lead_id", { length: 255 }).unique(), // External ID if applicable
  
  // Contact Info
  contact_name: varchar("contact_name", { length: 500 }),
  first_name: varchar("first_name", { length: 255 }),
  last_name: varchar("last_name", { length: 255 }),
  email: varchar("email", { length: 255 }).notNull().unique(), // De-dup key
  phone: varchar("phone", { length: 50 }),
  company_name: varchar("company_name", { length: 500 }),
  
  // Lead Info
  lead_type: varchar("lead_type", { length: 100 }), // 'quote_request', 'contact_inquiry', 'call_scheduled'
  source: varchar("source", { length: 100 }).notNull(), // 'truxsurance', 'insurelimos', 'casurance'
  source_url: varchar("source_url", { length: 500 }), // Which page on which site
  priority: varchar("priority", { length: 50 }).default("normal"), // 'low', 'normal', 'high', 'urgent'
  status: varchar("status", { length: 50 }).default("new"), // 'new', 'contacted', 'qualified', 'converted', 'lost'
  
  // Coverage Info
  coverage_type: varchar("coverage_type", { length: 255 }), // 'trucking', 'limousine', 'workers_comp'
  service_area: varchar("service_area", { length: 255 }), // City, state, region
  fleet_size: varchar("fleet_size", { length: 100 }), // '1-5 vehicles', '5-20', etc.
  
  // Assignment & Workflow
  assigned_to: varchar("assigned_to", { length: 255 }), // Agent email/name
  assigned_date: timestamp("assigned_date"),
  
  // Activity Tracking
  notes: text("notes"), // Internal notes from agents
  follow_up_date: timestamp("follow_up_date"), // Next scheduled follow-up
  last_contacted: timestamp("last_contacted"), // When was lead last contacted
  contact_attempts: integer("contact_attempts").default(0), // How many times contacted
  
  // Conversion Tracking
  converted_to_client: boolean("converted_to_client").default(false),
  conversion_date: timestamp("conversion_date"),
  converted_policy_id: varchar("converted_policy_id", { length: 255 }), // Link to policy if converted
  
  // Import Metadata
  raw_data: jsonb("raw_data"), // Full form submission data
  import_batch_id: varchar("import_batch_id", { length: 255 }), // Track which import batch this came from
  
  // Timestamps
  date_entered: timestamp("date_entered"), // When lead was originally captured
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
})

// Indexes for performance
export const leadsEmailIndex = index("leads_email_idx").on(leads.email)
export const leadsSourceIndex = index("leads_source_idx").on(leads.source)
export const leadsStatusIndex = index("leads_status_idx").on(leads.status)
export const leadsAssignedToIndex = index("leads_assigned_to_idx").on(leads.assigned_to)
```

---

## 🏗️ ARCHITECTURE

### Data Flow

```
SITE 1: Truxsurance.com
├─ Form submissions → Database
│  └─ API endpoint: /api/leads?source=truxsurance
│
SITE 2: InsureLimos.com
├─ Form submissions → Database
│  └─ API endpoint: /api/leads?source=insurelimos
│
SITE 3: Casurance.com
├─ Form submissions → Database
│  └─ API endpoint: /api/leads?source=casurance
│
CENTRAL IMPORT SERVICE (CasRM/XRisk)
├─ Scheduled job: Every hour
├─ Fetches new leads from all 3 sites
├─ Merges into unified leads table
├─ De-duplicates by email
├─ Tracks source & import batch
├─ Updates activity log
│
LEAD MANAGEMENT DASHBOARD
├─ View all leads (cross-site)
├─ Filter by source, status, priority
├─ Assign to agents
├─ Track follow-ups
├─ Convert to clients
└─ Analytics (funnel, ROI by source)
```

### Component Structure

```
app/
├─ api/
│  ├─ leads/
│  │  ├─ route.ts (GET/POST leads)
│  │  ├─ import/
│  │  │  ├─ route.ts (Trigger multi-site import)
│  │  │  └─ cron.ts (Hourly scheduled import)
│  │  ├─ [leadId]/
│  │  │  ├─ route.ts (Get/update individual lead)
│  │  │  └─ assign/route.ts (Assign to agent)
│  │  └─ deduplicate/route.ts (Manual de-dup)
│  │
│  └─ sites/
│     ├─ truxsurance/
│     │  └─ leads/route.ts (Fetch Truxsurance leads)
│     ├─ insurelimos/
│     │  └─ leads/route.ts (Fetch InsureLimos leads)
│     └─ casurance/
│        └─ leads/route.ts (Fetch Casurance leads)
│
├─ leads/
│  ├─ page.tsx (Lead dashboard - already exists)
│  ├─ import/
│  │  ├─ page.tsx (Import management UI)
│  │  └─ route.ts (Import endpoints)
│  └─ [leadId]/
│     └─ page.tsx (Lead detail view)
│
└─ hooks/
   └─ use-lead-import.ts (Hook for import status)
```

---

## 🔌 API ENDPOINTS

### 1. Fetch leads from individual sites

**Endpoint:** `GET /api/sites/[site]/leads`

**Sites:** `truxsurance`, `insurelimos`, `casurance`

**Query params:**
- `?lastImport=2024-06-15T12:00:00Z` (only get new leads since last import)
- `?limit=100` (limit results)

**Response:**
```json
{
  "site": "truxsurance",
  "leads": [
    {
      "id": "ext-123",
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "555-1234",
      "company": "Doe Trucking",
      "coverage": "trucking",
      "service_area": "CA",
      "message": "Looking for liability quote",
      "created_at": "2024-06-15T12:30:00Z"
    }
  ],
  "count": 1,
  "imported_at": "2024-06-15T13:00:00Z"
}
```

### 2. Trigger import from all sites

**Endpoint:** `POST /api/leads/import`

**Body:**
```json
{
  "manual": true,  // true = triggered manually, false = scheduled
  "sites": ["truxsurance", "insurelimos", "casurance"]
}
```

**Response:**
```json
{
  "batch_id": "batch-2024-06-15-13-00",
  "sites_processed": ["truxsurance", "insurelimos", "casurance"],
  "leads_imported": {
    "truxsurance": { "new": 5, "duplicates": 2 },
    "insurelimos": { "new": 3, "duplicates": 1 },
    "casurance": { "new": 4, "duplicates": 0 }
  },
  "total_new": 12,
  "total_duplicates": 3,
  "import_date": "2024-06-15T13:00:00Z",
  "status": "success"
}
```

### 3. Get import history

**Endpoint:** `GET /api/leads/import/history`

**Response:**
```json
{
  "imports": [
    {
      "batch_id": "batch-2024-06-15-13-00",
      "timestamp": "2024-06-15T13:00:00Z",
      "type": "scheduled",
      "results": {
        "truxsurance": { "new": 5, "duplicates": 2 },
        "insurelimos": { "new": 3, "duplicates": 1 },
        "casurance": { "new": 4, "duplicates": 0 }
      },
      "total_new": 12
    }
  ]
}
```

### 4. Manage lead assignments

**Endpoint:** `PATCH /api/leads/[leadId]/assign`

**Body:**
```json
{
  "assigned_to": "agent@example.com",
  "notes": "High priority - tech-savvy operator"
}
```

### 5. Update lead status

**Endpoint:** `PATCH /api/leads/[leadId]/status`

**Body:**
```json
{
  "status": "contacted",  // 'new', 'contacted', 'qualified', 'converted', 'lost'
  "notes": "Left voicemail, follow up tomorrow"
}
```

---

## 📋 IMPLEMENTATION PHASES

### Phase 1: Database & Core API (4 hours)
- [ ] Add `leads` table to schema
- [ ] Create `/api/sites/[site]/leads` endpoints (fetch from each site)
- [ ] Create `/api/leads/import` endpoint (main import logic)
- [ ] Implement de-duplication by email
- [ ] Test with sample data

### Phase 2: Scheduled Imports (3 hours)
- [ ] Create `/api/leads/import/cron.ts` (hourly trigger)
- [ ] Wire to Railway cron or your scheduler
- [ ] Create import history tracking
- [ ] Add logging & error handling
- [ ] Test scheduled import

### Phase 3: Lead Management Dashboard (5 hours)
- [ ] Update `/app/leads/page.tsx` to show imported leads
- [ ] Add source filter (show leads from specific site)
- [ ] Add assignment UI (drag/drop or select agent)
- [ ] Add follow-up tracking (next contact date)
- [ ] Add bulk actions (assign multiple, mark as contacted)

### Phase 4: Lead Details & Conversion (3 hours)
- [ ] Create `/app/leads/[leadId]/page.tsx` (lead detail view)
- [ ] Add lead edit form
- [ ] Add conversion button (convert lead → policy)
- [ ] Add activity history (all contacts/notes)
- [ ] Add email/SMS sending integration (optional)

### Phase 5: Analytics & Reporting (2 hours)
- [ ] Add lead funnel (new → contacted → qualified → converted)
- [ ] Add source analysis (which site generates best leads?)
- [ ] Add agent performance (who converts most leads?)
- [ ] Add ROI dashboard (cost per lead, conversion rate by source)

---

## 🔑 KEY FEATURES

### De-Duplication
**Problem:** Same person fills form on Truxsurance AND InsureLimos

**Solution:**
```typescript
// Before import, check if email exists
const existingLead = await db.select().from(leads)
  .where(eq(leads.email, newLead.email))
  .limit(1)

if (existingLead.length > 0) {
  // Merge: update existing lead with new source
  // Mark as duplicate in import log
  // Increment "contact_attempts" from other source
} else {
  // Insert as new lead
}
```

### Source Tracking
Every lead has:
- `source: 'truxsurance' | 'insurelimos' | 'casurance'`
- `source_url: 'https://truxsurance.com/quote'` (which page form was on)
- `raw_data: { ...full form submission }` (for reference)

### Activity Log
Track all lead interactions:
```typescript
interface LeadActivity {
  lead_id: string
  action: 'created' | 'contacted' | 'assigned' | 'converted' | 'status_changed'
  agent: string
  notes: string
  timestamp: Date
}
```

### Assignment Workflow
1. Lead imported
2. Auto-assign to next available agent (round-robin) OR
3. Manually assign by agent
4. Agent contacts lead
5. Update status (new → contacted → qualified → converted)
6. Follow-up tracking (next contact date)

---

## 🗄️ DATABASE MIGRATIONS

### Migration: Create leads table

```sql
CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id VARCHAR(255) UNIQUE,
  contact_name VARCHAR(500),
  first_name VARCHAR(255),
  last_name VARCHAR(255),
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(50),
  company_name VARCHAR(500),
  lead_type VARCHAR(100),
  source VARCHAR(100) NOT NULL,
  source_url VARCHAR(500),
  priority VARCHAR(50) DEFAULT 'normal',
  status VARCHAR(50) DEFAULT 'new',
  coverage_type VARCHAR(255),
  service_area VARCHAR(255),
  fleet_size VARCHAR(100),
  assigned_to VARCHAR(255),
  assigned_date TIMESTAMP,
  notes TEXT,
  follow_up_date TIMESTAMP,
  last_contacted TIMESTAMP,
  contact_attempts INT DEFAULT 0,
  converted_to_client BOOLEAN DEFAULT false,
  conversion_date TIMESTAMP,
  converted_policy_id VARCHAR(255),
  raw_data JSONB,
  import_batch_id VARCHAR(255),
  date_entered TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX leads_email_idx ON leads(email);
CREATE INDEX leads_source_idx ON leads(source);
CREATE INDEX leads_status_idx ON leads(status);
CREATE INDEX leads_assigned_to_idx ON leads(assigned_to);

CREATE TABLE IF NOT EXISTS lead_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES leads(id),
  action VARCHAR(50) NOT NULL,
  agent VARCHAR(255),
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX lead_activities_lead_id_idx ON lead_activities(lead_id);
```

---

## 🚀 IMPLEMENTATION ROADMAP

### Week 1: Core Import
- Day 1-2: Database schema + Phase 1 API
- Day 3-4: Phase 2 (scheduled imports)
- Day 5: Testing & debugging

### Week 2: Dashboard & Features
- Day 1-2: Phase 3 (lead management dashboard)
- Day 3-4: Phase 4 (lead details & conversion)
- Day 5: User testing & feedback

### Week 3: Analytics & Polish
- Day 1-2: Phase 5 (analytics)
- Day 3-4: Performance optimization
- Day 5: Documentation & training

---

## ✅ SUCCESS CRITERIA

When complete:
- [ ] Leads import automatically every hour from all 3 sites
- [ ] Duplicates detected and merged by email
- [ ] Leads show in dashboard with source tracking
- [ ] Can assign leads to agents
- [ ] Can track follow-ups & conversions
- [ ] Analytics show lead funnel by source
- [ ] No leads are lost (all visible in one place)

---

## 📞 NEXT STEPS

To get started:

1. **Decide:** Do you want me to build this system completely?
2. **Timeline:** How quickly do you need it?
3. **Specifics:**
   - Which agents should get assigned leads?
   - Auto-assign logic (round-robin, skill-based, etc.)?
   - Email notifications when lead assigned?
   - SMS follow-up capability?
   - Integration with existing lead workflow?

I can provide:
- ✅ Complete API endpoint code (copy-paste ready)
- ✅ Database schema + migrations
- ✅ React components for lead dashboard
- ✅ Scheduled job setup (Railway cron)
- ✅ De-duplication logic
- ✅ Lead assignment workflow

Ready when you are!

---

END OF DOCUMENT
