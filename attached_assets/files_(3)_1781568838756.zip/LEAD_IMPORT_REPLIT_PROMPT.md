// COMPLETE LEAD IMPORT SYSTEM - REPLIT AGENT AUTOMATION PROMPT
// Paste this into your Replit Agent to fully automate lead import setup

===== START PROMPT =====

You are a Node.js/TypeScript specialist. Implement the COMPLETE lead import system (from all 3 sites into unified leads database) INDEPENDENTLY.

## TASK: Multi-Site Lead Import System

Import leads from Truxsurance, InsureLimos, and Casurance into unified CasRM leads database.
De-duplicate by email. Track source. Schedule hourly imports.

## CRITICAL RULES
1. **RAW ARTIFACTS ONLY**: Show grep/curl output, SQL, git diff (never say "done" without proof)
2. **BACKUP FIRST**: Always backup before modifying schema
3. **TEST EACH STEP**: Verify with curl/npm commands
4. **GIT COMMITS**: Commit after each phase
5. **STOP ON ERROR**: If ANY command fails, show error and STOP

---

## PHASE 1: DATABASE SCHEMA (15 minutes)

**Step 1a: Backup current schema**
```bash
cp shared/schema.ts shared/schema.ts.backup.pre-leads
ls -la shared/schema.ts*
```
Show both files exist

**Step 1b: Add leads tables to schema**

Append to shared/schema.ts:

```typescript
// ── LEADS TABLES (NEW) ─────────────────────────────────────────────────────
export const leads = pgTable("leads", {
  id: uuid("id").primaryKey().defaultRandom(),
  lead_id: varchar("lead_id", { length: 255 }).unique(),
  contact_name: varchar("contact_name", { length: 500 }),
  first_name: varchar("first_name", { length: 255 }),
  last_name: varchar("last_name", { length: 255 }),
  email: varchar("email", { length: 255 }).notNull().unique(),
  phone: varchar("phone", { length: 50 }),
  company_name: varchar("company_name", { length: 500 }),
  lead_type: varchar("lead_type", { length: 100 }),
  source: varchar("source", { length: 100 }).notNull(),
  source_url: varchar("source_url", { length: 500 }),
  priority: varchar("priority", { length: 50 }).default("normal"),
  status: varchar("status", { length: 50 }).default("new"),
  coverage_type: varchar("coverage_type", { length: 255 }),
  service_area: varchar("service_area", { length: 255 }),
  fleet_size: varchar("fleet_size", { length: 100 }),
  assigned_to: varchar("assigned_to", { length: 255 }),
  assigned_date: timestamp("assigned_date"),
  notes: text("notes"),
  follow_up_date: timestamp("follow_up_date"),
  last_contacted: timestamp("last_contacted"),
  contact_attempts: integer("contact_attempts").default(0),
  converted_to_client: boolean("converted_to_client").default(false),
  conversion_date: timestamp("conversion_date"),
  converted_policy_id: varchar("converted_policy_id", { length: 255 }),
  raw_data: jsonb("raw_data"),
  import_batch_id: varchar("import_batch_id", { length: 255 }),
  date_entered: timestamp("date_entered"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
})

export const leadsEmailIndex = index("leads_email_idx").on(leads.email)
export const leadsSourceIndex = index("leads_source_idx").on(leads.source)
export const leadsStatusIndex = index("leads_status_idx").on(leads.status)
export const leadsAssignedToIndex = index("leads_assigned_to_idx").on(leads.assigned_to)

export const leadActivities = pgTable("lead_activities", {
  id: uuid("id").primaryKey().defaultRandom(),
  lead_id: uuid("lead_id").notNull(),
  action: varchar("action", { length: 50 }).notNull(),
  agent: varchar("agent", { length: 255 }),
  notes: text("notes"),
  created_at: timestamp("created_at").defaultNow().notNull(),
})

export const importLogs = pgTable("import_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  batch_id: varchar("batch_id", { length: 255 }).notNull().unique(),
  import_type: varchar("import_type", { length: 50 }).default("scheduled"),
  sites_processed: varchar("sites_processed", { length: 500 }),
  results: jsonb("results"),
  total_new_leads: integer("total_new_leads").default(0),
  total_duplicates: integer("total_duplicates").default(0),
  errors: jsonb("errors"),
  created_at: timestamp("created_at").defaultNow().notNull(),
})

export const leadsActivityIndex = index("lead_activities_lead_id_idx").on(leadActivities.lead_id)
export const importLogsIndex = index("import_logs_batch_id_idx").on(importLogs.batch_id)
```

**Step 1c: Verify schema updated**
```bash
grep -n "export const leads = pgTable" shared/schema.ts
tail -50 shared/schema.ts | head -20
```
Must show: "export const leads = pgTable"

**Step 1d: Commit schema changes**
```bash
git add shared/schema.ts
git commit -m "db: add leads, lead_activities, import_logs tables with indexes"
git log --oneline -1
```

---

## PHASE 2: MAIN IMPORT API (20 minutes)

**Step 2a: Create import endpoint directory**
```bash
mkdir -p app/api/leads/import
ls -la app/api/leads/import/
```

**Step 2b: Create main import route**

File: `app/api/leads/import/route.ts`

```typescript
import { NextRequest, NextResponse } from "next/server"
import { supabaseAdmin } from "@/lib/supabase/admin"

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

interface SiteLead {
  id?: string
  name?: string
  contact_name?: string
  email: string
  phone?: string
  company?: string
  company_name?: string
  coverage?: string
  coverage_type?: string
  service_area?: string
  fleet_size?: string
  message?: string
  notes?: string
  created_at?: string
  [key: string]: any
}

interface ImportResult {
  site: string
  new_leads: number
  duplicates: number
  errors: string[]
}

// Fetch leads from a specific site
async function fetchLeadsFromSite(
  site: 'truxsurance' | 'insurelimos' | 'casurance',
  lastImport?: string
): Promise<{ leads: SiteLead[]; error?: string }> {
  try {
    const baseUrls: Record<string, string> = {
      truxsurance: process.env.TRUXSURANCE_API_URL || "https://truxsurance.com/api",
      insurelimos: process.env.INSURELIMOS_API_URL || "https://insurelimos.com/api",
      casurance: process.env.CASURANCE_API_URL || "https://casurance.com/api",
    }

    const url = new URL(`${baseUrls[site]}/leads`)
    url.searchParams.append("source", site)
    if (lastImport) url.searchParams.append("since", lastImport)
    url.searchParams.append("limit", "500")

    const response = await fetch(url.toString(), {
      headers: {
        "Authorization": `Bearer ${process.env[`${site.toUpperCase()}_API_KEY`] || ""}`,
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      return { leads: [], error: `Failed to fetch from ${site}: ${response.status}` }
    }

    const data = await response.json()
    return { leads: data.leads || [] }
  } catch (error) {
    return { leads: [], error: String(error) }
  }
}

// Normalize lead from any site format to standard format
function normalizeLead(siteLead: SiteLead, source: string): any {
  return {
    contact_name: siteLead.contact_name || siteLead.name || "",
    first_name: siteLead.first_name || siteLead.name?.split(" ")[0] || "",
    last_name: siteLead.last_name || siteLead.name?.split(" ").slice(1).join(" ") || "",
    email: siteLead.email.toLowerCase().trim(),
    phone: siteLead.phone || null,
    company_name: siteLead.company_name || siteLead.company || null,
    lead_type: siteLead.lead_type || "contact_inquiry",
    source: source,
    source_url: siteLead.source_url || null,
    coverage_type: siteLead.coverage || siteLead.coverage_type || null,
    service_area: siteLead.service_area || null,
    fleet_size: siteLead.fleet_size || null,
    notes: siteLead.notes || siteLead.message || null,
    status: "new",
    priority: "normal",
    raw_data: siteLead,
    date_entered: siteLead.date_entered || siteLead.created_at || new Date().toISOString(),
  }
}

// Check if lead already exists (by email)
async function checkDuplicate(email: string, supabase: any): Promise<any | null> {
  try {
    const { data } = await supabase
      .from("leads")
      .select("*")
      .eq("email", email.toLowerCase())
      .limit(1)
      .single()
    return data || null
  } catch {
    return null
  }
}

// Insert or update lead
async function upsertLead(normalizedLead: any, batchId: string, supabase: any): Promise<{ success: boolean; isDuplicate: boolean; leadId?: string }> {
  try {
    const existing = await checkDuplicate(normalizedLead.email, supabase)

    if (existing) {
      const { data, error } = await supabase
        .from("leads")
        .update({
          contact_attempts: (existing.contact_attempts || 0) + 1,
          raw_data: { ...existing.raw_data, [normalizedLead.source]: normalizedLead.raw_data },
          import_batch_id: batchId,
          updated_at: new Date().toISOString(),
        })
        .eq("id", existing.id)
        .select()
        .single()

      if (error) throw error
      return { success: true, isDuplicate: true, leadId: existing.id }
    }

    const { data, error } = await supabase
      .from("leads")
      .insert([{ ...normalizedLead, import_batch_id: batchId, created_at: new Date().toISOString(), updated_at: new Date().toISOString() }])
      .select()
      .single()

    if (error) throw error
    return { success: true, isDuplicate: false, leadId: data.id }
  } catch (error) {
    console.error("Error in upsertLead:", error)
    return { success: false, isDuplicate: false }
  }
}

// Main POST handler
export async function POST(request: NextRequest) {
  try {
    const supabase = supabaseAdmin
    const { searchParams } = new URL(request.url)
    const manual = searchParams.get("manual") === "true"
    const sites = (searchParams.get("sites") || "truxsurance,insurelimos,casurance").split(",") as Array<'truxsurance' | 'insurelimos' | 'casurance'>

    const batchId = `batch-${new Date().toISOString().replace(/[:.]/g, "-")}`

    const results: ImportResult[] = []
    let totalNew = 0
    let totalDupes = 0

    for (const site of sites) {
      const siteResult: ImportResult = { site, new_leads: 0, duplicates: 0, errors: [] }

      try {
        const { leads: siteLeads, error } = await fetchLeadsFromSite(site)
        if (error) {
          siteResult.errors.push(error)
          results.push(siteResult)
          continue
        }

        for (const siteLead of siteLeads) {
          const normalized = normalizeLead(siteLead, site)
          const { success, isDuplicate } = await upsertLead(normalized, batchId, supabase)

          if (success) {
            if (isDuplicate) {
              siteResult.duplicates++
              totalDupes++
            } else {
              siteResult.new_leads++
              totalNew++
            }
          }
        }
      } catch (error) {
        siteResult.errors.push(String(error))
      }

      results.push(siteResult)
    }

    // Log import
    await supabase.from("import_logs").insert([{
      batch_id: batchId,
      import_type: manual ? "manual" : "scheduled",
      sites_processed: sites.join(","),
      results: results,
      total_new_leads: totalNew,
      total_duplicates: totalDupes,
      created_at: new Date().toISOString(),
    }])

    return NextResponse.json({
      success: true,
      batch_id: batchId,
      results,
      summary: { total_new_leads: totalNew, total_duplicates: totalDupes, timestamp: new Date().toISOString() },
    })
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}

// GET for import history
export async function GET(request: NextRequest) {
  try {
    const supabase = supabaseAdmin
    const { data: logs, error } = await supabase
      .from("import_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(20)

    if (error) throw error

    return NextResponse.json({ imports: logs || [], count: logs?.length || 0 })
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}
```

**Step 2c: Verify file created**
```bash
wc -l app/api/leads/import/route.ts
head -5 app/api/leads/import/route.ts | grep -i import
```
Must show: 300+ lines, import statements present

**Step 2d: Commit**
```bash
git add app/api/leads/import/route.ts
git commit -m "feat: add multi-site lead import API endpoint

- Fetches leads from truxsurance, insurelimos, casurance
- Normalizes data format across sites
- De-duplicates by email (merges duplicates)
- Tracks import batch and source
- Returns detailed import results"
git log --oneline -1
```

---

## PHASE 3: ENVIRONMENT VARIABLES (5 minutes)

**Step 3a: Update .env.local**

Add to `.env.local`:

```
# Lead Import - Site API URLs
TRUXSURANCE_API_URL=https://truxsurance.com/api
TRUXSURANCE_API_KEY=your-truxsurance-api-key

INSURELIMOS_API_URL=https://insurelimos.com/api
INSURELIMOS_API_KEY=your-insurelimos-api-key

CASURANCE_API_URL=https://casurance.com/api
CASURANCE_API_KEY=your-casurance-api-key
```

**Step 3b: Verify**
```bash
grep -i "TRUXSURANCE_API" .env.local
grep -i "INSURELIMOS_API" .env.local
grep -i "CASURANCE_API" .env.local
```

---

## PHASE 4: TEST IMPORT (10 minutes)

**Step 4a: Start dev server**
```bash
npm run dev &
sleep 5
ps aux | grep "next dev"
```

**Step 4b: Test import endpoint (manual)**
```bash
curl -X POST "http://localhost:3000/api/leads/import?manual=true" \
  -H "Content-Type: application/json" \
  2>/dev/null | jq '.'
```

Expected output: JSON with batch_id, results array, summary

**Step 4c: Verify leads in database**
```bash
# Check if leads table has data
curl -s "http://localhost:3000/api/leads/import" 2>/dev/null | jq '.imports[0]'
```

Must show: import log with batch_id, results, timestamps

---

## PHASE 5: SCHEDULED IMPORT (10 minutes)

**Step 5a: Create cron job**

File: `scripts/import-leads-cron.ts`

```typescript
// Run: node --loader ts-node/esm scripts/import-leads-cron.ts
// Or trigger via Railway cron job

import https from 'https'

const API_URL = process.env.API_URL || 'http://localhost:3000'

async function runImport() {
  try {
    console.log(`[${new Date().toISOString()}] Starting lead import...`)

    const response = await fetch(`${API_URL}/api/leads/import?manual=false`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    })

    const result = await response.json()
    console.log(`[${new Date().toISOString()}] Import complete:`, JSON.stringify(result.summary, null, 2))

    if (!response.ok) {
      console.error('Import failed:', result.error)
      process.exit(1)
    }

    process.exit(0)
  } catch (error) {
    console.error('Cron error:', error)
    process.exit(1)
  }
}

runImport()
```

**Step 5b: Test cron locally**
```bash
npx ts-node scripts/import-leads-cron.ts
```

Should show: "Starting lead import..." → "Import complete:"

**Step 5c: Add to Railway cron (if using Railway)**

Add to `railway.json`:
```json
{
  "buildCommand": "npm install && npm run build",
  "startCommand": "npm start",
  "crons": [
    {
      "schedule": "0 * * * *",
      "command": "npx ts-node scripts/import-leads-cron.ts"
    }
  ]
}
```

**Step 5d: Commit**
```bash
git add scripts/import-leads-cron.ts
git commit -m "feat: add scheduled lead import cron job

- Runs every hour (0 * * * *)
- Calls POST /api/leads/import
- Logs results to console
- Can be triggered manually or scheduled"
git log --oneline -1
```

---

## PHASE 6: UPDATE LEADS PAGE (15 minutes)

**Step 6a: Check existing leads page**
```bash
wc -l app/leads/page.tsx
head -30 app/leads/page.tsx
```

**Step 6b: Add import button to leads page**

In `app/leads/page.tsx`, add to your import statements:

```typescript
import { RefreshCw } from "lucide-react"
```

And add this button to your page (in the header section):

```typescript
const [importLoading, setImportLoading] = useState(false)

const handleImportLeads = async () => {
  setImportLoading(true)
  try {
    const res = await fetch('/api/leads/import?manual=true', { method: 'POST' })
    const data = await res.json()
    alert(`Import complete! New leads: ${data.summary.total_new_leads}, Duplicates: ${data.summary.total_duplicates}`)
    fetchLeads() // Refresh the list
  } catch (error) {
    alert(`Import failed: ${error}`)
  } finally {
    setImportLoading(false)
  }
}

// In your header, add:
<Button onClick={handleImportLeads} disabled={importLoading}>
  <RefreshCw className={importLoading ? "animate-spin" : ""} /> Import from All Sites
</Button>
```

**Step 6c: Verify updated**
```bash
grep -n "handleImportLeads" app/leads/page.tsx
grep -n "api/leads/import" app/leads/page.tsx
```
Must show: function defined and API call present

**Step 6d: Commit**
```bash
git add app/leads/page.tsx
git commit -m "feat: add manual import button to leads dashboard

- Users can trigger import anytime from dashboard
- Shows result count (new vs duplicates)
- Refreshes leads list after import"
git log --oneline -1
```

---

## PHASE 7: BUILD & DEPLOY (10 minutes)

**Step 7a: Build**
```bash
npm run build 2>&1 | tail -20
```
Must show: "Build complete" or similar success

**Step 7b: Git final commit**
```bash
git status
```
Must show: clean

**Step 7c: Push to GitHub**
```bash
git push origin main
```

**Step 7d: Railway deploys automatically**

Check Railway dashboard for "Live" status

---

## VERIFICATION CHECKLIST

- [ ] Phase 1: Leads tables added to schema
- [ ] Phase 2: Import API endpoint created (300+ lines)
- [ ] Phase 3: Environment variables configured
- [ ] Phase 4: Manual import test successful
- [ ] Phase 5: Cron job created and tested
- [ ] Phase 6: Leads page has import button
- [ ] Phase 7: Build successful
- [ ] Phase 7: Pushed to GitHub & Railway deploying

---

## USAGE AFTER DEPLOYMENT

### Manual Import (from dashboard)
1. Go to Leads page
2. Click "Import from All Sites"
3. Wait for result popup
4. Leads list refreshes with new leads

### Automatic Import
- Runs every hour automatically
- No action needed
- Check import logs at `/api/leads/import` (GET)

### Check Import History
```bash
curl http://your-domain/api/leads/import | jq '.imports[0]'
```

---

===== END PROMPT =====
