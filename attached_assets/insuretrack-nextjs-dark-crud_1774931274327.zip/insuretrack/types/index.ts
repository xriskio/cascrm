export type RenewalStatus = 'Pending' | 'In Progress' | 'Quoted' | 'Cancelled';
export interface Renewal {
  id: string;
  clientName: string;
  policyType: string;
  policyId: string;
  expiryDate: string;       // ISO YYYY-MM-DD
  status: RenewalStatus;
  premium?: string;
  notes?: string;
}

export type QuoteStage = 'pending' | 'submitted' | 'bound';
export interface Quote {
  id: string;
  clientName: string;
  policyType: string;
  stage: QuoteStage;
  premium?: string;
  carrier?: string;
  notes?: string;
}

export type TaskPriority = 'High' | 'Medium' | 'Low';
export interface Task {
  id: string;
  name: string;
  client?: string;
  dueDate?: string;
  priority: TaskPriority;
  policyType?: string;
  notes?: string;
  done: boolean;
}

export type ActivityType = 'task' | 'renewal' | 'call' | 'quote' | 'document';
export interface Activity {
  id: string;
  type: ActivityType;
  title: string;
  description: string;
  date: string;
}

export interface UserProfile {
  name: string;
  role: string;
  agency?: string;
  email?: string;
}

export interface DashboardState {
  user: UserProfile;
  renewals: Renewal[];
  quotes: Quote[];
  tasks: Task[];
  activity: Activity[];
}
