'use client';

import { useState, useCallback } from 'react';
import { INITIAL_TASKS } from '@/lib/data';
import type { Task, TaskStatus, TaskPriority } from '@/types';

type Filter = 'all' | 'overdue' | 'progress' | 'done';

const PRIORITY_STYLES: Record<TaskPriority, { bg: string; color: string }> = {
  high:   { bg: 'var(--red-bg)',   color: 'var(--red)'   },
  medium: { bg: 'var(--amber-bg)', color: 'var(--amber)' },
  low:    { bg: 'var(--green-bg)', color: 'var(--green)' },
};

interface TaskPanelProps {
  onNewTask?: () => void;
}

export default function TaskPanel({ onNewTask }: TaskPanelProps) {
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [filter, setFilter] = useState<Filter>('all');

  const counts = {
    all:      tasks.length,
    overdue:  tasks.filter(t => t.status === 'overdue').length,
    progress: tasks.filter(t => t.status === 'progress').length,
    done:     tasks.filter(t => t.status === 'done').length,
  };

  const visible = filter === 'all' ? tasks : tasks.filter(t => t.status === filter);

  const toggleTask = useCallback((id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id !== id) return t;
      const completed = !t.completed;
      return { ...t, completed, status: completed ? 'done' : 'progress' };
    }));
  }, []);

  const FILTER_TABS: { label: string; value: Filter; count: number; numColor?: string }[] = [
    { label: 'All',     value: 'all',      count: counts.all      },
    { label: 'Overdue', value: 'overdue',  count: counts.overdue,  numColor: 'var(--red)'   },
    { label: 'Pending', value: 'progress', count: counts.progress, numColor: 'var(--amber)' },
    { label: 'Done',    value: 'done',     count: counts.done,     numColor: 'var(--green)' },
  ];

  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center',
        padding: '14px 14px',
        borderBottom: '1px solid var(--border)',
        gap: 8,
      }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.2px' }}>My Tasks</div>
        <button
          onClick={onNewTask}
          style={{
            marginLeft: 'auto',
            display: 'flex', alignItems: 'center', gap: 4,
            padding: '0 10px', height: 28,
            background: 'var(--text)', color: '#fff',
            border: 'none', borderRadius: 'var(--radius)',
            fontFamily: 'var(--font)', fontSize: 11, fontWeight: 500,
            cursor: 'pointer',
          }}
        >
          + New
        </button>
      </div>

      {/* Mini stat tabs */}
      <div style={{
        padding: '10px 14px',
        borderBottom: '1px solid var(--border)',
      }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
          {FILTER_TABS.map(tab => (
            <div
              key={tab.value}
              onClick={() => setFilter(tab.value)}
              style={{
                textAlign: 'center',
                padding: '8px 4px',
                borderRadius: 8,
                cursor: 'pointer',
                border: `1px solid ${filter === tab.value ? 'var(--border-med)' : 'transparent'}`,
                background: filter === tab.value ? 'var(--surface2)' : 'transparent',
                transition: 'background 0.12s, border-color 0.12s',
              }}
            >
              <div style={{
                fontSize: 18, fontWeight: 500, lineHeight: 1,
                fontFamily: 'var(--mono)',
                color: tab.numColor ?? 'var(--text-2)',
              }}>
                {tab.count}
              </div>
              <div style={{ fontSize: 9.5, color: 'var(--text-3)', marginTop: 3, fontWeight: 500 }}>
                {tab.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Task list */}
      <div>
        {visible.map(task => (
          <TaskItem key={task.id} task={task} onToggle={toggleTask} />
        ))}
      </div>

      {/* Add task row */}
      <AddTaskRow onNewTask={onNewTask} />
    </div>
  );
}

// ── TASK ITEM ──────────────────────────────────────────────────────────────────
function TaskItem({ task, onToggle }: { task: Task; onToggle: (id: string) => void }) {
  const [hovered, setHovered] = useState(false);
  const pri = PRIORITY_STYLES[task.priority];
  const isOverdue = task.status === 'overdue' && !task.completed;

  return (
    <div
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 10,
        padding: '10px 14px',
        borderBottom: '1px solid var(--border)',
        cursor: 'pointer',
        background: hovered ? 'var(--surface2)' : 'transparent',
        transition: 'background 0.1s',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Checkbox */}
      <div
        onClick={e => { e.stopPropagation(); onToggle(task.id); }}
        style={{
          width: 17, height: 17, borderRadius: 5, flexShrink: 0, marginTop: 1,
          border: `1.5px solid ${task.completed ? 'var(--green)' : 'var(--border-med)'}`,
          background: task.completed ? 'var(--green)' : 'transparent',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', transition: 'background 0.12s, border-color 0.12s',
        }}
      >
        {task.completed && (
          <svg width="9" height="8" viewBox="0 0 10 8" fill="none" stroke="white" strokeWidth="2">
            <polyline points="1,4 4,7 9,1"/>
          </svg>
        )}
      </div>

      {/* Content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12.5, fontWeight: 500,
          color: task.completed ? 'var(--text-3)' : 'var(--text)',
          textDecoration: task.completed ? 'line-through' : 'none',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>
          {task.name}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3, flexWrap: 'wrap' }}>
          {task.dueDate && (
            <span style={{
              fontSize: 10.5,
              fontFamily: 'var(--mono)',
              color: isOverdue ? 'var(--red)' : 'var(--text-3)',
              fontWeight: isOverdue ? 500 : 400,
            }}>
              {isOverdue ? `Overdue · ${task.dueDate}` : `Due ${task.dueDate}`}
            </span>
          )}
          {!task.dueDate && (
            <span style={{ fontSize: 10.5, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>
              No due date
            </span>
          )}
          {!task.completed && (
            <span style={{
              fontSize: 9.5, fontWeight: 600,
              padding: '1px 6px', borderRadius: 10,
              background: pri.bg, color: pri.color,
            }}>
              {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// ── ADD TASK ROW ───────────────────────────────────────────────────────────────
function AddTaskRow({ onNewTask }: { onNewTask?: () => void }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={onNewTask}
      style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '10px 14px',
        borderTop: '1px solid var(--border)',
        cursor: 'pointer',
        color: hovered ? 'var(--text-2)' : 'var(--text-3)',
        fontSize: 12.5,
        background: hovered ? 'var(--surface2)' : 'transparent',
        transition: 'background 0.12s, color 0.12s',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <span style={{ fontSize: 15 }}>+</span> Add new task
    </div>
  );
}
