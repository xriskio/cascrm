'use client';

import { useState } from 'react';
import { ACTIVITY_FEED } from '@/lib/data';
import type { ActivityType } from '@/types';

type Tab = 'all' | 'tasks' | 'renewals' | 'calls';

const ICON_CONFIG: Record<ActivityType, { icon: string; bg: string }> = {
  task:     { icon: '✔', bg: 'var(--green-bg)'  },
  renewal:  { icon: '↻', bg: 'var(--amber-bg)'  },
  call:     { icon: '📞', bg: 'var(--blue-bg)'  },
  quote:    { icon: '$', bg: 'var(--red-bg)'    },
  document: { icon: '📄', bg: 'var(--purple-bg)' },
};

const FILTER_MAP: Record<Tab, ActivityType[] | 'all'> = {
  all:      'all',
  tasks:    ['task'],
  renewals: ['renewal'],
  calls:    ['call'],
};

const TABS: { label: string; value: Tab }[] = [
  { label: 'All',      value: 'all'      },
  { label: 'Tasks',    value: 'tasks'    },
  { label: 'Renewals', value: 'renewals' },
  { label: 'Calls',    value: 'calls'    },
];

export default function ActivityFeed() {
  const [activeTab, setActiveTab] = useState<Tab>('all');

  const visible = ACTIVITY_FEED.filter(a => {
    const f = FILTER_MAP[activeTab];
    return f === 'all' || f.includes(a.type);
  });

  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center',
        padding: '14px 18px',
        borderBottom: '1px solid var(--border)',
        gap: 10,
      }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.2px' }}>Recent Activity</div>
        <div style={{ marginLeft: 'auto', display: 'flex', background: 'var(--surface2)', borderRadius: 8, padding: 2, gap: 1 }}>
          {TABS.map(tab => (
            <button
              key={tab.value}
              onClick={() => setActiveTab(tab.value)}
              style={{
                padding: '4px 10px', fontSize: 11, fontWeight: 500,
                borderRadius: 6, border: 'none', cursor: 'pointer',
                fontFamily: 'var(--font)',
                background: activeTab === tab.value ? 'var(--surface)' : 'transparent',
                color: activeTab === tab.value ? 'var(--text)' : 'var(--text-3)',
                boxShadow: activeTab === tab.value ? 'var(--shadow-sm)' : 'none',
                transition: 'background 0.12s, color 0.12s',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Feed */}
      {visible.length === 0 ? (
        <div style={{ padding: '24px 18px', textAlign: 'center', color: 'var(--text-3)', fontSize: 13 }}>
          No activity to show
        </div>
      ) : (
        visible.map(item => {
          const config = ICON_CONFIG[item.type];
          return <ActivityItem key={item.id} item={item} config={config} />;
        })
      )}
    </div>
  );
}

function ActivityItem({
  item,
  config,
}: {
  item: typeof ACTIVITY_FEED[0];
  config: { icon: string; bg: string };
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 11,
        padding: '11px 18px',
        borderBottom: '1px solid var(--border)',
        background: hovered ? 'var(--surface2)' : 'transparent',
        transition: 'background 0.1s',
        cursor: 'pointer',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div style={{
        width: 30, height: 30, borderRadius: 9,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 13, flexShrink: 0, marginTop: 1,
        background: config.bg,
      }}>
        {config.icon}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12.5, fontWeight: 500, color: 'var(--text)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>
          {item.title}
        </div>
        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
          {item.description}
        </div>
      </div>
      <div style={{ fontSize: 10, color: 'var(--text-3)', flexShrink: 0, marginTop: 3, fontFamily: 'var(--mono)' }}>
        {item.date}
      </div>
    </div>
  );
}
