'use client';
/**
 * CrudModal.tsx — Universal add/edit modal for all entity types.
 * Props: type ('renewal'|'quote'|'task'|'activity'|'user'), existing item, onSave, onDelete, onClose
 */
import { useState, useEffect, useCallback } from 'react';
import { Field, Input, Select, Textarea } from './ui';
import type { Renewal, Quote, Task, Activity, UserProfile } from '@/types';

type ModalType = 'renewal' | 'quote' | 'task' | 'activity' | 'user';

interface CrudModalProps {
  type: ModalType;
  defaultStage?: string;
  existing?: Renewal | Quote | Task | Activity | UserProfile | null;
  onSave: (data: Record<string, string>) => void;
  onDelete?: () => void;
  onClose: () => void;
}

const POLICY_TYPES = ['General Liability','Commercial Property','Commercial Auto','Dwelling Fire','Workers Comp','Commercial Umbrella','BOP','Homeowners',"Renter's Policy",'Other'];

const TITLES: Record<ModalType, [string, string]> = {
  renewal:  ['Add Renewal',  'Edit Renewal'],
  quote:    ['Add Quote',    'Edit Quote'],
  task:     ['Add Task',     'Edit Task'],
  activity: ['Log Activity', 'Log Activity'],
  user:     ['Profile',      'Profile'],
};

export default function CrudModal({ type, defaultStage = 'pending', existing, onSave, onDelete, onClose }: CrudModalProps) {
  const isEdit = !!existing;
  const [form, setForm] = useState<Record<string, string>>({});
  const [err, setErr] = useState('');

  // Pre-fill form from existing item
  useEffect(() => {
    const base: Record<string, string> = {};
    if (existing) Object.entries(existing).forEach(([k, v]) => { if (typeof v === 'string') base[k] = v; });
    if (!base.status) base.status = 'Pending';
    if (!base.priority) base.priority = 'Medium';
    if (!base.stage) base.stage = defaultStage;
    if (!base.policyType) base.policyType = POLICY_TYPES[0];
    if (!base.type && type === 'activity') base.type = 'task';
    if (!base.date && type === 'activity') base.date = new Date().toISOString().slice(0, 10);
    setForm(base);
  }, [existing, defaultStage, type]);

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(prev => ({ ...prev, [k]: e.target.value }));

  const handleSave = () => {
    setErr('');
    if (type === 'renewal') {
      if (!form.clientName?.trim()) return setErr('Client name is required');
      if (!form.expiryDate) return setErr('Expiry date is required');
    }
    if (type === 'quote'    && !form.clientName?.trim()) return setErr('Client name is required');
    if (type === 'task'     && !form.name?.trim())       return setErr('Task name is required');
    if (type === 'activity' && !form.title?.trim())      return setErr('Title is required');
    onSave(form);
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleSave();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [form]);

  const title = TITLES[type][isEdit ? 1 : 0];

  return (
    <div onClick={onClose} style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.75)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:300, backdropFilter:'blur(4px)', animation:'fadeIn 0.15s ease' }}>
      <div onClick={e => e.stopPropagation()} style={{ background:'var(--bg2)', border:'1px solid var(--border2)', borderRadius:'var(--rl)', width:460, maxWidth:'96vw', boxShadow:'var(--shadow-lg)', animation:'scaleIn 0.18s ease', overflow:'hidden', maxHeight:'90vh', display:'flex', flexDirection:'column' }}>

        {/* Head */}
        <div style={{ padding:'16px 18px 12px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0 }}>
          <div style={{ fontSize:14, fontWeight:600, letterSpacing:'-0.3px' }}>{title}</div>
          <button onClick={onClose} style={{ width:26, height:26, borderRadius:6, border:'1px solid var(--border2)', background:'transparent', cursor:'pointer', fontSize:15, color:'var(--text3)', display:'flex', alignItems:'center', justifyContent:'center' }}>×</button>
        </div>

        {/* Body */}
        <div style={{ padding:'16px 18px', display:'flex', flexDirection:'column', gap:12, overflowY:'auto' }}>
          {err && <div style={{ background:'var(--red-bg)', border:'1px solid var(--red-bd)', borderRadius:'var(--r)', padding:'8px 12px', fontSize:11.5, color:'var(--red)' }}>{err}</div>}

          {/* ── RENEWAL ── */}
          {type === 'renewal' && <>
            <Field label="Client Name *"><Input value={form.clientName||''} onChange={set('clientName')} placeholder="e.g. KARS INC" autoFocus /></Field>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <Field label="Policy Type *"><Select value={form.policyType||''} onChange={set('policyType')}>{POLICY_TYPES.map(p=><option key={p}>{p}</option>)}</Select></Field>
              <Field label="Policy ID"><Input value={form.policyId||''} onChange={set('policyId')} placeholder="e.g. GL-2024-001"/></Field>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <Field label="Expiry Date *"><Input type="date" value={form.expiryDate||''} onChange={set('expiryDate')}/></Field>
              <Field label="Status"><Select value={form.status||'Pending'} onChange={set('status')}>{['Pending','In Progress','Quoted','Cancelled'].map(s=><option key={s}>{s}</option>)}</Select></Field>
            </div>
            <Field label="Premium ($)"><Input type="number" value={form.premium||''} onChange={set('premium')} placeholder="Annual premium amount"/></Field>
            <Field label="Notes"><Textarea value={form.notes||''} onChange={set('notes')} placeholder="Optional notes…" rows={2}/></Field>
          </>}

          {/* ── QUOTE ── */}
          {type === 'quote' && <>
            <Field label="Client Name *"><Input value={form.clientName||''} onChange={set('clientName')} placeholder="e.g. Acme Corp" autoFocus/></Field>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <Field label="Policy Type *"><Select value={form.policyType||''} onChange={set('policyType')}>{POLICY_TYPES.map(p=><option key={p}>{p}</option>)}</Select></Field>
              <Field label="Stage"><Select value={form.stage||'pending'} onChange={set('stage')}>{['pending','submitted','bound'].map(s=><option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}</Select></Field>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <Field label="Estimated Premium"><Input value={form.premium||''} onChange={set('premium')} placeholder="e.g. Est. $4,200"/></Field>
              <Field label="Carrier"><Input value={form.carrier||''} onChange={set('carrier')} placeholder="e.g. Travelers"/></Field>
            </div>
            <Field label="Notes"><Textarea value={form.notes||''} onChange={set('notes')} placeholder="Optional notes…" rows={2}/></Field>
          </>}

          {/* ── TASK ── */}
          {type === 'task' && <>
            <Field label="Task Name *"><Input value={form.name||''} onChange={set('name')} placeholder="e.g. Send renewal quote to client" autoFocus/></Field>
            <Field label="Client / Account"><Input value={form.client||''} onChange={set('client')} placeholder="Optional client name"/></Field>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <Field label="Due Date"><Input type="date" value={form.dueDate||''} onChange={set('dueDate')}/></Field>
              <Field label="Priority"><Select value={form.priority||'Medium'} onChange={set('priority')}>{['High','Medium','Low'].map(p=><option key={p}>{p}</option>)}</Select></Field>
            </div>
            <Field label="Policy Type (optional)"><Select value={form.policyType||''} onChange={set('policyType')}><option value="">— None —</option>{POLICY_TYPES.map(p=><option key={p}>{p}</option>)}</Select></Field>
            <Field label="Notes"><Textarea value={form.notes||''} onChange={set('notes')} placeholder="Optional notes…" rows={2}/></Field>
          </>}

          {/* ── ACTIVITY ── */}
          {type === 'activity' && <>
            <Field label="Title *"><Input value={form.title||''} onChange={set('title')} placeholder="e.g. Called KARS INC re: renewal" autoFocus/></Field>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <Field label="Type"><Select value={form.type||'task'} onChange={set('type')}>{['task','renewal','call','quote','document'].map(t=><option key={t} value={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>)}</Select></Field>
              <Field label="Date"><Input type="date" value={form.date||''} onChange={set('date')}/></Field>
            </div>
            <Field label="Description"><Textarea value={form.description||''} onChange={set('description')} placeholder="What happened?" rows={2}/></Field>
          </>}

          {/* ── USER ── */}
          {type === 'user' && <>
            <Field label="Full Name"><Input value={form.name||''} onChange={set('name')} autoFocus/></Field>
            <Field label="Role / Title"><Input value={form.role||''} onChange={set('role')}/></Field>
            <Field label="Agency Name"><Input value={form.agency||''} onChange={set('agency')}/></Field>
            <Field label="Email"><Input type="email" value={form.email||''} onChange={set('email')}/></Field>
          </>}
        </div>

        {/* Footer */}
        <div style={{ padding:'12px 18px', borderTop:'1px solid var(--border)', display:'flex', gap:7, justifyContent:'flex-end', flexShrink:0 }}>
          {isEdit && onDelete && type !== 'user' && (
            <button onClick={onDelete} style={{ padding:'0 12px', height:30, borderRadius:'var(--r)', border:'1px solid var(--red-bd)', background:'var(--red-bg)', fontFamily:'var(--font)', fontSize:11.5, color:'var(--red)', cursor:'pointer', marginRight:'auto' }}>Delete</button>
          )}
          <button onClick={onClose} style={{ padding:'0 12px', height:30, borderRadius:'var(--r)', border:'1px solid var(--border2)', background:'transparent', fontFamily:'var(--font)', fontSize:11.5, color:'var(--text2)', cursor:'pointer' }}>Cancel</button>
          <button onClick={handleSave} style={{ padding:'0 14px', height:30, borderRadius:'var(--r)', border:'none', background:'var(--blue)', color:'#fff', fontFamily:'var(--font)', fontSize:11.5, fontWeight:500, cursor:'pointer', boxShadow:'0 0 12px rgba(59,130,246,0.25)' }}>{type === 'activity' ? 'Log' : 'Save'}</button>
        </div>
      </div>
    </div>
  );
}
