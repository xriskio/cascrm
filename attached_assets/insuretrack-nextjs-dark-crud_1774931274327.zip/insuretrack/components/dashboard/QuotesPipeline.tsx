'use client';

import { useState } from 'react';
import { QUOTES } from '@/lib/data';
import type { QuoteStage } from '@/types';

const STAGES: { id: QuoteStage; label: string; dot: string; color: string }[] = [
  { id: 'pending',   label: 'Pending',   dot: '🔵', color: 'var(--blue)'  },
  { id: 'submitted', label: 'Submitted', dot: '🟡', color: 'var(--amber)' },
  { id: 'bound',     label: 'Bound',     dot: '🟢', color: 'var(--green)' },
];

export default function QuotesPipeline() {
  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center',
        padding: '14px 18px',
        borderBottom: '1px solid var(--border)',
        gap: 10,
      }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.2px' }}>Quotes Pipeline</div>
        <span style={{
          fontSize: 11, fontWeight: 500,
          background: 'var(--surface2)', color: 'var(--text-2)',
          padding: '2px 7px', borderRadius: 20,
        }}>
          {QUOTES.length} active
        </span>
        <span style={{ marginLeft: 'auto', fontSize: 11.5, color: 'var(--green)', cursor: 'pointer', fontWeight: 500 }}>
          View all →
        </span>
      </div>

      {/* Kanban columns */}
      <div style={{ padding: '16px 18px', display: 'flex', gap: 10 }}>
        {STAGES.map(stage => {
          const cards = QUOTES.filter(q => q.stage === stage.id);
          return (
            <div key={stage.id} style={{
              flex: 1, minWidth: 0,
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius)',
              overflow: 'hidden',
            }}>
              {/* Column header */}
              <div style={{
                padding: '8px 11px',
                background: 'var(--surface2)',
                display: 'flex', alignItems: 'center', gap: 6,
                fontSize: 11, fontWeight: 600, color: 'var(--text-2)',
              }}>
                <span>{stage.dot}</span>
                {stage.label}
                <span style={{
                  marginLeft: 'auto',
                  fontSize: 10, background: 'var(--surface3)',
                  color: 'var(--text-3)', padding: '1px 5px',
                  borderRadius: 10, fontWeight: 500,
                }}>
                  {cards.length}
                </span>
              </div>

              {/* Cards */}
              <div style={{ padding: 6, display: 'flex', flexDirection: 'column', gap: 5 }}>
                {cards.map(quote => <PipelineCard key={quote.id} quote={quote} />)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── PIPELINE CARD ──────────────────────────────────────────────────────────────
function PipelineCard({ quote }: { quote: typeof QUOTES[0] }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{
        background: 'var(--surface)',
        border: `1px solid ${hovered ? 'var(--border-med)' : 'var(--border)'}`,
        borderRadius: 7,
        padding: '9px 10px',
        cursor: 'pointer',
        boxShadow: hovered ? 'var(--shadow-sm)' : 'none',
        transition: 'border-color 0.12s, box-shadow 0.12s',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div style={{
        fontSize: 11.5, fontWeight: 500, color: 'var(--text)',
        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
      }}>
        {quote.clientName}
      </div>
      <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 2 }}>
        {quote.policyType}
      </div>
      <div style={{
        fontSize: 11, fontWeight: 600, color: 'var(--text)',
        fontFamily: 'var(--mono)', marginTop: 5,
      }}>
        {quote.estimatedPremium}
      </div>
    </div>
  );
}
