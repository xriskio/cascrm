'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { SEARCH_DATA } from '@/lib/data';

// ── SEARCH DROPDOWN ────────────────────────────────────────────────────────────
function SearchDropdown({ onClose }: { onClose: () => void }) {
  return (
    <div style={{
      position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0,
      background: 'var(--surface)',
      border: '1px solid var(--border-med)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      zIndex: 100,
      overflow: 'hidden',
      animation: 'dropIn 0.15s ease',
    }}>
      {/* Clients */}
      <SearchSection label="Clients">
        {SEARCH_DATA.clients.map(c => (
          <SearchResult key={c.name} icon={c.initials} iconType="client" name={c.name} sub={c.sub} onClose={onClose} />
        ))}
      </SearchSection>

      {/* Renewals */}
      <SearchSection label="Renewals">
        {SEARCH_DATA.renewals.map(r => (
          <SearchResult key={r.name} icon="↻" iconType="renewal" name={r.name} sub={r.sub} onClose={onClose} />
        ))}
      </SearchSection>

      {/* Tasks & Quotes */}
      <SearchSection label="Quotes & Tasks">
        {SEARCH_DATA.tasks.map(t => (
          <SearchResult key={t.name} icon="T" iconType="task" name={t.name} sub={t.sub} onClose={onClose} />
        ))}
      </SearchSection>

      {/* Footer hints */}
      <div style={{
        padding: '8px 14px',
        borderTop: '1px solid var(--border)',
        display: 'flex', gap: 12,
      }}>
        {[['↑↓', 'navigate'], ['↵', 'open'], ['Esc', 'close']].map(([key, label]) => (
          <span key={key} style={{ fontSize: 10, color: 'var(--text-3)', display: 'flex', alignItems: 'center', gap: 4 }}>
            <kbd style={{
              background: 'var(--surface2)', border: '1px solid var(--border-med)',
              borderRadius: 3, padding: '1px 4px',
              fontFamily: 'var(--mono)', fontSize: 9,
            }}>{key}</kbd>
            {label}
          </span>
        ))}
      </div>
    </div>
  );
}

function SearchSection({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <>
      <div style={{
        padding: '10px 14px 5px',
        fontSize: 10, fontWeight: 600, letterSpacing: '0.7px',
        textTransform: 'uppercase', color: 'var(--text-3)',
      }}>
        {label}
      </div>
      {children}
    </>
  );
}

const ICON_COLORS: Record<string, { bg: string; color: string }> = {
  client:  { bg: 'var(--green-bg)',  color: 'var(--green)'  },
  renewal: { bg: 'var(--amber-bg)',  color: 'var(--amber)'  },
  task:    { bg: 'var(--purple-bg)', color: 'var(--purple)' },
  quote:   { bg: 'var(--blue-bg)',   color: 'var(--blue)'   },
};

function SearchResult({
  icon, iconType, name, sub, onClose,
}: {
  icon: string; iconType: string; name: string; sub: string; onClose: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  const colors = ICON_COLORS[iconType] ?? ICON_COLORS.client;

  return (
    <div
      style={{
        display: 'flex', alignItems: 'center', gap: 11,
        padding: '9px 14px', cursor: 'pointer',
        background: hovered ? 'var(--surface2)' : 'transparent',
        transition: 'background 0.1s',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClose}
    >
      <div style={{
        width: 30, height: 30, borderRadius: 8,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 12, flexShrink: 0, fontWeight: 600,
        background: colors.bg, color: colors.color,
      }}>
        {icon}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{name}</div>
        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 1 }}>{sub}</div>
      </div>
      <span style={{ color: 'var(--text-3)', fontSize: 12, opacity: hovered ? 1 : 0, transition: 'opacity 0.1s' }}>→</span>
    </div>
  );
}

// ── TOPBAR ─────────────────────────────────────────────────────────────────────
interface TopbarProps {
  onNewSubmission?: () => void;
}

export default function Topbar({ onNewSubmission }: TopbarProps) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [dateStr, setDateStr] = useState('');
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setDateStr(new Date().toLocaleDateString('en-US', {
      weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
    }));
  }, []);

  const closeSearch = useCallback(() => setSearchOpen(false), []);

  // Keyboard shortcut: /  to open search, Esc to close
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === '/' && document.activeElement?.tagName !== 'INPUT') {
        e.preventDefault();
        setSearchOpen(true);
        (searchRef.current?.querySelector('input') as HTMLInputElement)?.focus();
      }
      if (e.key === 'Escape') closeSearch();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [closeSearch]);

  // Click outside to close
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) closeSearch();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [closeSearch]);

  return (
    <div style={{
      height: 'var(--topbar-h)',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--border)',
      display: 'flex', alignItems: 'center',
      gap: 12, padding: '0 24px',
      flexShrink: 0, zIndex: 10,
    }}>
      {/* Left */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: '-0.3px' }}>Dashboard</div>
        <div style={{ fontSize: 12, color: 'var(--text-3)', fontFamily: 'var(--mono)' }}>{dateStr}</div>
      </div>

      {/* Search */}
      <div ref={searchRef} style={{ flex: 1, maxWidth: 480, position: 'relative' }}>
        <div
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: 'var(--surface2)',
            border: `1px solid ${searchOpen ? 'var(--green-mid)' : 'var(--border)'}`,
            boxShadow: searchOpen ? '0 0 0 3px rgba(77,175,119,0.15)' : 'none',
            borderRadius: 'var(--radius)',
            padding: '0 12px', height: 36, cursor: 'text',
            transition: 'border-color 0.15s, box-shadow 0.15s',
          }}
          onClick={() => {
            setSearchOpen(true);
            (searchRef.current?.querySelector('input') as HTMLInputElement)?.focus();
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            style={{
              flex: 1, border: 'none', background: 'transparent',
              fontFamily: 'var(--font)', fontSize: 13, color: 'var(--text)', outline: 'none',
            }}
            placeholder="Search clients, policies, renewals…"
            onFocus={() => setSearchOpen(true)}
          />
          <span style={{
            fontSize: 10, fontFamily: 'var(--mono)',
            background: 'var(--surface3)', color: 'var(--text-3)',
            padding: '2px 5px', borderRadius: 4,
            border: '1px solid var(--border-med)', flexShrink: 0,
          }}>/</span>
        </div>

        {searchOpen && <SearchDropdown onClose={closeSearch} />}
      </div>

      {/* Right actions */}
      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
        <IconButton title="Notifications" badge>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
        </IconButton>

        <IconButton title="Refresh data">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="23 4 23 10 17 10"/>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
          </svg>
        </IconButton>

        <button
          onClick={onNewSubmission}
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '0 14px', height: 34,
            background: 'var(--text)', color: '#fff',
            border: 'none', borderRadius: 'var(--radius)',
            fontFamily: 'var(--font)', fontSize: 13, fontWeight: 500,
            cursor: 'pointer', whiteSpace: 'nowrap',
            transition: 'opacity 0.12s',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.opacity = '0.85'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.opacity = '1'; }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="12" y1="5" x2="12" y2="19"/>
            <line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
          New Submission
        </button>
      </div>
    </div>
  );
}

// ── ICON BUTTON ────────────────────────────────────────────────────────────────
function IconButton({ children, title, badge }: { children: React.ReactNode; title: string; badge?: boolean }) {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      title={title}
      style={{
        width: 34, height: 34,
        borderRadius: 'var(--radius)',
        border: '1px solid var(--border)',
        background: hovered ? 'var(--surface2)' : 'transparent',
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', transition: 'background 0.12s',
        color: 'var(--text-2)',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {children}
      {badge && (
        <span style={{
          position: 'absolute', top: 7, right: 7,
          width: 7, height: 7, borderRadius: '50%',
          background: 'var(--red)',
          border: '1.5px solid var(--surface)',
        }}/>
      )}
    </button>
  );
}
