'use client';

import { useState } from 'react';
import { RENEWALS } from '@/lib/data';
import type { RenewalStatus } from '@/types';

type Filter = 'all' | 'urgent' | 'pending' | 'quoted';

const FILTER_TABS: { label: string; value: Filter }[] = [
  { label: 'All',     value: 'all'     },
  { label: 'Urgent',  value: 'urgent'  },
  { label: 'Pending', value: 'pending' },
  { label: 'Quoted',  value: 'quoted'  },
];

// Which statuses show under each tab
const FILTER_MAP: Record<Filter, RenewalStatus[]> = {
  all:     ['urgent', 'pending', 'progress', 'quoted'],
  urgent:  ['urgent'],
  pending: ['urgent', 'pending', 'progress'],
  quoted:  ['quoted'],
};

// Days chip styling
function getDaysChip(days: number) {
  if (days <= 20)  return { background: 'var(--red-bg)',   color: 'var(--red)',   label: `${days} days` };
  if (days <= 35)  return { background: 'var(--amber-bg)', color: 'var(--amber)', label: `${days} days` };
  return              { background: 'var(--green-bg)', color: 'var(--green)', label: `${days} days` };
}

// Status dot
const STATUS_CONFIG: Record<RenewalStatus, { dot: string; label: string }> = {
  urgent:   { dot: 'var(--red)',   label: 'Pending'     },
  pending:  { dot: 'var(--amber)', label: 'Pending'     },
  progress: { dot: 'var(--blue)',  label: 'In Progress' },
  quoted:   { dot: 'var(--green)', label: 'Quoted'      },
};

export default function RenewalTable() {
  const [activeFilter, setActiveFilter] = useState<Filter>('all');

  const visible = RENEWALS.filter(r => FILTER_MAP[activeFilter].includes(r.status));

  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center',
        padding: '14px 18px',
        borderBottom: '1px solid var(--border)',
        gap: 10,
      }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--text)', letterSpacing: '-0.2px' }}>
          Upcoming Renewals
        </div>
        <span style={{
          fontSize: 11, fontWeight: 500,
          background: 'var(--surface2)', color: 'var(--text-2)',
          padding: '2px 7px', borderRadius: 20,
        }}>
          {RENEWALS.length} total
        </span>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
          {/* Filter tabs */}
          <div style={{
            display: 'flex', background: 'var(--surface2)',
            borderRadius: 8, padding: 2, gap: 1,
          }}>
            {FILTER_TABS.map(tab => (
              <button
                key={tab.value}
                onClick={() => setActiveFilter(tab.value)}
                style={{
                  padding: '4px 10px', fontSize: 11, fontWeight: 500,
                  borderRadius: 6, border: 'none', cursor: 'pointer',
                  fontFamily: 'var(--font)',
                  background: activeFilter === tab.value ? 'var(--surface)' : 'transparent',
                  color: activeFilter === tab.value ? 'var(--text)' : 'var(--text-3)',
                  boxShadow: activeFilter === tab.value ? 'var(--shadow-sm)' : 'none',
                  transition: 'background 0.12s, color 0.12s',
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <ViewAllBtn />
        </div>
      </div>

      {/* Column headers */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 120px 100px 110px 36px',
        padding: '8px 18px',
        background: 'var(--surface2)',
        fontSize: 10, fontWeight: 600, letterSpacing: '0.6px',
        textTransform: 'uppercase', color: 'var(--text-3)',
      }}>
        <span>Client</span>
        <span>Policy ID</span>
        <span>Expires</span>
        <span>Status</span>
        <span />
      </div>

      {/* Rows */}
      {visible.length === 0 ? (
        <div style={{ padding: '24px 18px', textAlign: 'center', color: 'var(--text-3)', fontSize: 13 }}>
          No renewals match this filter
        </div>
      ) : (
        visible.map(renewal => {
          const chip = getDaysChip(renewal.daysUntilExpiry);
          const status = STATUS_CONFIG[renewal.status];
          return <RenewalRow key={renewal.id} renewal={renewal} chip={chip} status={status} />;
        })
      )}
    </div>
  );
}

// ── ROW ─────────────────────────────────────────────────────────────────────────
function RenewalRow({
  renewal, chip, status,
}: {
  renewal: typeof RENEWALS[0];
  chip: { background: string; color: string; label: string };
  status: { dot: string; label: string };
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '1fr 120px 100px 110px 36px',
        alignItems: 'center',
        padding: '12px 18px',
        borderBottom: '1px solid var(--border)',
        cursor: 'pointer',
        background: hovered ? 'var(--surface2)' : 'transparent',
        transition: 'background 0.1s',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Client */}
      <div>
        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{renewal.clientName}</div>
        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{renewal.policyType}</div>
      </div>

      {/* Policy ID */}
      <div style={{ fontSize: 11.5, color: 'var(--text-2)', fontFamily: 'var(--mono)' }}>
        {renewal.policyId}
      </div>

      {/* Days chip */}
      <div>
        <span style={{
          display: 'inline-flex', alignItems: 'center',
          fontSize: 11, fontWeight: 600,
          padding: '3px 9px', borderRadius: 20,
          background: chip.background, color: chip.color,
        }}>
          {chip.label}
        </span>
      </div>

      {/* Status */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--text-2)' }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: status.dot, flexShrink: 0 }}/>
        {status.label}
      </div>

      {/* Arrow */}
      <div style={{
        opacity: hovered ? 1 : 0, transition: 'opacity 0.1s',
        cursor: 'pointer', color: 'var(--text-3)', fontSize: 14,
        width: 28, height: 28, borderRadius: 6,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        →
      </div>
    </div>
  );
}

function ViewAllBtn() {
  const [hovered, setHovered] = useState(false);
  return (
    <span
      style={{
        fontSize: 11.5, color: 'var(--green)', cursor: 'pointer',
        fontWeight: 500, padding: '4px 8px', borderRadius: 6,
        background: hovered ? 'var(--green-bg)' : 'transparent',
        transition: 'background 0.12s',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      View all →
    </span>
  );
}
