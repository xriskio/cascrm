'use client';

import { useState } from 'react';
import { STAT_CARDS } from '@/lib/data';
import type { StatVariant } from '@/types';

const VARIANT_COLORS: Record<StatVariant, string> = {
  red:   'var(--red)',
  amber: 'var(--amber)',
  blue:  'var(--blue)',
  green: 'var(--green)',
};

const TOP_BAR_COLORS: Record<StatVariant, string> = {
  red:   'var(--red)',
  amber: '#D4960A',
  blue:  'var(--blue)',
  green: 'var(--green)',
};

export default function StatCards() {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 12,
    }}>
      {STAT_CARDS.map((card, i) => (
        <StatCard key={card.id} card={card} delay={i * 0.05} />
      ))}
    </div>
  );
}

function StatCard({ card, delay }: { card: typeof STAT_CARDS[0]; delay: number }) {
  const [hovered, setHovered] = useState(false);
  const color = VARIANT_COLORS[card.variant];
  const topColor = TOP_BAR_COLORS[card.variant];

  return (
    <div
      style={{
        background: 'var(--surface)',
        border: `1px solid ${hovered ? 'var(--border-med)' : 'var(--border)'}`,
        borderRadius: 'var(--radius-lg)',
        padding: '16px 18px',
        cursor: 'pointer',
        transition: 'border-color 0.15s, transform 0.15s, box-shadow 0.15s',
        position: 'relative',
        overflow: 'hidden',
        transform: hovered ? 'translateY(-1px)' : 'none',
        boxShadow: hovered ? 'var(--shadow-sm)' : 'none',
        animation: `fadeUp 0.3s ease ${delay}s both`,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Colored top strip */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 3,
        background: topColor,
      }}/>

      {/* Label row */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        fontSize: 11, fontWeight: 500, letterSpacing: '0.4px',
        color: 'var(--text-3)', textTransform: 'uppercase',
        marginBottom: 8, marginTop: 4,
      }}>
        {card.label}
        {card.badge && (
          <span style={{
            fontSize: 9.5, fontWeight: 500,
            padding: '2px 6px', borderRadius: 20,
            background: card.variant === 'amber' ? 'var(--amber-bg)' : 'var(--red-bg)',
            color: card.variant === 'amber' ? 'var(--amber)' : 'var(--red)',
          }}>
            {card.badge}
          </span>
        )}
      </div>

      {/* Big number */}
      <div style={{
        fontSize: 36, fontWeight: 300, letterSpacing: '-1.5px',
        lineHeight: 1, marginBottom: 6,
        fontFamily: 'var(--mono)',
        color,
      }}>
        {card.value}
      </div>

      {/* Sub text */}
      <div style={{ fontSize: 11.5, color: 'var(--text-3)' }}>
        {card.subtext}
      </div>
    </div>
  );
}
