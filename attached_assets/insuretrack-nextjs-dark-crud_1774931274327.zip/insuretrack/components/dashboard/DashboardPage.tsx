'use client';
import { useState, useCallback } from 'react';
import { useDashboard, daysUntil, fmtDate, uid } from '@/lib/store';
import { Toast, ConfirmDialog, AiDot, Chip, StatusPill, EmptyState, Card, CardHeader, CardTitle, CardCount, PillTabs, LinkBtn, AddRowBtn, RowActions, PrimaryBtn } from './ui';
import CrudModal from './CrudModal';
import type { Renewal, Quote, Task, Activity } from '@/types';

// ────────────────────────────────────────────────────────────────────────────
// TYPES
// ────────────────────────────────────────────────────────────────────────────
type ModalConfig = { type: 'renewal'|'quote'|'task'|'activity'|'user'; stage?: string; existing?: Renewal|Quote|Task|Activity|null; } | null;
type ConfirmConfig = { title: string; sub: string; onConfirm: () => void; } | null;
type ToastState = { msg: string; color: 'green'|'red'|'blue'; visible: boolean };

// ────────────────────────────────────────────────────────────────────────────
// MAIN PAGE
// ────────────────────────────────────────────────────────────────────────────
export default function DashboardPage() {
  const db = useDashboard();
  const [modal, setModal]     = useState<ModalConfig>(null);
  const [confirm, setConfirm] = useState<ConfirmConfig>(null);
  const [toast, setToast]     = useState<ToastState>({ msg:'', color:'green', visible:false });
  const [searchQ, setSearchQ] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [renewFilter, setRenewFilter] = useState('All');
  const [taskFilter, setTaskFilter]   = useState('All');
  const [actFilter, setActFilter]     = useState('All');

  const showToast = useCallback((msg: string, color: 'green'|'red'|'blue' = 'green') => {
    setToast({ msg, color, visible: true });
    setTimeout(() => setToast(p => ({ ...p, visible: false })), 2800);
  }, []);

  const openModal = (type: ModalConfig['type'], stage?: string, existing?: any) =>
    setModal({ type, stage, existing: existing ?? null });

  const askConfirm = (title: string, sub: string, onConfirm: () => void) =>
    setConfirm({ title, sub, onConfirm });

  // ── SAVE HANDLERS ──────────────────────────────────────────────────────────
  function handleSave(data: Record<string, string>) {
    if (!modal) return;
    const isEdit = !!modal.existing;

    if (modal.type === 'renewal') {
      if (isEdit) db.updateRenewal((modal.existing as Renewal).id, data as any);
      else db.addRenewal(data as any);
      showToast(isEdit ? 'Renewal updated' : 'Renewal added');
    }
    if (modal.type === 'quote') {
      if (isEdit) db.updateQuote((modal.existing as Quote).id, data as any);
      else db.addQuote(data as any);
      showToast(isEdit ? 'Quote updated' : 'Quote added');
    }
    if (modal.type === 'task') {
      if (isEdit) db.updateTask((modal.existing as Task).id, data as any);
      else db.addTask(data as any);
      showToast(isEdit ? 'Task updated' : 'Task added');
    }
    if (modal.type === 'activity') {
      db.addActivity({ ...data, id: uid() } as any);
      showToast('Activity logged');
    }
    if (modal.type === 'user') {
      db.updateUser(data as any);
      showToast('Profile saved');
    }
    setModal(null);
  }

  function handleDelete() {
    if (!modal?.existing) return;
    const id = (modal.existing as any).id;
    const label = (modal.existing as any).clientName || (modal.existing as any).name || 'item';
    askConfirm(`Delete "${label}"?`, 'This will permanently remove this item.', () => {
      if (modal.type === 'renewal')  db.deleteRenewal(id);
      if (modal.type === 'quote')    db.deleteQuote(id);
      if (modal.type === 'task')     db.deleteTask(id);
      setModal(null);
      showToast('Deleted', 'red');
    });
  }

  // ── SEARCH ────────────────────────────────────────────────────────────────
  const q = searchQ.toLowerCase().trim();
  const srRenewals = q ? db.state.renewals.filter(r => r.clientName?.toLowerCase().includes(q) || r.policyId?.toLowerCase().includes(q)) : [];
  const srTasks    = q ? db.state.tasks.filter(t => t.name?.toLowerCase().includes(q)) : [];
  const srQuotes   = q ? db.state.quotes.filter(qt => qt.clientName?.toLowerCase().includes(q)) : [];
  const hasResults = srRenewals.length || srTasks.length || srQuotes.length;

  // ── DERIVED ───────────────────────────────────────────────────────────────
  const sortedRenewals = db.state.renewals.slice().sort((a,b) => daysUntil(a.expiryDate) - daysUntil(b.expiryDate));
  const filteredRenewals = sortedRenewals.filter(r => {
    if (renewFilter === 'All') return true;
    if (renewFilter === 'Urgent') return daysUntil(r.expiryDate) <= 20;
    if (renewFilter === 'Pending') return r.status === 'Pending' || r.status === 'In Progress';
    if (renewFilter === 'Quoted') return r.status === 'Quoted';
    return true;
  });

  const sortedTasks = db.state.tasks.slice().sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    return (a.dueDate||'9999') < (b.dueDate||'9999') ? -1 : 1;
  });
  const filteredTasks = sortedTasks.filter(t => {
    if (taskFilter === 'All') return true;
    if (taskFilter === 'Overdue') return !t.done && t.dueDate && daysUntil(t.dueDate) < 0;
    if (taskFilter === 'Pending') return !t.done;
    if (taskFilter === 'Done') return t.done;
    return true;
  });

  const filteredActivity = db.state.activity.slice().reverse().filter(a => {
    if (actFilter === 'All') return true;
    return a.type === actFilter.toLowerCase();
  });

  return (
    <>
      {/* ── APP SHELL ── */}
      <div style={{ display:'flex', height:'100vh', overflow:'hidden', background:'var(--bg)' }}>

        {/* SIDEBAR */}
        <Sidebar db={db} onOpenUser={() => openModal('user', undefined, db.state.user)}
          pendingTasks={db.pendingTasks} urgentRenewals={db.urgentRenewals}
          pendingQuotes={db.state.quotes.filter(q=>q.stage==='pending').length} />

        <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden', minWidth:0 }}>

          {/* TOPBAR */}
          <Topbar
            searchQ={searchQ} setSearchQ={setSearchQ}
            searchOpen={searchOpen} setSearchOpen={setSearchOpen}
            srRenewals={srRenewals} srTasks={srTasks} srQuotes={srQuotes} hasResults={hasResults}
            onEditRenewal={r => openModal('renewal', undefined, r)}
            onEditTask={t => openModal('task', undefined, t)}
            onNew={() => openModal('renewal')}
          />

          {/* CONTENT */}
          <div style={{ flex:1, overflowY:'auto', padding:18, display:'flex', flexDirection:'column', gap:14 }}>

            {/* AI STRIP */}
            <AIStrip renewals={db.state.renewals} tasks={db.state.tasks} quotes={db.state.quotes} urgentRenewals={db.urgentRenewals} overdueTasks={db.overdueTasks} />

            {/* STATS */}
            <StatsRow db={db} />

            <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:12 }}>
              <div style={{ display:'flex', flexDirection:'column', gap:12, minWidth:0 }}>

                {/* RENEWALS */}
                <RenewalSection renewals={filteredRenewals} total={db.state.renewals.length} filter={renewFilter} setFilter={setRenewFilter}
                  onAdd={() => openModal('renewal')} onEdit={r => openModal('renewal', undefined, r)}
                  onDelete={r => askConfirm(`Delete "${r.clientName}"?`, 'This cannot be undone.', () => { db.deleteRenewal(r.id); showToast('Deleted','red'); })} />

                {/* QUOTES */}
                <QuotesSection quotes={db.state.quotes}
                  onAdd={stage => openModal('quote', stage)} onEdit={q => openModal('quote', q.stage, q)}
                  onDelete={q => askConfirm(`Delete "${q.clientName}"?`, 'This cannot be undone.', () => { db.deleteQuote(q.id); showToast('Deleted','red'); })} />

                {/* ACTIVITY */}
                <ActivitySection activity={filteredActivity} filter={actFilter} setFilter={setActFilter}
                  onAdd={() => openModal('activity')}
                  onDelete={a => askConfirm('Delete this activity?', 'This cannot be undone.', () => { db.deleteActivity(a.id); showToast('Deleted','red'); })} />
              </div>

              <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                {/* MINI PAIR */}
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                  <MiniCard label="Overdue" value={db.overdueTasks} color="var(--red)" sub="tasks past due"/>
                  <MiniCard label="Done" value={db.doneTasks} color="var(--green)" sub="tasks completed"/>
                </div>

                {/* TASKS */}
                <TaskSection tasks={filteredTasks} allTasks={db.state.tasks} filter={taskFilter} setFilter={setTaskFilter}
                  onToggle={id => { db.toggleTask(id); showToast('Task updated'); }}
                  onAdd={() => openModal('task')} onEdit={t => openModal('task', undefined, t)}
                  onDelete={t => askConfirm(`Delete "${t.name}"?`, 'This cannot be undone.', () => { db.deleteTask(t.id); showToast('Deleted','red'); })}
                  overdueTasks={db.overdueTasks} doneTasks={db.doneTasks} pendingTasks={db.pendingTasks} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL */}
      {modal && (
        <CrudModal type={modal.type} defaultStage={modal.stage} existing={modal.existing}
          onSave={handleSave} onDelete={modal.existing ? handleDelete : undefined} onClose={() => setModal(null)} />
      )}

      {/* CONFIRM */}
      {confirm && <ConfirmDialog title={confirm.title} sub={confirm.sub} onConfirm={() => { confirm.onConfirm(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}

      {/* TOAST */}
      <Toast message={toast.msg} color={toast.color} visible={toast.visible} />
    </>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// SIDEBAR
// ────────────────────────────────────────────────────────────────────────────
function Sidebar({ db, onOpenUser, pendingTasks, urgentRenewals, pendingQuotes }: any) {
  const { name, role } = db.state.user;
  const initials = (name||'?').split(' ').map((w:string)=>w[0]).join('').slice(0,2).toUpperCase();
  const NAV = [
    { section:'Overview', items:[{label:'Dashboard',icon:'⊞'},{label:'My Tasks',icon:'✓',badge:pendingTasks,bc:'amber'},{label:'Reports',icon:'◈'}]},
    { section:'Insurance', items:[{label:'Renewals',icon:'↻',badge:urgentRenewals,bc:'red'},{label:'Submissions',icon:'◻'},{label:'Quotes',icon:'$',badge:pendingQuotes,bc:'blue'},{label:'Market Submissions',icon:'⬡'}]},
    { section:'Clients', items:[{label:'Clients',icon:'◉'},{label:'Leads',icon:'◎'},{label:'Call Log',icon:'◌'}]},
    { section:'Operations', items:[{label:'Service Requests',icon:'⚙'},{label:'Inspections',icon:'◈'},{label:'Documents',icon:'◧'},{label:'Carrier Contacts',icon:'⬣'}]},
    { section:'Sync & API', items:[{label:'QQCatalyst Sync',icon:'⟳'},{label:'Settings',icon:'◈'}]},
  ];
  const [active, setActive] = useState('Dashboard');
  const badgeStyle = (c:string) => ({ marginLeft:'auto', fontSize:9.5, fontWeight:600, padding:'1px 5px', borderRadius:20, flexShrink:0, background:`var(--${c}-bg)`, color:`var(--${c})`, border:`1px solid var(--${c}-bd)` });
  return (
    <aside style={{ width:210, minWidth:210, background:'var(--bg1)', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ padding:'18px 14px 14px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:9 }}>
        <div style={{ width:28, height:28, borderRadius:7, background:'linear-gradient(135deg,#3B82F6,#A855F7)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, fontWeight:700, color:'#fff' }}>IT</div>
        <div><div style={{ fontSize:14, fontWeight:600, letterSpacing:'-0.3px' }}>InsureTrack</div><div style={{ fontSize:9.5, color:'var(--text3)', marginTop:1 }}>AI-Powered Portal</div></div>
      </div>
      <nav style={{ flex:1, overflowY:'auto', padding:8 }}>
        {NAV.map(g => (
          <div key={g.section}>
            <div style={{ fontSize:9, fontWeight:600, letterSpacing:'1px', textTransform:'uppercase', color:'var(--text4)', padding:'10px 6px 4px', marginTop:2 }}>{g.section}</div>
            {g.items.map(item => (
              <div key={item.label} onClick={() => setActive(item.label)} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 8px', borderRadius:'var(--r)', cursor:'pointer', fontSize:12, fontWeight: active===item.label ? 500 : 400, color: active===item.label ? 'var(--text)' : 'var(--text2)', background: active===item.label ? 'var(--bg3)' : 'transparent', position:'relative', transition:'all 0.1s' }}>
                {active===item.label && <span style={{ position:'absolute', left:0, top:'20%', bottom:'20%', width:2, borderRadius:2, background:'var(--blue)' }}/>}
                <span style={{ width:15, textAlign:'center', fontSize:13, flexShrink:0, opacity: active===item.label ? 1 : 0.7 }}>{item.icon}</span>
                {item.label}
                {(item as any).badge > 0 && <span style={badgeStyle((item as any).bc)}>{(item as any).badge}</span>}
              </div>
            ))}
          </div>
        ))}
      </nav>
      <div style={{ padding:'10px 8px', borderTop:'1px solid var(--border)' }}>
        <div onClick={onOpenUser} style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 8px', borderRadius:'var(--r)', cursor:'pointer' }}>
          <div style={{ width:26, height:26, borderRadius:'50%', background:'linear-gradient(135deg,#3B82F6,#A855F7)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, color:'#fff', flexShrink:0 }}>{initials}</div>
          <div><div style={{ fontSize:11.5, fontWeight:500 }}>{name||'Your Name'}</div><div style={{ fontSize:9.5, color:'var(--text3)' }}>{role||'Agent'}</div></div>
          <span style={{ marginLeft:'auto', color:'var(--text3)', fontSize:11 }}>⌄</span>
        </div>
      </div>
    </aside>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// TOPBAR
// ────────────────────────────────────────────────────────────────────────────
function Topbar({ searchQ, setSearchQ, searchOpen, setSearchOpen, srRenewals, srTasks, srQuotes, hasResults, onEditRenewal, onEditTask, onNew }: any) {
  const dateStr = new Date().toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
  return (
    <div style={{ height:52, background:'var(--bg1)', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:10, padding:'0 20px', flexShrink:0 }}>
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <div style={{ fontSize:14, fontWeight:600, letterSpacing:'-0.3px' }}>Dashboard</div>
        <div style={{ fontSize:11, color:'var(--text3)', fontFamily:'var(--mono)' }}>{dateStr}</div>
      </div>

      {/* SEARCH */}
      <div style={{ flex:1, maxWidth:420, position:'relative' }}>
        <div style={{ display:'flex', alignItems:'center', gap:7, background:'var(--bg2)', border:`1px solid ${searchOpen?'rgba(59,130,246,0.4)':'var(--border2)'}`, boxShadow: searchOpen ? '0 0 0 3px rgba(59,130,246,0.08)' : 'none', borderRadius:'var(--r)', padding:'0 11px', height:32, cursor:'text', transition:'all 0.15s' }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input value={searchQ} onChange={e=>{setSearchQ(e.target.value);setSearchOpen(e.target.value.length>0);}} onFocus={()=>searchQ&&setSearchOpen(true)} onBlur={()=>setTimeout(()=>setSearchOpen(false),180)} placeholder="Search clients, policies, tasks…" style={{ flex:1, border:'none', background:'transparent', fontFamily:'var(--font)', fontSize:12, color:'var(--text)', outline:'none' }}/>
          <span style={{ fontSize:9.5, fontFamily:'var(--mono)', background:'var(--bg3)', color:'var(--text3)', padding:'1px 4px', borderRadius:3, border:'1px solid var(--border2)' }}>/</span>
        </div>
        {searchOpen && (
          <div style={{ position:'absolute', top:'calc(100% + 5px)', left:0, right:0, background:'var(--bg2)', border:'1px solid var(--border2)', borderRadius:'var(--rl)', boxShadow:'0 16px 40px rgba(0,0,0,0.6)', zIndex:200, overflow:'hidden', animation:'dropIn 0.15s ease' }}>
            {!hasResults && <div style={{ padding:'20px', textAlign:'center', color:'var(--text3)', fontSize:12 }}>No results for "{searchQ}"</div>}
            {srRenewals.length > 0 && <><div style={{ fontSize:9.5, fontWeight:600, letterSpacing:'0.7px', textTransform:'uppercase', color:'var(--text3)', padding:'10px 12px 4px' }}>Renewals</div>{srRenewals.slice(0,3).map((r:Renewal)=><SearchItem key={r.id} icon="↻" type="r" name={r.clientName} sub={`${r.policyType} · ${daysUntil(r.expiryDate)}d remaining`} onClick={()=>onEditRenewal(r)}/>)}</>}
            {srTasks.length > 0 && <><div style={{ fontSize:9.5, fontWeight:600, letterSpacing:'0.7px', textTransform:'uppercase', color:'var(--text3)', padding:'10px 12px 4px' }}>Tasks</div>{srTasks.slice(0,3).map((t:Task)=><SearchItem key={t.id} icon="T" type="t" name={t.name} sub={`${t.priority} priority · ${t.done?'Done':'Pending'}`} onClick={()=>onEditTask(t)}/>)}</>}
            {srQuotes.length > 0 && <><div style={{ fontSize:9.5, fontWeight:600, letterSpacing:'0.7px', textTransform:'uppercase', color:'var(--text3)', padding:'10px 12px 4px' }}>Quotes</div>{srQuotes.slice(0,3).map((q:Quote)=><SearchItem key={q.id} icon="$" type="q" name={q.clientName} sub={`${q.policyType} · ${q.stage}`} onClick={()=>{}}/>)}</>}
          </div>
        )}
      </div>

      <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:6 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6, padding:'4px 10px', borderRadius:20, background:'var(--blue-bg)', border:'1px solid var(--blue-bd)', fontSize:10.5, fontWeight:500, color:'var(--blue)', cursor:'pointer' }}>
          <AiDot/> AI Copilot
        </div>
        <PrimaryBtn onClick={onNew}>+ New</PrimaryBtn>
      </div>
    </div>
  );
}

function SearchItem({ icon, type, name, sub, onClick }: any) {
  const [h,setH] = useState(false);
  const colors: any = { r:{bg:'var(--amber-bg)',c:'var(--amber)',bd:'var(--amber-bd)'}, t:{bg:'var(--purple-bg)',c:'var(--purple)',bd:'var(--purple-bd)'}, q:{bg:'var(--blue-bg)',c:'var(--blue)',bd:'var(--blue-bd)'} };
  const col = colors[type];
  return <div onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{ display:'flex', alignItems:'center', gap:9, padding:'8px 12px', cursor:'pointer', background:h?'var(--bg3)':'transparent' }}>
    <div style={{ width:28, height:28, borderRadius:7, display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:600, flexShrink:0, background:col.bg, color:col.c, border:`1px solid ${col.bd}` }}>{icon}</div>
    <div><div style={{ fontSize:12, fontWeight:500 }}>{name}</div><div style={{ fontSize:10, color:'var(--text3)', marginTop:1 }}>{sub}</div></div>
    <span style={{ marginLeft:'auto', color:'var(--text3)', opacity:h?1:0 }}>→</span>
  </div>;
}

// ────────────────────────────────────────────────────────────────────────────
// AI STRIP
// ────────────────────────────────────────────────────────────────────────────
function AIStrip({ renewals, tasks, quotes, urgentRenewals, overdueTasks }: any) {
  const insights = [];
  if (urgentRenewals) insights.push({ chip:'red', label:`${urgentRenewals} renewal${urgentRenewals>1?'s':''} expiring within 20 days` });
  if (overdueTasks)   insights.push({ chip:'amber', label:`${overdueTasks} task${overdueTasks>1?'s':''} past due date` });
  const submitted = quotes.filter((q:Quote)=>q.stage==='submitted').length;
  if (submitted)      insights.push({ chip:'green', label:`${submitted} quote${submitted>1?'s':''} awaiting carrier response` });

  return (
    <div style={{ background:'var(--bg2)', border:'1px solid var(--blue-bd)', borderRadius:'var(--r)', padding:'10px 14px', display:'flex', alignItems:'center', gap:12, position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', left:0, top:0, bottom:0, width:2, background:'linear-gradient(180deg,var(--blue),var(--purple))' }}/>
      <div style={{ display:'flex', alignItems:'center', gap:5, fontSize:10, fontWeight:600, color:'var(--blue)', letterSpacing:'0.5px', textTransform:'uppercase', flexShrink:0 }}>
        <AiDot/> AI Insights
      </div>
      <div style={{ display:'flex', gap:14, flexWrap:'wrap', flex:1, fontSize:11 }}>
        {!insights.length
          ? <span style={{ color:'var(--text3)', fontStyle:'italic' }}>Add data to unlock AI insights</span>
          : insights.map((ins, i) => (
              <span key={i} style={{ color:'var(--text2)', display:'flex', alignItems:'center', gap:4 }}>
                <span style={{ fontSize:9.5, fontWeight:600, padding:'1px 6px', borderRadius:10, background:`var(--${ins.chip}-bg)`, color:`var(--${ins.chip})`, border:`1px solid var(--${ins.chip}-bd)` }}>{ins.chip==='red'?'Urgent':ins.chip==='amber'?'Overdue':'Follow-up'}</span>
                {ins.label}
              </span>
            ))
        }
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// STATS ROW
// ────────────────────────────────────────────────────────────────────────────
function StatsRow({ db }: any) {
  const cards = [
    { label:'Pending Tasks',     value:db.pendingTasks,              color:'amber', sub: db.pendingTasks ? `${db.overdueTasks} overdue` : 'No tasks yet' },
    { label:'Upcoming Renewals', value:db.state.renewals.length,     color:'red',   sub: db.state.renewals.length ? `${db.urgentRenewals} urgent` : 'No renewals yet' },
    { label:'Active Quotes',     value:db.state.quotes.length,       color:'blue',  sub: db.state.quotes.length ? `${db.state.quotes.filter((q:Quote)=>q.stage==='pending').length} pending` : 'No quotes yet' },
    { label:'Active Clients',    value:db.state.renewals.length,     color:'green', sub: 'Tracked policies' },
  ];
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10 }}>
      {cards.map((c,i) => (
        <div key={i} style={{ background:'var(--bg2)', border:`1px solid rgba(${c.color==='amber'?'245,158,11':c.color==='red'?'239,68,68':c.color==='blue'?'59,130,246':'34,197,94'},0.2)`, borderRadius:'var(--rl)', padding:'14px 16px', cursor:'pointer', position:'relative', overflow:'hidden', animation:`fadeUp 0.3s ease ${i*0.05}s both`, transition:'transform 0.15s' }}>
          <div style={{ position:'absolute', top:0, left:0, right:0, height:1, background:`linear-gradient(90deg,var(--${c.color}),transparent)` }}/>
          <div style={{ fontSize:10, fontWeight:500, letterSpacing:'0.5px', textTransform:'uppercase', color:'var(--text3)', marginBottom:10 }}>{c.label}</div>
          <div style={{ fontSize:38, fontWeight:300, letterSpacing:'-2px', lineHeight:1, marginBottom:6, fontFamily:'var(--mono)', color:`var(--${c.color})` }}>{c.value}</div>
          <div style={{ fontSize:11, color:'var(--text3)' }}>{c.sub}</div>
          <div style={{ position:'absolute', right:-20, bottom:-20, width:80, height:80, borderRadius:'50%', background:`var(--${c.color})`, opacity:0.07, filter:'blur(20px)' }}/>
        </div>
      ))}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// RENEWALS
// ────────────────────────────────────────────────────────────────────────────
function RenewalSection({ renewals, total, filter, setFilter, onAdd, onEdit, onDelete }: any) {
  return (
    <Card id="renewals-section">
      <CardHeader>
        <CardTitle>Upcoming Renewals</CardTitle>
        <CardCount>{total} total</CardCount>
        <div style={{ marginLeft:'auto', display:'flex', gap:5 }}>
          <PillTabs tabs={['All','Urgent','Pending','Quoted']} active={filter} onChange={setFilter}/>
          <LinkBtn onClick={onAdd}>+ Add</LinkBtn>
        </div>
      </CardHeader>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 108px 86px 100px 60px', padding:'7px 16px', background:'var(--bg3)', fontSize:9.5, fontWeight:600, letterSpacing:'0.6px', textTransform:'uppercase', color:'var(--text3)' }}>
        <span>Client</span><span>Policy ID</span><span>Expires</span><span>Status</span><span/>
      </div>
      {!renewals.length
        ? <EmptyState icon="↻" title="No renewals" sub="Add your first renewal to track expiring policies" onAdd={onAdd} addLabel="+ Add renewal"/>
        : renewals.map((r: Renewal) => <RenewalRow key={r.id} renewal={r} onEdit={()=>onEdit(r)} onDelete={()=>onDelete(r)}/>)
      }
      <AddRowBtn label="Add renewal" onClick={onAdd}/>
    </Card>
  );
}

function RenewalRow({ renewal, onEdit, onDelete }: { renewal: Renewal; onEdit: ()=>void; onDelete: ()=>void }) {
  const [h, setH] = useState(false);
  const days = daysUntil(renewal.expiryDate);
  const chipV = days <= 20 ? 'urgent' : days <= 35 ? 'soon' : 'ok';
  return (
    <div onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} onClick={onEdit} style={{ display:'grid', gridTemplateColumns:'1fr 108px 86px 100px 60px', alignItems:'center', padding:'10px 16px', borderTop:'1px solid var(--border)', cursor:'pointer', background:h?'var(--bg3)':'transparent', transition:'background 0.1s' }}>
      <div><div style={{ fontSize:12.5, fontWeight:500 }}>{renewal.clientName}</div><div style={{ fontSize:10, color:'var(--text3)', marginTop:2 }}>{renewal.policyType}</div></div>
      <div style={{ fontSize:10.5, color:'var(--text2)', fontFamily:'var(--mono)' }}>{renewal.policyId}</div>
      <div><Chip variant={chipV}>{days}d</Chip></div>
      <StatusPill status={renewal.status}/>
      <div style={{ opacity:h?1:0, transition:'opacity 0.1s' }} onClick={e=>e.stopPropagation()}>
        <RowActions onEdit={onEdit} onDelete={onDelete}/>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// QUOTES PIPELINE
// ────────────────────────────────────────────────────────────────────────────
function QuotesSection({ quotes, onAdd, onEdit, onDelete }: any) {
  const stages: { id: Quote['stage']; label: string; dot: string }[] = [
    { id:'pending',   label:'Pending',   dot:'var(--blue)'  },
    { id:'submitted', label:'Submitted', dot:'var(--amber)' },
    { id:'bound',     label:'Bound',     dot:'var(--green)' },
  ];
  return (
    <Card id="quotes-section">
      <CardHeader>
        <CardTitle>Quotes Pipeline</CardTitle>
        <CardCount>{quotes.length} active</CardCount>
        <div style={{ marginLeft:'auto' }}><LinkBtn onClick={()=>onAdd('pending')}>+ Add quote</LinkBtn></div>
      </CardHeader>
      <div style={{ padding:'12px 14px', display:'flex', gap:8 }}>
        {stages.map(stage => {
          const list = quotes.filter((q: Quote) => q.stage === stage.id);
          return (
            <div key={stage.id} style={{ flex:1, minWidth:0, border:'1px solid var(--border)', borderRadius:'var(--r)', overflow:'hidden', display:'flex', flexDirection:'column' }}>
              <div style={{ padding:'7px 10px', background:'var(--bg3)', display:'flex', alignItems:'center', gap:5, fontSize:10.5, fontWeight:600, color:'var(--text2)', borderBottom:'1px solid var(--border)' }}>
                <span style={{ color:stage.dot }}>●</span> {stage.label}
                <span style={{ marginLeft:'auto', fontSize:9.5, background:'var(--bg4)', color:'var(--text3)', padding:'1px 5px', borderRadius:8 }}>{list.length}</span>
              </div>
              <div style={{ padding:5, display:'flex', flexDirection:'column', gap:4, flex:1 }}>
                {!list.length && <div style={{ padding:'16px 8px', textAlign:'center', color:'var(--text3)', fontSize:10.5 }}>Empty</div>}
                {list.map((q: Quote) => <QuoteCard key={q.id} quote={q} onEdit={()=>onEdit(q)} onDelete={()=>onDelete(q)}/>)}
              </div>
              <button onClick={()=>onAdd(stage.id)} style={{ display:'flex', alignItems:'center', gap:4, padding:'6px 9px', fontSize:10.5, color:'var(--text3)', cursor:'pointer', borderTop:'1px solid var(--border)', background:'transparent', border:'none', borderTop:'1px solid var(--border)', fontFamily:'var(--font)', width:'100%', transition:'all 0.1s' }}>+ Add</button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function QuoteCard({ quote, onEdit, onDelete }: { quote: Quote; onEdit: ()=>void; onDelete: ()=>void }) {
  const [h, setH] = useState(false);
  return (
    <div onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} onClick={onEdit} style={{ background: h?'var(--bg4)':'var(--bg3)', border:`1px solid ${h?'var(--border2)':'var(--border)'}`, borderRadius:6, padding:'8px 9px', cursor:'pointer', transition:'all 0.1s', position:'relative' }}>
      <div style={{ fontSize:11, fontWeight:500, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', paddingRight:40 }}>{quote.clientName}</div>
      <div style={{ fontSize:9.5, color:'var(--text3)', marginTop:1 }}>{quote.policyType}</div>
      <div style={{ fontSize:10.5, fontWeight:600, color:'var(--text2)', fontFamily:'var(--mono)', marginTop:5 }}>{quote.premium}</div>
      <div style={{ position:'absolute', top:6, right:6, display:'flex', gap:2, opacity:h?1:0, transition:'opacity 0.1s' }} onClick={e=>e.stopPropagation()}>
        <RowActions onEdit={onEdit} onDelete={onDelete}/>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// ACTIVITY
// ────────────────────────────────────────────────────────────────────────────
const ACT_DOTS: Record<string,{bg:string;bd:string;icon:string}> = {
  task:     {bg:'var(--green-bg)',  bd:'var(--green-bd)',  icon:'✔'},
  renewal:  {bg:'var(--amber-bg)', bd:'var(--amber-bd)',  icon:'↻'},
  call:     {bg:'var(--blue-bg)',  bd:'var(--blue-bd)',   icon:'📞'},
  quote:    {bg:'var(--red-bg)',   bd:'var(--red-bd)',    icon:'$'},
  document: {bg:'var(--purple-bg)',bd:'var(--purple-bd)', icon:'📄'},
};

function ActivitySection({ activity, filter, setFilter, onAdd, onDelete }: any) {
  return (
    <Card id="activity-section">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <div style={{ marginLeft:'auto', display:'flex', gap:5 }}>
          <PillTabs tabs={['All','Task','Renewal','Call']} active={filter} onChange={setFilter}/>
          <LinkBtn onClick={onAdd}>+ Log</LinkBtn>
        </div>
      </CardHeader>
      {!activity.length
        ? <EmptyState icon="◈" title="No activity yet" sub="Log calls, tasks, and renewals to build your activity feed" onAdd={onAdd} addLabel="+ Log activity"/>
        : activity.map((a: Activity) => <ActivityRow key={a.id} item={a} onDelete={()=>onDelete(a)}/>)
      }
      <AddRowBtn label="Log activity" onClick={onAdd}/>
    </Card>
  );
}

function ActivityRow({ item, onDelete }: { item: Activity; onDelete: ()=>void }) {
  const [h, setH] = useState(false);
  const dot = ACT_DOTS[item.type] || ACT_DOTS.task;
  return (
    <div onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{ display:'flex', alignItems:'flex-start', gap:10, padding:'10px 16px', borderTop:'1px solid var(--border)', background:h?'var(--bg3)':'transparent', transition:'background 0.1s', position:'relative' }}>
      <div style={{ width:28, height:28, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, flexShrink:0, marginTop:1, background:dot.bg, border:`1px solid ${dot.bd}` }}>{dot.icon}</div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:12, fontWeight:500, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{item.title}</div>
        <div style={{ fontSize:10.5, color:'var(--text3)', marginTop:1 }}>{item.description}</div>
      </div>
      <div style={{ fontSize:9.5, color:'var(--text3)', flexShrink:0, marginTop:2, fontFamily:'var(--mono)' }}>{item.date}</div>
      <div style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', opacity:h?1:0, transition:'opacity 0.1s' }} onClick={e=>e.stopPropagation()}>
        <RowActions onDelete={onDelete}/>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// TASKS
// ────────────────────────────────────────────────────────────────────────────
function TaskSection({ tasks, allTasks, filter, setFilter, onToggle, onAdd, onEdit, onDelete, overdueTasks, doneTasks, pendingTasks }: any) {
  return (
    <Card id="tasks-section">
      <CardHeader>
        <CardTitle>My Tasks</CardTitle>
        <div style={{ marginLeft:'auto' }}><PrimaryBtn small onClick={onAdd}>+ New</PrimaryBtn></div>
      </CardHeader>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:5, padding:'9px 12px', borderBottom:'1px solid var(--border)' }}>
        {[
          { label:'All', value:allTasks.length, color:'var(--text2)', f:'All' },
          { label:'Overdue', value:overdueTasks, color:'var(--red)', f:'Overdue' },
          { label:'Pending', value:pendingTasks, color:'var(--amber)', f:'Pending' },
          { label:'Done',    value:doneTasks, color:'var(--green)', f:'Done' },
        ].map(t => (
          <div key={t.f} onClick={()=>setFilter(t.f)} style={{ textAlign:'center', padding:'7px 4px', borderRadius:'var(--r)', cursor:'pointer', border:`1px solid ${filter===t.f?'var(--border2)':'transparent'}`, background:filter===t.f?'var(--bg3)':'transparent', transition:'all 0.1s' }}>
            <div style={{ fontSize:18, fontWeight:500, lineHeight:1, fontFamily:'var(--mono)', color:t.color }}>{t.value}</div>
            <div style={{ fontSize:9, color:'var(--text3)', marginTop:2, fontWeight:500 }}>{t.label}</div>
          </div>
        ))}
      </div>
      {!tasks.length
        ? <EmptyState icon="✓" title="No tasks" sub={filter==='All'?'Add your first task to get started':'No tasks match this filter'} onAdd={filter==='All'?onAdd:undefined} addLabel="+ Add task"/>
        : tasks.map((t: Task) => <TaskRow key={t.id} task={t} onToggle={()=>onToggle(t.id)} onEdit={()=>onEdit(t)} onDelete={()=>onDelete(t)}/>)
      }
      <AddRowBtn label="Add task" onClick={onAdd}/>
    </Card>
  );
}

function TaskRow({ task, onToggle, onEdit, onDelete }: { task: Task; onToggle:()=>void; onEdit:()=>void; onDelete:()=>void }) {
  const [h, setH] = useState(false);
  const days = task.dueDate ? daysUntil(task.dueDate) : null;
  const isOverdue = !task.done && days !== null && days < 0;
  const dueLabel = task.dueDate ? (isOverdue ? `Overdue · ${fmtDate(task.dueDate)}` : `Due ${fmtDate(task.dueDate)}`) : 'No due date';
  const pri = task.priority?.toLowerCase() as 'high'|'medium'|'low';
  return (
    <div onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{ display:'flex', alignItems:'flex-start', gap:9, padding:'9px 12px', borderTop:'1px solid var(--border)', background:h?'var(--bg3)':'transparent', transition:'background 0.1s', position:'relative' }}>
      <div onClick={e=>{e.stopPropagation();onToggle();}} style={{ width:15, height:15, borderRadius:4, border:`1.5px solid ${task.done?'var(--green)':'var(--border2)'}`, background:task.done?'var(--green)':'transparent', flexShrink:0, marginTop:1, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', fontSize:9, fontWeight:700, color:'#000', transition:'all 0.1s' }}>{task.done?'✓':''}</div>
      <div style={{ flex:1, minWidth:0, cursor:'pointer' }} onClick={onEdit}>
        <div style={{ fontSize:11.5, fontWeight:500, color:task.done?'var(--text3)':'var(--text)', textDecoration:task.done?'line-through':'none', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', paddingRight:50 }}>{task.name}</div>
        <div style={{ display:'flex', alignItems:'center', gap:5, marginTop:2 }}>
          <span style={{ fontSize:9.5, color:isOverdue?'var(--red)':'var(--text3)', fontFamily:'var(--mono)', fontWeight:isOverdue?500:400 }}>{dueLabel}</span>
          {!task.done && pri && <Chip variant={pri==='high'?'high':pri==='low'?'low':'medium'}>{task.priority}</Chip>}
        </div>
      </div>
      <div style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', opacity:h?1:0, transition:'opacity 0.1s' }} onClick={e=>e.stopPropagation()}>
        <RowActions onEdit={onEdit} onDelete={onDelete}/>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// MINI CARD
// ────────────────────────────────────────────────────────────────────────────
function MiniCard({ label, value, color, sub }: { label:string; value:number; color:string; sub:string }) {
  return (
    <div style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'var(--rl)', padding:'12px 14px' }}>
      <div style={{ fontSize:9.5, fontWeight:600, letterSpacing:'0.5px', textTransform:'uppercase', color:'var(--text3)', marginBottom:5 }}>{label}</div>
      <div style={{ fontSize:24, fontWeight:300, fontFamily:'var(--mono)', letterSpacing:'-1px', color }}>{value}</div>
      <div style={{ fontSize:10, color:'var(--text3)', marginTop:2 }}>{sub}</div>
    </div>
  );
}
