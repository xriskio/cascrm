'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { NAV_ITEMS } from '@/lib/data';

// ── TYPES ──────────────────────────────────────────────────────────────────────
type BadgeVariant = 'red' | 'amber' | 'green' | 'neutral';

interface NavItem {
  label: string;
  icon: string;
  href: string;
  badge?: string;
  badgeVariant?: BadgeVariant;
}

// ── BADGE ──────────────────────────────────────────────────────────────────────
const BADGE_STYLES: Record<BadgeVariant, React.CSSProperties> = {
  red:     { background: 'var(--red-bg)',   color: 'var(--red)'   },
  amber:   { background: 'var(--amber-bg)', color: 'var(--amber)' },
  green:   { background: 'var(--green-bg)', color: 'var(--green)' },
  neutral: { background: 'var(--surface2)', color: 'var(--text-2)'},
};

function NavBadge({ count, variant = 'red' }: { count: string; variant?: BadgeVariant }) {
  return (
    <span style={{
      marginLeft: 'auto',
      fontSize: 10,
      fontWeight: 600,
      padding: '1px 6px',
      borderRadius: 20,
      flexShrink: 0,
      ...BADGE_STYLES[variant],
    }}>
      {count}
    </span>
  );
}

// ── NAV ITEM ───────────────────────────────────────────────────────────────────
function NavItemComponent({ item, isActive }: { item: NavItem; isActive: boolean }) {
  const baseStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: 9,
    padding: '7px 10px',
    borderRadius: 'var(--radius)',
    cursor: 'pointer',
    fontSize: 13,
    fontWeight: isActive ? 500 : 400,
    textDecoration: 'none',
    whiteSpace: 'nowrap',
    transition: 'background 0.12s, color 0.12s',
    background: isActive ? 'var(--text)' : 'transparent',
    color: isActive ? '#fff' : 'var(--text-2)',
  };

  return (
    <Link href={item.href} style={baseStyle}
      onMouseEnter={e => { if (!isActive) { (e.currentTarget as HTMLAnchorElement).style.background = 'var(--surface2)'; (e.currentTarget as HTMLAnchorElement).style.color = 'var(--text)'; }}}
      onMouseLeave={e => { if (!isActive) { (e.currentTarget as HTMLAnchorElement).style.background = 'transparent'; (e.currentTarget as HTMLAnchorElement).style.color = 'var(--text-2)'; }}}
    >
      <span style={{ width: 16, textAlign: 'center', flexShrink: 0, fontSize: 14 }}>
        {item.icon}
      </span>
      {item.label}
      {item.badge && (
        <NavBadge
          count={item.badge}
          variant={isActive ? 'neutral' : (item.badgeVariant ?? 'red')}
        />
      )}
    </Link>
  );
}

// ── SIDEBAR ────────────────────────────────────────────────────────────────────
export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside style={{
      width: 'var(--sidebar-w)',
      minWidth: 'var(--sidebar-w)',
      background: 'var(--surface)',
      borderRight: '1px solid var(--border)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      position: 'relative',
      zIndex: 20,
    }}>

      {/* Logo */}
      <div style={{
        padding: '20px 18px 16px',
        borderBottom: '1px solid var(--border)',
        display: 'flex',
        alignItems: 'center',
        gap: 10,
      }}>
        <div style={{
          width: 32, height: 32,
          background: 'var(--text)',
          borderRadius: 8,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
              stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div>
          <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: '-0.4px', color: 'var(--text)' }}>
            InsureTrack
          </div>
          <div style={{ fontSize: 10, color: 'var(--text-3)', letterSpacing: '0.3px', marginTop: 1 }}>
            AI-Powered Portal
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, overflowY: 'auto', padding: '10px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV_ITEMS.map(group => (
          <div key={group.section}>
            <div style={{
              fontSize: 9.5,
              fontWeight: 600,
              letterSpacing: '0.9px',
              textTransform: 'uppercase',
              color: 'var(--text-3)',
              padding: '10px 8px 4px',
              marginTop: 4,
            }}>
              {group.section}
            </div>
            {group.items.map(item => (
              <NavItemComponent
                key={item.href}
                item={item}
                isActive={pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href))}
              />
            ))}
          </div>
        ))}
      </nav>

      {/* User footer */}
      <div style={{ padding: '12px 10px', borderTop: '1px solid var(--border)' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '8px 10px',
          borderRadius: 'var(--radius)',
          cursor: 'pointer',
          transition: 'background 0.12s',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = 'var(--surface2)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = 'transparent'; }}
        >
          <div style={{
            width: 30, height: 30, borderRadius: '50%',
            background: 'var(--text)', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 11, fontWeight: 600, flexShrink: 0, letterSpacing: '0.3px',
          }}>
            WU
          </div>
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--text)' }}>Wael User</div>
            <div style={{ fontSize: 10, color: 'var(--text-3)' }}>Senior Agent</div>
          </div>
          <span style={{ marginLeft: 'auto', color: 'var(--text-3)', fontSize: 12 }}>⌄</span>
        </div>
      </div>
    </aside>
  );
}
