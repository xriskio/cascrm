# InsureTrack — Dashboard Components

Redesigned Next.js dashboard for your insurance agency portal.

## File Structure

```
├── app/
│   ├── layout.tsx              ← Root layout (add globals.css import here)
│   └── dashboard/
│       └── page.tsx            ← Dashboard route
│
├── components/dashboard/
│   ├── DashboardPage.tsx       ← Main page — wires everything together
│   ├── Sidebar.tsx             ← Left nav with grouped sections + badges
│   ├── Topbar.tsx              ← Search bar (press / to focus) + New Submission btn
│   ├── StatCards.tsx           ← 4 KPI cards with color-coded urgency
│   ├── RenewalTable.tsx        ← Renewals with filter tabs (All/Urgent/Pending/Quoted)
│   ├── QuotesPipeline.tsx      ← Kanban board: Pending → Submitted → Bound
│   ├── ActivityFeed.tsx        ← Activity log with tab filters
│   ├── TaskPanel.tsx           ← Checklist with overdue counts + priority badges
│   └── NewSubmissionModal.tsx  ← Form modal for new submissions/tasks
│
├── lib/
│   └── data.ts                 ← All mock data (swap for real API calls)
│
├── types/
│   └── index.ts                ← TypeScript types for all entities
│
└── styles/
    └── globals.css             ← CSS variables (design tokens) + global styles
```

## Setup

### 1. Copy files into your project

Drop the folders into your existing Next.js repo root. If you already have
`app/layout.tsx` and `styles/globals.css`, merge them — don't replace.

### 2. Install nothing extra

Zero new dependencies. Uses only React, Next.js, and standard CSS.

### 3. Set your path alias

In `tsconfig.json` make sure you have:
```json
"paths": { "@/*": ["./*"] }
```

And in `next.config.js` / `next.config.ts`:
```js
/** @type {import('next').NextConfig} */
const nextConfig = {};
export default nextConfig;
```

### 4. Import globals.css in your layout

```tsx
// app/layout.tsx
import '@/styles/globals.css';
```

---

## Connecting to your real data

All mock data lives in `lib/data.ts`. To connect to your API, replace the
exported arrays with async fetches. Each component accepts the data as props
or you can use React Server Components to fetch at the page level.

### Example — fetching renewals from your API

```tsx
// app/dashboard/page.tsx
import { getRenewals } from '@/lib/api';  // your API helper
import RenewalTable from '@/components/dashboard/RenewalTable';

export default async function Page() {
  const renewals = await getRenewals();
  return (
    <DashboardPage initialRenewals={renewals} />
  );
}
```

Then update `RenewalTable.tsx` to accept `initialRenewals` as a prop instead
of importing from `lib/data.ts`.

### QQCatalyst / API sync

Your nav already has a "QQCatalyst Sync" link at `/sync`. Wire that page to
trigger your existing sync endpoint.

---

## Key interactions (all work without any extra libraries)

| Feature | How it works |
|---|---|
| Press `/` | Focuses search from anywhere |
| `Esc` | Closes search or modal |
| Search dropdown | Shows categorized results (Clients, Renewals, Tasks) |
| Renewal filter tabs | Client-side filter, no fetch needed |
| Task checkboxes | Toggle `completed` state, updates status badge counts |
| New Submission btn | Opens modal — calls `onSubmit` callback with form data |
| Alert banner | Dismissible, shows urgency callout |

---

## Design tokens

All colors, spacing, and typography live as CSS variables in `styles/globals.css`.
Change them once and the whole UI updates:

```css
:root {
  --green:    #2D7A4F;   /* primary accent */
  --amber:    #8A5A00;   /* warnings       */
  --red:      #C13333;   /* urgent/errors  */
  --blue:     #1A5FAD;   /* informational  */
  --font:     'DM Sans'; /* body font      */
  --mono:     'DM Mono'; /* numbers/codes  */
}
```
