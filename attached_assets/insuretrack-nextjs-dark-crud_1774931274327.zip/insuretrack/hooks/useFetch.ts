/**
 * hooks/useFetch.ts
 * ─────────────────────────────────────────────────────────────────
 * Lightweight data-fetching hook — no React Query or SWR needed.
 * Supports: loading state, error state, auto-refetch interval,
 * manual refresh, and deduplication within the same render cycle.
 */

'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

export interface FetchState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refetch: () => void;
  lastUpdated: Date | null;
}

interface UseFetchOptions {
  /** Auto-refetch every N milliseconds (0 = disabled) */
  refetchInterval?: number;
  /** Don't fetch until this is true (for conditional fetching) */
  enabled?: boolean;
}

export function useFetch<T>(
  url: string,
  { refetchInterval = 0, enabled = true }: UseFetchOptions = {},
): FetchState<T> {
  const [data, setData]               = useState<T | null>(null);
  const [loading, setLoading]         = useState(true);
  const [error, setError]             = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [tick, setTick]               = useState(0);
  const abortRef                      = useRef<AbortController | null>(null);

  const refetch = useCallback(() => setTick(t => t + 1), []);

  useEffect(() => {
    if (!enabled) return;

    // Cancel any in-flight request
    abortRef.current?.abort();
    abortRef.current = new AbortController();

    setLoading(true);
    setError(null);

    fetch(url, { signal: abortRef.current.signal })
      .then(async res => {
        if (!res.ok) {
          const json = await res.json().catch(() => ({}));
          throw new Error(json?.error?.message ?? `HTTP ${res.status}`);
        }
        return res.json();
      })
      .then(json => {
        setData(json.data ?? json);
        setLastUpdated(new Date());
        setLoading(false);
      })
      .catch(err => {
        if ((err as Error).name === 'AbortError') return;
        setError((err as Error).message);
        setLoading(false);
      });

    return () => { abortRef.current?.abort(); };
  }, [url, tick, enabled]);

  // Auto-refetch
  useEffect(() => {
    if (!refetchInterval || !enabled) return;
    const id = setInterval(refetch, refetchInterval);
    return () => clearInterval(id);
  }, [refetchInterval, enabled, refetch]);

  return { data, loading, error, refetch, lastUpdated };
}

// ── MUTATION HOOK ──────────────────────────────────────────────────────────────
export interface MutationState<TResult> {
  mutate: (body?: unknown) => Promise<TResult | null>;
  loading: boolean;
  error: string | null;
}

export function useMutation<TResult = unknown>(
  url: string,
  method: 'POST' | 'PATCH' | 'PUT' | 'DELETE' = 'POST',
): MutationState<TResult> {
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);

  const mutate = useCallback(async (body?: unknown): Promise<TResult | null> => {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });

      const json = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(json?.error?.message ?? `HTTP ${res.status}`);
      }

      setLoading(false);
      return (json.data ?? json) as TResult;

    } catch (err) {
      setError((err as Error).message);
      setLoading(false);
      return null;
    }
  }, [url, method]);

  return { mutate, loading, error };
}
