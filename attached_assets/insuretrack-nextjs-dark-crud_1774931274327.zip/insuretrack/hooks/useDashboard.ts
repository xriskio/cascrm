/**
 * hooks/useDashboard.ts
 * ─────────────────────────────────────────────────────────────────
 * Domain hooks — the only hooks your components need to import.
 * All API URLs are centralised here so refactoring is a one-liner.
 */

'use client';

import { useState, useCallback } from 'react';
import { useFetch, useMutation } from './useFetch';
import type { Renewal, Quote, Task, Activity, StatCard } from '@/types';

// ── DASHBOARD STATS ────────────────────────────────────────────────────────────
export function useDashboardStats() {
  return useFetch<{ stats: Record<string, number>; cards: StatCard[] }>(
    '/api/dashboard',
    { refetchInterval: 5 * 60_000 }, // auto-refresh every 5 min
  );
}

// ── RENEWALS ───────────────────────────────────────────────────────────────────
export function useRenewals(days = 90) {
  return useFetch<Renewal[]>(`/api/renewals?days=${days}`, {
    refetchInterval: 3 * 60_000,
  });
}

// ── QUOTES ─────────────────────────────────────────────────────────────────────
export function useQuotes() {
  return useFetch<Quote[]>('/api/quotes', {
    refetchInterval: 3 * 60_000,
  });
}

// ── ACTIVITY FEED ──────────────────────────────────────────────────────────────
export function useActivityFeed() {
  return useFetch<Activity[]>('/api/activity', {
    refetchInterval: 2 * 60_000,
  });
}

// ── TASKS ──────────────────────────────────────────────────────────────────────
export interface UseTasksReturn {
  tasks: Task[];
  loading: boolean;
  error: string | null;
  refetch: () => void;
  toggleComplete: (id: string) => Promise<void>;
  createTask: (body: Record<string, unknown>) => Promise<boolean>;
}

export function useTasks(): UseTasksReturn {
  const { data, loading, error, refetch } = useFetch<Task[]>('/api/tasks');
  const [optimistic, setOptimistic] = useState<Task[]>([]);

  // Merge server data with any optimistic updates
  const tasks = (data ?? []).map(t => {
    const opt = optimistic.find(o => o.id === t.id);
    return opt ?? t;
  });

  const completeMutation = useMutation(`/api/tasks/__id__`, 'PATCH');
  const createMutation   = useMutation('/api/tasks', 'POST');

  const toggleComplete = useCallback(async (id: string) => {
    // Optimistic update immediately
    setOptimistic(prev => {
      const existing = (data ?? []).find(t => t.id === id);
      if (!existing) return prev;
      const updated  = { ...existing, completed: !existing.completed, status: !existing.completed ? 'done' as const : 'progress' as const };
      return [...prev.filter(o => o.id !== id), updated];
    });

    // Send to server
    try {
      const url = `/api/tasks/${id}`;
      const res = await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed: true }),
      });
      if (!res.ok) throw new Error('Failed to update task');
    } catch {
      // Revert optimistic update on failure
      setOptimistic(prev => prev.filter(o => o.id !== id));
    }
  }, [data]);

  const createTask = useCallback(async (body: Record<string, unknown>): Promise<boolean> => {
    const result = await createMutation.mutate(body);
    if (result) refetch();
    return Boolean(result);
  }, [createMutation, refetch]);

  return { tasks, loading, error, refetch, toggleComplete, createTask };
}

// ── SYNC ───────────────────────────────────────────────────────────────────────
export interface SyncStatus {
  jobId: string;
  status: 'idle' | 'running' | 'complete' | 'failed';
  progress: number;
  message: string;
}

export function useSync() {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    jobId: '', status: 'idle', progress: 0, message: '',
  });
  const triggerMutation = useMutation<{ jobId: string }>('/api/sync', 'POST');

  const triggerSync = useCallback(async () => {
    setSyncStatus(s => ({ ...s, status: 'running', progress: 0, message: 'Starting sync…' }));

    const result = await triggerMutation.mutate();
    if (!result?.jobId) {
      setSyncStatus(s => ({ ...s, status: 'failed', message: 'Failed to start sync' }));
      return;
    }

    const jobId = result.jobId;
    setSyncStatus(s => ({ ...s, jobId, message: 'Sync running…' }));

    // Poll until complete
    const poll = setInterval(async () => {
      try {
        const res  = await fetch(`/api/sync?job=${jobId}`);
        const json = await res.json();
        const st   = json.data ?? json;

        setSyncStatus({
          jobId,
          status:   st.status === 'complete' ? 'complete' : st.status === 'failed' ? 'failed' : 'running',
          progress: st.progress ?? 0,
          message:  st.message ?? '',
        });

        if (st.status === 'complete' || st.status === 'failed') {
          clearInterval(poll);
        }
      } catch {
        clearInterval(poll);
        setSyncStatus(s => ({ ...s, status: 'failed', message: 'Failed to poll sync status' }));
      }
    }, 2000);

  }, [triggerMutation]);

  return { syncStatus, triggerSync, syncing: triggerMutation.loading };
}
