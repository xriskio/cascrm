/**
 * app/api/sync/route.ts
 * POST /api/sync           — trigger a QQCatalyst data sync
 * GET  /api/sync?job=<id>  — poll sync job status
 */

import { NextRequest } from 'next/server';
import { qqApi } from '@/lib/qqcatalyst/client';
import { ok, handleError } from '../_helpers';

export const dynamic = 'force-dynamic';

export async function POST() {
  try {
    const job = await qqApi.triggerSync();
    return ok(job, 202);
  } catch (err) {
    return handleError(err);
  }
}

export async function GET(req: NextRequest) {
  try {
    const jobId = req.nextUrl.searchParams.get('job');
    if (!jobId) {
      return Response.json(
        { ok: false, error: { code: 'MISSING_PARAM', message: 'job query param is required' } },
        { status: 400 },
      );
    }
    const status = await qqApi.getSyncStatus(jobId);
    return ok(status);
  } catch (err) {
    return handleError(err);
  }
}
