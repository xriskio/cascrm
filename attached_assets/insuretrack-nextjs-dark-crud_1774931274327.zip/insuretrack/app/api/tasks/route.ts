/**
 * app/api/tasks/route.ts
 * GET  /api/tasks          — list all tasks
 * POST /api/tasks          — create a new task
 */

import { NextRequest } from 'next/server';
import { getTasks, createTask } from '@/lib/api/service';
import { ok, handleError } from '../_helpers';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const tasks = await getTasks();
    return ok(tasks);
  } catch (err) {
    return handleError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body.clientName) {
      return Response.json(
        { ok: false, error: { code: 'VALIDATION_ERROR', message: 'clientName is required' } },
        { status: 422 },
      );
    }

    await createTask({
      name:       body.description ?? body.name ?? 'New Task',
      clientName: body.clientName,
      dueDate:    body.dueDate,
      priority:   body.priority,
      policyType: body.policyType,
    });

    return ok({ created: true }, 201);
  } catch (err) {
    return handleError(err);
  }
}
