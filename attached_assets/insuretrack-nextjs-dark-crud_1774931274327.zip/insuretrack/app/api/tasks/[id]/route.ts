/**
 * app/api/tasks/[id]/route.ts
 * PATCH /api/tasks/:id     — update a task (e.g. mark complete)
 */

import { NextRequest } from 'next/server';
import { completeTask } from '@/lib/api/service';
import { ok, handleError } from '../../_helpers';

export const dynamic = 'force-dynamic';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  try {
    const body = await req.json();

    if (body.completed === true) {
      await completeTask(params.id);
      return ok({ updated: true });
    }

    // Future: handle other patch fields (priority, dueDate, etc.)
    return ok({ updated: false, reason: 'No recognised fields to update' });

  } catch (err) {
    return handleError(err);
  }
}
