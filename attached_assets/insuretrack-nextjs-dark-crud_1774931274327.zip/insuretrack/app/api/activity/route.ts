/**
 * app/api/activity/route.ts
 * GET /api/activity
 */

import { getActivityFeed } from '@/lib/api/service';
import { ok, handleError, withCache } from '../_helpers';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const feed = await withCache('activity', 60_000, getActivityFeed);
    return ok(feed);
  } catch (err) {
    return handleError(err);
  }
}
