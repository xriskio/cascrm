/**
 * app/api/_helpers.ts
 * Shared utilities for all API route handlers.
 */

import { NextResponse } from 'next/server';
import { ApiError } from '@/lib/api/client';

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ ok: true, data }, { status });
}

export function err(message: string, status = 500, code = 'INTERNAL_ERROR') {
  return NextResponse.json({ ok: false, error: { code, message } }, { status });
}

export function handleError(error: unknown) {
  if (error instanceof ApiError) {
    return err(error.message, error.status, error.code);
  }
  if (error instanceof Error) {
    return err(error.message, 500, 'INTERNAL_ERROR');
  }
  return err('An unexpected error occurred', 500);
}

/** Simple in-memory cache for short-lived data (resets on server restart) */
const cache = new Map<string, { value: unknown; expiresAt: number }>();

export function withCache<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const cached = cache.get(key);
  if (cached && cached.expiresAt > Date.now()) {
    return Promise.resolve(cached.value as T);
  }
  return fn().then(value => {
    cache.set(key, { value, expiresAt: Date.now() + ttlMs });
    return value;
  });
}
