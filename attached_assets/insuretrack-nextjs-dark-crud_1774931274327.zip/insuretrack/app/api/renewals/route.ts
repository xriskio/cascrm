/**
 * app/api/renewals/route.ts
 * GET /api/renewals?days=90
 */

import { NextRequest } from 'next/server';
import { getRenewals } from '@/lib/api/service';
import { ok, handleError, withCache } from '../_helpers';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const days = Number(req.nextUrl.searchParams.get('days') ?? '90');
    const renewals = await withCache(`renewals:${days}`, 120_000, () => getRenewals(days));
    return ok(renewals);
  } catch (err) {
    return handleError(err);
  }
}
