/**
 * app/api/quotes/route.ts
 * GET /api/quotes
 */

import { getQuotes } from '@/lib/api/service';
import { ok, handleError, withCache } from '../_helpers';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const quotes = await withCache('quotes', 120_000, getQuotes);
    return ok(quotes);
  } catch (err) {
    return handleError(err);
  }
}
