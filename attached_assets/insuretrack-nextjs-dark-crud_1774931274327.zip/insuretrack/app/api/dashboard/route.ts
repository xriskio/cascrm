/**
 * app/api/dashboard/route.ts
 * GET /api/dashboard
 *
 * Returns all dashboard KPIs in one round-trip.
 * Cached for 60 seconds to avoid hammering QQCatalyst.
 */

import { NextResponse } from 'next/server';
import { getDashboardStats, buildStatCards } from '@/lib/api/service';
import { ok, handleError, withCache } from '../_helpers';

export const dynamic = 'force-dynamic'; // never statically cache this route

export async function GET() {
  try {
    const stats = await withCache('dashboard:stats', 60_000, getDashboardStats);
    return ok({ stats, cards: buildStatCards(stats) });
  } catch (err) {
    return handleError(err);
  }
}
