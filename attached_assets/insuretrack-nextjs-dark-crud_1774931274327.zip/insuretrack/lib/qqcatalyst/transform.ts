/**
 * lib/qqcatalyst/transform.ts
 * ─────────────────────────────────────────────────────────────────
 * Pure functions that convert raw QQCatalyst API responses into the
 * typed shapes our UI components consume.
 */

import type { Renewal, RenewalStatus, Quote, QuoteStage, Task, TaskStatus, TaskPriority, Activity, ActivityType } from '@/types';
import type { QQPolicy, QQActivity, QQQuote } from './client';

// ── HELPERS ────────────────────────────────────────────────────────────────────
function daysUntil(isoDate: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const exp = new Date(isoDate);
  exp.setHours(0, 0, 0, 0);
  return Math.round((exp.getTime() - today.getTime()) / 86_400_000);
}

function shortDate(isoDate: string | undefined): string | null {
  if (!isoDate) return null;
  return new Date(isoDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function relativeDate(isoDate: string): string {
  const d = new Date(isoDate);
  const diffDays = Math.round((Date.now() - d.getTime()) / 86_400_000);
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7)  return `${diffDays}d ago`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// ── RENEWALS ───────────────────────────────────────────────────────────────────
function qqStatusToRenewal(qqStatus: string, days: number): RenewalStatus {
  if (qqStatus === 'Pending' && days <= 20)  return 'urgent';
  if (qqStatus === 'Pending')                return 'pending';
  if (qqStatus === 'In Progress')            return 'progress';
  if (qqStatus === 'Quoted')                 return 'quoted';
  return 'pending';
}

export function transformPolicy(p: QQPolicy): Renewal {
  const days = daysUntil(p.ExpirationDate);
  return {
    id:              p.PolicyId,
    clientName:      p.ClientName,
    policyType:      p.LineOfBusiness,
    policyId:        p.PolicyNumber,
    daysUntilExpiry: days,
    status:          qqStatusToRenewal(p.Status, days),
  };
}

export function transformPolicies(policies: QQPolicy[]): Renewal[] {
  return policies
    .map(transformPolicy)
    .sort((a, b) => a.daysUntilExpiry - b.daysUntilExpiry); // soonest first
}

// ── QUOTES ─────────────────────────────────────────────────────────────────────
function qqStatusToStage(s: string): QuoteStage {
  if (s === 'Bound')     return 'bound';
  if (s === 'Submitted') return 'submitted';
  return 'pending';
}

export function transformQuote(q: QQQuote): Quote {
  const premium = q.EstimatedPremium
    ? `Est. $${q.EstimatedPremium.toLocaleString()}`
    : 'TBD';
  return {
    id:               q.QuoteId,
    clientName:       q.ClientName,
    policyType:       q.LineOfBusiness,
    estimatedPremium: premium,
    stage:            qqStatusToStage(q.Status),
  };
}

export function transformQuotes(quotes: QQQuote[]): Quote[] {
  return quotes.map(transformQuote);
}

// ── TASKS ──────────────────────────────────────────────────────────────────────
function qqPriorityToApp(p: string): TaskPriority {
  if (p === 'High') return 'high';
  if (p === 'Low')  return 'low';
  return 'medium';
}

function deriveTaskStatus(a: QQActivity): TaskStatus {
  if (a.Status === 'Completed') return 'done';
  if (a.DueDate && daysUntil(a.DueDate) < 0) return 'overdue';
  return 'progress';
}

export function transformActivity(a: QQActivity): Task {
  const status = deriveTaskStatus(a);
  return {
    id:        a.ActivityId,
    name:      a.Subject || a.Description.slice(0, 60),
    dueDate:   shortDate(a.DueDate),
    priority:  qqPriorityToApp(a.Priority),
    status,
    completed: status === 'done',
  };
}

export function transformTasks(activities: QQActivity[]): Task[] {
  return activities
    .filter(a => a.ActivityType === 'Task')
    .map(transformActivity)
    .sort((a, b) => {
      // Overdue first, then progress, then done
      const order = { overdue: 0, progress: 1, done: 2 };
      return order[a.status] - order[b.status];
    });
}

// ── ACTIVITY FEED ──────────────────────────────────────────────────────────────
function qqTypeToActivity(t: string): ActivityType {
  const map: Record<string, ActivityType> = {
    Task:     'task',
    Call:     'call',
    Note:     'document',
    Email:    'document',
    Renewal:  'renewal',
    Quote:    'quote',
  };
  return map[t] ?? 'task';
}

export function transformActivityFeed(activities: QQActivity[]): Activity[] {
  return activities.slice(0, 20).map(a => ({
    id:          a.ActivityId,
    type:        qqTypeToActivity(a.ActivityType),
    title:       a.Subject ?? `${a.ActivityType} — ${a.ClientName}`,
    description: a.Description ?? '',
    date:        relativeDate(a.ActivityDate),
  }));
}
