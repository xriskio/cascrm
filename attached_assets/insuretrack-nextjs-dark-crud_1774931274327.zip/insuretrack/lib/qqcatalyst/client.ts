/**
 * lib/qqcatalyst/client.ts
 * ─────────────────────────────────────────────────────────────────
 * Low-level QQCatalyst REST API client.
 *
 * Environment variables required:
 *   QQCATALYST_API_KEY      — your agency API key
 *   QQCATALYST_AGENCY_ID    — your QQ agency ID
 *   QQCATALYST_BASE_URL     — defaults to https://api.qqcatalyst.com/v1
 *
 * QQCatalyst API docs: https://developer.qqcatalyst.com
 */

import { apiFetch, ApiError } from '@/lib/api/client';

const BASE = process.env.QQCATALYST_BASE_URL ?? 'https://api.qqcatalyst.com/v1';
const AGENCY_ID = process.env.QQCATALYST_AGENCY_ID ?? '';

function qqHeaders(): HeadersInit {
  const key = process.env.QQCATALYST_API_KEY;
  if (!key) throw new ApiError(401, 'MISSING_QQ_KEY', 'QQCATALYST_API_KEY is not set');
  return {
    'Authorization': `Bearer ${key}`,
    'X-Agency-Id': AGENCY_ID,
  };
}

function url(path: string, params?: Record<string, string | number | boolean | undefined>) {
  const u = new URL(`${BASE}${path}`);
  if (params) {
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined) u.searchParams.set(k, String(v));
    });
  }
  return u.toString();
}

// ── RAW QQ TYPES (as returned by the QQ API) ─────────────────────────────────
export interface QQPolicy {
  PolicyId:       string;
  PolicyNumber:   string;
  ClientName:     string;
  LineOfBusiness: string;
  ExpirationDate: string;   // ISO 8601
  Status:         string;   // 'Active' | 'Pending' | 'Cancelled' | ...
  Premium:        number;
  CarrierName:    string;
  ProducerName:   string;
}

export interface QQClient {
  ClientId:    string;
  FirstName:   string;
  LastName:    string;
  CompanyName: string;
  Email:       string;
  Phone:       string;
  Address:     string;
  City:        string;
  State:       string;
  Zip:         string;
  CreatedDate: string;
}

export interface QQActivity {
  ActivityId:   string;
  ActivityType: string;   // 'Task' | 'Call' | 'Note' | 'Email' | ...
  Subject:      string;
  Description:  string;
  ActivityDate: string;
  ClientId:     string;
  ClientName:   string;
  PolicyId?:    string;
  Status:       string;   // 'Open' | 'Completed' | 'Pending'
  Priority:     string;   // 'High' | 'Medium' | 'Low'
  DueDate?:     string;
  CompletedDate?: string;
}

export interface QQQuote {
  QuoteId:        string;
  ClientName:     string;
  LineOfBusiness: string;
  EstimatedPremium: number;
  Status:         string;   // 'In Progress' | 'Submitted' | 'Bound' | 'Declined'
  CreatedDate:    string;
  EffectiveDate:  string;
  CarrierName?:   string;
}

export interface QQListResponse<T> {
  Data:        T[];
  TotalCount:  number;
  PageNumber:  number;
  PageSize:    number;
}

// ── API METHODS ────────────────────────────────────────────────────────────────
export const qqApi = {

  /**
   * Fetch policies expiring within `daysAhead` days.
   * QQ endpoint: GET /policies?filter=expiring&daysAhead=90
   */
  async getExpiringPolicies(daysAhead = 90): Promise<QQPolicy[]> {
    const res = await apiFetch<QQListResponse<QQPolicy>>(
      url('/policies', { filter: 'expiring', daysAhead, pageSize: 200 }),
      { headers: qqHeaders() },
    );
    return res.Data;
  },

  /**
   * Fetch all active clients.
   */
  async getClients(params?: { search?: string; page?: number; pageSize?: number }): Promise<QQListResponse<QQClient>> {
    return apiFetch<QQListResponse<QQClient>>(
      url('/clients', { status: 'Active', ...params }),
      { headers: qqHeaders() },
    );
  },

  /**
   * Fetch a single client by ID.
   */
  async getClient(clientId: string): Promise<QQClient> {
    return apiFetch<QQClient>(
      url(`/clients/${clientId}`),
      { headers: qqHeaders() },
    );
  },

  /**
   * Fetch open activities / tasks — optionally filtered to a date range.
   */
  async getActivities(params?: {
    status?: 'Open' | 'Completed' | 'Pending';
    type?: 'Task' | 'Call' | 'Note';
    fromDate?: string;
    toDate?: string;
    pageSize?: number;
  }): Promise<QQActivity[]> {
    const res = await apiFetch<QQListResponse<QQActivity>>(
      url('/activities', { pageSize: 100, ...params }),
      { headers: qqHeaders() },
    );
    return res.Data;
  },

  /**
   * Update an activity (e.g. mark a task complete).
   */
  async updateActivity(activityId: string, patch: Partial<QQActivity>): Promise<QQActivity> {
    return apiFetch<QQActivity>(
      url(`/activities/${activityId}`),
      { method: 'PATCH', body: JSON.stringify(patch), headers: qqHeaders() },
    );
  },

  /**
   * Create a new activity / task.
   */
  async createActivity(data: Omit<QQActivity, 'ActivityId' | 'CreatedDate'>): Promise<QQActivity> {
    return apiFetch<QQActivity>(
      url('/activities'),
      { method: 'POST', body: JSON.stringify(data), headers: qqHeaders() },
    );
  },

  /**
   * Fetch quotes pipeline.
   */
  async getQuotes(params?: { status?: string; pageSize?: number }): Promise<QQQuote[]> {
    const res = await apiFetch<QQListResponse<QQQuote>>(
      url('/quotes', { pageSize: 100, ...params }),
      { headers: qqHeaders() },
    );
    return res.Data;
  },

  /**
   * Trigger a full data sync and return a job ID to poll.
   */
  async triggerSync(): Promise<{ jobId: string; startedAt: string }> {
    return apiFetch(
      url('/sync/trigger'),
      { method: 'POST', headers: qqHeaders() },
    );
  },

  /**
   * Poll the status of a sync job.
   */
  async getSyncStatus(jobId: string): Promise<{
    jobId: string;
    status: 'running' | 'complete' | 'failed';
    progress: number;
    message: string;
    completedAt?: string;
  }> {
    return apiFetch(url(`/sync/status/${jobId}`), { headers: qqHeaders() });
  },
};
