/**
 * lib/store.ts
 * Client-side state store with localStorage persistence.
 * Used by all dashboard components via useDashboard() hook.
 */
'use client';

import { useState, useCallback, useEffect } from 'react';
import type { DashboardState, Renewal, Quote, Task, Activity, UserProfile } from '@/types';

const STORAGE_KEY = 'insuretrack_db';

const DEFAULT_STATE: DashboardState = {
  user:     { name: '', role: 'Agent' },
  renewals: [],
  quotes:   [],
  tasks:    [],
  activity: [],
};

export function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

export function daysUntil(dateStr?: string): number {
  if (!dateStr) return 9999;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const d = new Date(dateStr + 'T00:00:00'); d.setHours(0, 0, 0, 0);
  return Math.round((d.getTime() - today.getTime()) / 86_400_000);
}

export function fmtDate(s?: string): string {
  if (!s) return '';
  try { return new Date(s + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); }
  catch { return s; }
}

function loadState(): DashboardState {
  if (typeof window === 'undefined') return DEFAULT_STATE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_STATE, ...JSON.parse(raw) } : DEFAULT_STATE;
  } catch { return DEFAULT_STATE; }
}

function saveState(state: DashboardState) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
}

// ── HOOK ───────────────────────────────────────────────────────────────────────
export function useDashboard() {
  const [state, setState] = useState<DashboardState>(DEFAULT_STATE);

  useEffect(() => { setState(loadState()); }, []);

  const update = useCallback((fn: (s: DashboardState) => DashboardState) => {
    setState(prev => {
      const next = fn(prev);
      saveState(next);
      return next;
    });
  }, []);

  function autoLog(type: Activity['type'], title: string, description: string) {
    update(s => ({
      ...s,
      activity: [...s.activity, {
        id: uid(), type, title, description,
        date: fmtDate(new Date().toISOString().slice(0, 10)),
      }],
    }));
  }

  // ── RENEWALS ──────────────────────────────────────────────────────────────
  const addRenewal = useCallback((r: Omit<Renewal, 'id'>) => {
    const item = { ...r, id: uid() };
    update(s => ({ ...s, renewals: [...s.renewals, item] }));
    autoLog('renewal', `Renewal Added — ${r.clientName}`, r.policyType);
  }, [update]);

  const updateRenewal = useCallback((id: string, patch: Partial<Renewal>) => {
    update(s => ({ ...s, renewals: s.renewals.map(r => r.id === id ? { ...r, ...patch } : r) }));
  }, [update]);

  const deleteRenewal = useCallback((id: string) => {
    update(s => ({ ...s, renewals: s.renewals.filter(r => r.id !== id) }));
  }, [update]);

  // ── QUOTES ────────────────────────────────────────────────────────────────
  const addQuote = useCallback((q: Omit<Quote, 'id'>) => {
    const item = { ...q, id: uid() };
    update(s => ({ ...s, quotes: [...s.quotes, item] }));
    autoLog('quote', `Quote Added — ${q.clientName}`, `${q.policyType} · ${q.stage}`);
  }, [update]);

  const updateQuote = useCallback((id: string, patch: Partial<Quote>) => {
    update(s => ({ ...s, quotes: s.quotes.map(q => q.id === id ? { ...q, ...patch } : q) }));
  }, [update]);

  const deleteQuote = useCallback((id: string) => {
    update(s => ({ ...s, quotes: s.quotes.filter(q => q.id !== id) }));
  }, [update]);

  // ── TASKS ─────────────────────────────────────────────────────────────────
  const addTask = useCallback((t: Omit<Task, 'id' | 'done'>) => {
    const item = { ...t, id: uid(), done: false };
    update(s => ({ ...s, tasks: [...s.tasks, item] }));
    autoLog('task', `Task Created — ${t.name}`, t.client || '');
  }, [update]);

  const updateTask = useCallback((id: string, patch: Partial<Task>) => {
    update(s => ({ ...s, tasks: s.tasks.map(t => t.id === id ? { ...t, ...patch } : t) }));
  }, [update]);

  const toggleTask = useCallback((id: string) => {
    update(s => ({ ...s, tasks: s.tasks.map(t => t.id === id ? { ...t, done: !t.done } : t) }));
  }, [update]);

  const deleteTask = useCallback((id: string) => {
    update(s => ({ ...s, tasks: s.tasks.filter(t => t.id !== id) }));
  }, [update]);

  // ── ACTIVITY ──────────────────────────────────────────────────────────────
  const addActivity = useCallback((a: Omit<Activity, 'id'>) => {
    update(s => ({ ...s, activity: [...s.activity, { ...a, id: uid() }] }));
  }, [update]);

  const deleteActivity = useCallback((id: string) => {
    update(s => ({ ...s, activity: s.activity.filter(a => a.id !== id) }));
  }, [update]);

  // ── USER ──────────────────────────────────────────────────────────────────
  const updateUser = useCallback((patch: Partial<UserProfile>) => {
    update(s => ({ ...s, user: { ...s.user, ...patch } }));
  }, [update]);

  // ── DERIVED ───────────────────────────────────────────────────────────────
  const pendingTasks    = state.tasks.filter(t => !t.done).length;
  const overdueTasks    = state.tasks.filter(t => !t.done && t.dueDate && daysUntil(t.dueDate) < 0).length;
  const doneTasks       = state.tasks.filter(t => t.done).length;
  const urgentRenewals  = state.renewals.filter(r => daysUntil(r.expiryDate) <= 20).length;

  return {
    state,
    // renewals
    addRenewal, updateRenewal, deleteRenewal,
    // quotes
    addQuote, updateQuote, deleteQuote,
    // tasks
    addTask, updateTask, toggleTask, deleteTask,
    // activity
    addActivity, deleteActivity,
    // user
    updateUser,
    // derived
    pendingTasks, overdueTasks, doneTasks, urgentRenewals,
  };
}
