import type { Renewal, Quote, Task, Activity, StatCard } from '@/types';

// ── STAT CARDS ────────────────────────────────────────────────────────────────
export const STAT_CARDS: StatCard[] = [
  { id: 'tasks',    label: 'Pending Tasks',     value: 14, subtext: '14 require attention this week',     variant: 'amber', badge: 'Needs attention' },
  { id: 'renewals', label: 'Upcoming Renewals',  value: 56, subtext: 'In the next 90 days · 3 urgent',    variant: 'red' },
  { id: 'quotes',   label: 'Active Quotes',      value: 7,  subtext: 'Across 5 clients · 2 awaiting',     variant: 'blue' },
  { id: 'clients',  label: 'Active Clients',     value: 42, subtext: 'All documents complete',            variant: 'green' },
];

// ── RENEWALS ──────────────────────────────────────────────────────────────────
export const RENEWALS: Renewal[] = [
  { id: 'r1', clientName: 'KARS INC',              policyType: 'General Liability',    policyId: 'GL-2024-881', daysUntilExpiry: 8,  status: 'urgent'   },
  { id: 'r2', clientName: 'Aniad Selim',            policyType: 'Dwelling Fire',        policyId: 'DF-7821-05',  daysUntilExpiry: 18, status: 'urgent'   },
  { id: 'r3', clientName: 'Hemant Patel',           policyType: 'Commercial Umbrella',  policyId: 'CU-3310-22',  daysUntilExpiry: 24, status: 'progress' },
  { id: 'r4', clientName: 'Lone Oak Studio Suites', policyType: 'Commercial Property',  policyId: 'CP-9944-17',  daysUntilExpiry: 42, status: 'quoted'   },
  { id: 'r5', clientName: 'Core Transport Totah',   policyType: 'Commercial Auto',      policyId: 'CA-1172-09',  daysUntilExpiry: 61, status: 'pending'  },
  { id: 'r6', clientName: 'Bret Payton',            policyType: 'Business Owners Policy', policyId: 'BOP-5542-11', daysUntilExpiry: 74, status: 'quoted' },
];

// ── QUOTES PIPELINE ───────────────────────────────────────────────────────────
export const QUOTES: Quote[] = [
  { id: 'q1', clientName: '2020 SF Taxi — Igor',    policyType: 'Commercial Auto',     estimatedPremium: 'Est. $4,200', stage: 'pending'   },
  { id: 'q2', clientName: 'Shadi Abakuzr',          policyType: 'General Liability',   estimatedPremium: 'Est. $1,800', stage: 'pending'   },
  { id: 'q3', clientName: 'Waied',                  policyType: 'Dwelling Fire',       estimatedPremium: 'Est. $950',   stage: 'pending'   },
  { id: 'q4', clientName: 'Rashid Washed — Gym',    policyType: 'Commercial GL',       estimatedPremium: 'Est. $3,100', stage: 'submitted' },
  { id: 'q5', clientName: 'Salem New Hotel',        policyType: 'Commercial Property', estimatedPremium: 'Est. $8,400', stage: 'submitted' },
  { id: 'q6', clientName: 'Bella Kay Abrahamsen',   policyType: 'Homeowners',          estimatedPremium: '$2,250/yr',   stage: 'bound'     },
  { id: 'q7', clientName: '10X Waverly B408B',      policyType: "Renter's Policy",     estimatedPremium: '$480/yr',     stage: 'bound'     },
];

// ── TASKS ─────────────────────────────────────────────────────────────────────
export const INITIAL_TASKS: Task[] = [
  { id: 't1', name: 'Freedom Choice — Property Reinstatement', dueDate: 'Oct 31', priority: 'high',   status: 'overdue',  completed: false },
  { id: 't2', name: '2020 SF Taxi Quote — Igor',               dueDate: 'Oct 28', priority: 'high',   status: 'overdue',  completed: false },
  { id: 't3', name: 'Shadi Abakuzr — Quote Follow-up',         dueDate: 'Oct 21', priority: 'medium', status: 'overdue',  completed: false },
  { id: 't4', name: 'Bret Payton — BOP Quotes',                dueDate: 'Jan 7',  priority: 'medium', status: 'progress', completed: false },
  { id: 't5', name: 'Waied — Dwelling Fire Quote',             dueDate: 'Jan 21', priority: 'medium', status: 'progress', completed: false },
  { id: 't6', name: 'Rashid Washed — Gym for Son Gym',         dueDate: 'Jan 24', priority: 'medium', status: 'progress', completed: false },
  { id: 't7', name: 'Core Transport — Send Suray or Aon',      dueDate: 'Mar 11', priority: 'medium', status: 'progress', completed: false },
  { id: 't8', name: '10X Waverly B408B',                       dueDate: null,     priority: 'low',    status: 'progress', completed: false },
  { id: 't9', name: 'Delta Kay — Reinstatement Follow-up',     dueDate: null,     priority: 'low',    status: 'progress', completed: false },
  { id: 't10',name: 'Salem New Hotel — Kinnasel Submit',       dueDate: 'Oct 20', priority: 'medium', status: 'done',     completed: true  },
];

// ── ACTIVITY ──────────────────────────────────────────────────────────────────
export const ACTIVITY_FEED: Activity[] = [
  { id: 'a1', type: 'task',    title: 'Task Created — Core Transport Totah',          description: 'Send Suray or Aon · Not Started',          date: 'Mar 12' },
  { id: 'a2', type: 'renewal', title: 'Renewal Updated — KARS INC · General Liability', description: 'Status changed to Pending · Due in 8 days',  date: 'Feb 26' },
  { id: 'a3', type: 'renewal', title: 'Renewal Updated — Hemant Patel · Commercial Umbrella', description: 'Lone Oak Studio Suites · Pending',    date: 'Feb 26' },
  { id: 'a4', type: 'quote',   title: 'Quote Submitted — 2020 SF Taxi Igor',          description: 'Sent to 3 carriers · Awaiting response',     date: 'Feb 24' },
  { id: 'a5', type: 'call',    title: 'Call Logged — Bret Payton',                    description: 'Discussed BOP renewal options · Follow-up scheduled', date: 'Feb 22' },
];

// ── SEARCH DATA ───────────────────────────────────────────────────────────────
export const SEARCH_DATA = {
  clients: [
    { name: 'KARS INC',            sub: 'General Liability · Renewal due in 8 days', initials: 'K'  },
    { name: 'Hemant Patel',         sub: 'Commercial Property · Lone Oak Studio Suites', initials: 'HP' },
    { name: 'Core Transport Totah', sub: 'Commercial Auto · Active',               initials: 'CT' },
  ],
  renewals: [
    { name: 'Aniad Selim — Dwelling Fire',       sub: 'Due in 18 days · Pending' },
    { name: 'Lone Oak — Commercial Property',    sub: 'Due in 42 days · Quoted'  },
  ],
  tasks: [
    { name: 'Freedom Choice — Property Reinstatement', sub: 'Task · Due Oct 31 · High priority' },
    { name: '2020 SF Taxi Quote — Igor',               sub: 'Quote · Due Oct 28 · Pending'      },
  ],
};

// ── NAV ───────────────────────────────────────────────────────────────────────
export const NAV_ITEMS = [
  {
    section: 'Overview',
    items: [
      { label: 'Dashboard',   icon: '⊞', href: '/dashboard' },
      { label: 'My Tasks',    icon: '✓', href: '/tasks',    badge: '14', badgeVariant: 'amber' as const },
      { label: 'Reports',     icon: '📊', href: '/reports'  },
    ],
  },
  {
    section: 'Insurance',
    items: [
      { label: 'Renewals',          icon: '↻', href: '/renewals',    badge: '56', badgeVariant: 'red' as const },
      { label: 'Submissions',       icon: '📋', href: '/submissions' },
      { label: 'Quotes',            icon: '💲', href: '/quotes'      },
      { label: 'Market Submissions',icon: '🏛', href: '/market'      },
    ],
  },
  {
    section: 'Clients',
    items: [
      { label: 'Clients',   icon: '👥', href: '/clients' },
      { label: 'Leads',     icon: '🎯', href: '/leads',    badge: '3', badgeVariant: 'green' as const },
      { label: 'Call Log',  icon: '📞', href: '/calls'   },
    ],
  },
  {
    section: 'Operations',
    items: [
      { label: 'Service Requests', icon: '🔧', href: '/service'     },
      { label: 'Inspections',      icon: '🔍', href: '/inspections' },
      { label: 'Documents',        icon: '📁', href: '/documents'   },
      { label: 'Carrier Contacts', icon: '🏢', href: '/carriers'    },
    ],
  },
  {
    section: 'Sync & API',
    items: [
      { label: 'QQCatalyst Sync', icon: '⟳', href: '/sync'     },
      { label: 'Settings',        icon: '⚙', href: '/settings' },
    ],
  },
];
