/**
 * lib/api/service.ts
 * ─────────────────────────────────────────────────────────────────
 * High-level service functions called by Next.js API routes and
 * React hooks. Each function:
 *  1. Tries QQCatalyst (live data)
 *  2. Falls back to mock data if QQ is unavailable or unconfigured
 *
 * This lets you develop locally without QQ credentials, and gracefully
 * degrade in production if QQ goes down.
 */

import type { Renewal, Quote, Task, Activity, StatCard } from '@/types';
import { qqApi } from '@/lib/qqcatalyst/client';
import { transformPolicies, transformQuotes, transformTasks, transformActivityFeed } from '@/lib/qqcatalyst/transform';
import { RENEWALS, QUOTES, INITIAL_TASKS, ACTIVITY_FEED, STAT_CARDS } from '@/lib/data';
import { ApiError } from './client';

// ── CONFIG ─────────────────────────────────────────────────────────────────────
const QQ_ENABLED = Boolean(process.env.QQCATALYST_API_KEY);

function log(msg: string, err?: unknown) {
  if (process.env.NODE_ENV !== 'production') {
    console.warn(`[InsureTrack] ${msg}`, err ?? '');
  }
}

// ── RENEWALS ───────────────────────────────────────────────────────────────────
export async function getRenewals(daysAhead = 90): Promise<Renewal[]> {
  if (!QQ_ENABLED) return RENEWALS;
  try {
    const raw = await qqApi.getExpiringPolicies(daysAhead);
    return transformPolicies(raw);
  } catch (err) {
    log('getRenewals failed, using mock data', err);
    return RENEWALS;
  }
}

// ── QUOTES ─────────────────────────────────────────────────────────────────────
export async function getQuotes(): Promise<Quote[]> {
  if (!QQ_ENABLED) return QUOTES;
  try {
    const raw = await qqApi.getQuotes({ pageSize: 100 });
    return transformQuotes(raw);
  } catch (err) {
    log('getQuotes failed, using mock data', err);
    return QUOTES;
  }
}

// ── TASKS ──────────────────────────────────────────────────────────────────────
export async function getTasks(): Promise<Task[]> {
  if (!QQ_ENABLED) return INITIAL_TASKS;
  try {
    const raw = await qqApi.getActivities({ type: 'Task', status: 'Open', pageSize: 100 });
    return transformTasks(raw);
  } catch (err) {
    log('getTasks failed, using mock data', err);
    return INITIAL_TASKS;
  }
}

export async function completeTask(taskId: string): Promise<void> {
  if (!QQ_ENABLED) return; // noop in mock mode
  await qqApi.updateActivity(taskId, {
    Status: 'Completed',
    CompletedDate: new Date().toISOString(),
  });
}

export interface NewTaskInput {
  name: string;
  clientName: string;
  dueDate?: string;
  priority?: 'High' | 'Medium' | 'Low';
  policyType?: string;
}

export async function createTask(input: NewTaskInput): Promise<void> {
  if (!QQ_ENABLED) return; // noop in mock mode
  await qqApi.createActivity({
    ActivityType: 'Task',
    Subject:      input.name,
    Description:  `${input.policyType ?? ''} — ${input.clientName}`,
    ClientName:   input.clientName,
    Status:       'Open',
    Priority:     input.priority ?? 'Medium',
    DueDate:      input.dueDate,
    ActivityDate: new Date().toISOString(),
  });
}

// ── ACTIVITY FEED ──────────────────────────────────────────────────────────────
export async function getActivityFeed(): Promise<Activity[]> {
  if (!QQ_ENABLED) return ACTIVITY_FEED;
  try {
    const raw = await qqApi.getActivities({ pageSize: 20 });
    return transformActivityFeed(raw);
  } catch (err) {
    log('getActivityFeed failed, using mock data', err);
    return ACTIVITY_FEED;
  }
}

// ── DASHBOARD STATS ────────────────────────────────────────────────────────────
export interface DashboardStats {
  pendingTasks:     number;
  upcomingRenewals: number;
  urgentRenewals:   number;
  activeQuotes:     number;
  activeClients:    number;
}

export async function getDashboardStats(): Promise<DashboardStats> {
  if (!QQ_ENABLED) {
    return {
      pendingTasks:     14,
      upcomingRenewals: 56,
      urgentRenewals:   3,
      activeQuotes:     7,
      activeClients:    42,
    };
  }

  // Fetch in parallel for speed
  const [renewals, tasks, quotes, clients] = await Promise.allSettled([
    qqApi.getExpiringPolicies(90),
    qqApi.getActivities({ type: 'Task', status: 'Open' }),
    qqApi.getQuotes({ status: 'In Progress' }),
    qqApi.getClients(),
  ]);

  return {
    pendingTasks:     tasks.status     === 'fulfilled' ? tasks.value.length         : 0,
    upcomingRenewals: renewals.status  === 'fulfilled' ? renewals.value.length       : 0,
    urgentRenewals:   renewals.status  === 'fulfilled'
      ? renewals.value.filter(r => {
          const days = Math.round((new Date(r.ExpirationDate).getTime() - Date.now()) / 86_400_000);
          return days <= 20;
        }).length
      : 0,
    activeQuotes:     quotes.status    === 'fulfilled' ? quotes.value.length         : 0,
    activeClients:    clients.status   === 'fulfilled' ? clients.value.TotalCount    : 0,
  };
}

export function buildStatCards(stats: DashboardStats): StatCard[] {
  return [
    {
      id: 'tasks',
      label: 'Pending Tasks',
      value: stats.pendingTasks,
      subtext: `${stats.pendingTasks} require attention this week`,
      variant: 'amber',
      badge: stats.pendingTasks > 0 ? 'Needs attention' : undefined,
    },
    {
      id: 'renewals',
      label: 'Upcoming Renewals',
      value: stats.upcomingRenewals,
      subtext: `In the next 90 days · ${stats.urgentRenewals} urgent`,
      variant: 'red',
    },
    {
      id: 'quotes',
      label: 'Active Quotes',
      value: stats.activeQuotes,
      subtext: `Active in pipeline`,
      variant: 'blue',
    },
    {
      id: 'clients',
      label: 'Active Clients',
      value: stats.activeClients,
      subtext: 'Total active policies',
      variant: 'green',
    },
  ];
}
