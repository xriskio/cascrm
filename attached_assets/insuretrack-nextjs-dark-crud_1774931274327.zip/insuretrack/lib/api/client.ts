/**
 * lib/api/client.ts
 * ─────────────────────────────────────────────────────────────────
 * Typed HTTP client used by every API helper in this project.
 * Handles: auth headers, retries, error normalization, timeouts.
 */

// ── ERROR ──────────────────────────────────────────────────────────────────────
export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }

  get isNotFound()     { return this.status === 404; }
  get isUnauthorized() { return this.status === 401; }
  get isServerError()  { return this.status >= 500; }
}

// ── CONFIG ─────────────────────────────────────────────────────────────────────
interface RequestOptions extends RequestInit {
  /** Timeout in ms (default 10 000) */
  timeout?: number;
  /** How many times to retry on 5xx / network errors (default 2) */
  retries?: number;
  /** Base delay between retries in ms (doubles each attempt, default 300) */
  retryDelay?: number;
}

// ── INTERNAL HELPERS ───────────────────────────────────────────────────────────
async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function buildHeaders(extra?: HeadersInit): Headers {
  const h = new Headers(extra);
  h.set('Content-Type', 'application/json');
  h.set('Accept', 'application/json');

  // Internal API key — set INTERNAL_API_SECRET in your .env
  const secret = process.env.INTERNAL_API_SECRET;
  if (secret) h.set('X-API-Key', secret);

  return h;
}

async function parseResponse<T>(res: Response): Promise<T> {
  const text = await res.text();

  // Some endpoints return empty 204 bodies
  if (!text) return undefined as T;

  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    throw new ApiError(res.status, 'PARSE_ERROR', `Non-JSON response: ${text.slice(0, 120)}`);
  }

  if (!res.ok) {
    const err = json as { message?: string; code?: string; error?: string };
    throw new ApiError(
      res.status,
      err.code ?? 'API_ERROR',
      err.message ?? err.error ?? `HTTP ${res.status}`,
      json,
    );
  }

  return json as T;
}

// ── CORE FETCH ─────────────────────────────────────────────────────────────────
export async function apiFetch<T>(
  url: string,
  { timeout = 10_000, retries = 2, retryDelay = 300, ...init }: RequestOptions = {},
): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);

  let attempt = 0;

  while (true) {
    try {
      const res = await fetch(url, {
        ...init,
        headers: buildHeaders(init.headers),
        signal: controller.signal,
      });
      clearTimeout(timer);
      return await parseResponse<T>(res);

    } catch (err) {
      const isRetryable =
        (err instanceof ApiError && err.isServerError) ||
        (err instanceof TypeError); // network failure

      if (isRetryable && attempt < retries) {
        attempt++;
        await sleep(retryDelay * 2 ** (attempt - 1));
        continue;
      }

      clearTimeout(timer);

      if ((err as Error).name === 'AbortError') {
        throw new ApiError(408, 'TIMEOUT', `Request timed out after ${timeout}ms`);
      }

      throw err;
    }
  }
}

// ── CONVENIENCE METHODS ────────────────────────────────────────────────────────
export const api = {
  get: <T>(url: string, opts?: RequestOptions) =>
    apiFetch<T>(url, { method: 'GET', ...opts }),

  post: <T>(url: string, body: unknown, opts?: RequestOptions) =>
    apiFetch<T>(url, { method: 'POST', body: JSON.stringify(body), ...opts }),

  put: <T>(url: string, body: unknown, opts?: RequestOptions) =>
    apiFetch<T>(url, { method: 'PUT', body: JSON.stringify(body), ...opts }),

  patch: <T>(url: string, body: unknown, opts?: RequestOptions) =>
    apiFetch<T>(url, { method: 'PATCH', body: JSON.stringify(body), ...opts }),

  delete: <T>(url: string, opts?: RequestOptions) =>
    apiFetch<T>(url, { method: 'DELETE', ...opts }),
};
